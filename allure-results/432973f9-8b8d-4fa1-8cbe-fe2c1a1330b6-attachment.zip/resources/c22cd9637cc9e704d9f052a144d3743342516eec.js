if( 'function' === typeof importScripts) {
importScripts('https://st-a.cdp.asia/antsomiSDKsw.js');
}