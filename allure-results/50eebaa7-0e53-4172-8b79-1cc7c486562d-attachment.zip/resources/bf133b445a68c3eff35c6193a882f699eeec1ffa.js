var checkUpdate = null, checkUpdate_2 = null;
const html_rating_btn = `
  <button id="start_rating">
    Viết đánh giá <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3 9H15M15 9L10.5 4.5M15 9L10.5 13.5" stroke="#110E11" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
  </button>
`;

KG.Index = {
  video_status: 'pause',
	init: function(){
		var that = this;
		that.sliderBannerHome();
		that.sliderCollection();
		that.sliderModule();
    that.tabBrands();
    try {
      that.videoModule();
    }
    catch (err){
      
    }
    $('.slider-cates').each(function(){
      var target = '#' + $(this).attr('id');
      var count_item = $(this).find('.item').length;
      if(count_item > 3 && window.screen.width > 768){
        that.sliderBannerCate(target);
      }
    });

    if($('.section-flashsale-home').length > 0){
      that.checkTimeFlashsale();
    }
	},
  checkTimeFlashsale: function(){
    var self = this;
    const flashSaleData = flashsale;
    const now = new Date();
    const todayKey = `${now.getDate()}/${now.getMonth() + 1 > 10 ? now.getMonth() + 1 : '0' + (now.getMonth() + 1)}/${now.getFullYear()}`;
    const currentTime = now.toTimeString().split(' ')[0];
    const timeFrames = flashSaleData[todayKey] || [];
    let currentFrame = null;
    let currentFrameIndex = 0;
    
    function findCurrentFrame() {
      for (let i = 0; i < timeFrames.length; i++) {
        const timeRange = timeFrames[i].time.split(' - ');
        const timeStart = timeRange[0];
        const timeEnd = timeRange[1];
        if (currentTime >= timeStart && currentTime <= timeEnd) {
          currentFrameIndex = i;
          return timeFrames[i];
        }
      }
      return null;
    }
    
    currentFrame = findCurrentFrame();
    function getCurrentFrameDetails() {
      if (currentFrame) {
        return {
          limit: currentFrame.limit,
          handle: currentFrame.handle
        };
      }
      return null;
    }
    
    function displayFrameDetails() {
      const details = getCurrentFrameDetails();
      if (details) {
        self.sliderFlashsale(details.handle,details.limit);
      } 
      else {
        $('.section-flashsale-home').hide();
      }
    }
    
    function parseDate(dateString, timeString) {
      const [day, month, year] = dateString.split('/').map(Number);
      const [hours, minutes, seconds] = timeString.split(':').map(Number);
      return new Date(year, month - 1, day, hours, minutes, seconds);
    }
    
    function formatToISO(dateString, timeString) {
      const [day, month, year] = dateString.split('/');
      const [hours, minutes, seconds] = timeString.split(':');
      return year + '-' + month + '-' + day + 'T' + hours + ':' + minutes + ':' + seconds;
    }
    
    if (!currentFrame) {
      $('.section-flashsale-home').hide();
    } 
    else {
      const timeRange = currentFrame.time.split(' - ');
      const timeStart = parseDate(todayKey, timeRange[0]);
      const timeEnd = parseDate(todayKey, timeRange[1]);
      const timeStartNew = formatToISO(todayKey, timeRange[0]);
      const timeEndNew = formatToISO(todayKey, timeRange[1]);
      function tick(milliseconds) {
        if (milliseconds === 0) {
          $('.section-flashsale-home').hide();
        } 
        else {
          $('#label-due').html("Sắp diễn ra:");
        }
      }
      function tick2(milliseconds) {
        if (milliseconds === 0) {
          $('.section-flashsale-home').hide();
        } 
        else {
          $('#label-due').html("Đang diễn ra:");
        }
      }
      function complete() {
        currentFrameIndex++;
        if (currentFrameIndex < timeFrames.length) {
          console.log('123');
          //startCountdown(timeFrames[currentFrameIndex]);
        } 
        else {
          $('#label-due').html("Chờ đến khung giờ tiếp theo...");
        }
      }
      const element = document.getElementById('flashsale-countdown');
      Soon.create(element, {
        due: now < timeStart ? timeStartNew : timeEndNew,
        now: null,
        layout: "group label-small",
        face: "flip color-light",
        format: "d,h,m,s",
        labelsYears: null,
        labelsDays: 'Ngày',
        labelsHours: 'Giờ',
        labelsMinutes: 'Phút',
        labelsSeconds: 'Giây',
        separateChars: false,
        scaleMax: "s",
        separator: "",
        singular: true,
        paddingDays: "00",
        eventTick: now < timeStart ? tick : tick2,
        eventComplete: complete
      });
      $('#flashsale-countdown').addClass('soon');
      displayFrameDetails();
    }
  },
  sliderFlashsale: function(handle,limit){ 
    var url_get = '/collections/' + handle + '/products.json?include=metafields[product]&page=1&limit='+limit;
    var page = 1;
		$.get(url_get).done(function(data){
			if(data.products.length > 0){
				$('.section-flashsale-home .list-products').html('');
				data.products.map((item,ind) => {
					var html_loop = `<div class="swiper-slide"><div class="pro-loop pro-flashsale ">` + KG.Global.renderLoop(item,limit*(page - 1) + (ind + 1)) + `</div></div>`;
					$('.section-flashsale-home .list-products').append(html_loop);
				});
			}
			var swiper = new Swiper(".section-flashsale-home .swiper-container", {
        loop: false,
        slidesPerView: 1.2,
        spaceBetween: 16,
        breakpoints: {
          735: {
            slidesPerView: 2.5,
          },
          1024: {
            slidesPerView: 4,
          },
          1460: {
            slidesPerView: 4,
          }
        },
        navigation: {
          nextEl: '.section-flashsale-home .swiper-button-next',
          prevEl: '.section-flashsale-home .swiper-button-prev',
        },
        scrollbar: {
          el: '.section-flashsale-home .swiper-scrollbar',
          draggable: true
        }
      });
		});
  },
	sliderBannerHome: function(){
    if($('#bannerhome-slider .swiper-slide').length > 1) $('#bannerhome-slider .swiper-button-nav').removeClass('d-none');
		var swiper = new Swiper("#bannerhome-slider", {
			loop: $('.section-slider .item-video').length > 0 ? false : true,
			slidesPerView: 1,
			spaceBetween: 1,
			autoplay: {
				delay: 5000,
			},
			navigation: {
				nextEl: "#bannerhome-slider .swiper-button-next",
				prevEl: "#bannerhome-slider .swiper-button-prev",
			},
      lazy: {
        loadPreNext: true
      }
		});
	},
	sliderModule: function(){
    //Logo Brand
		if($(window).width() < 992){
			new Swiper('#brandhome-slider', {
				loop: true,
				slidesPerView: 2,
				spaceBetween: 0,
        autoplay: {
  				delay: 3000,
  			},
				breakpoints: {
					767: {
						slidesPerView: 4,
					}
				},
				navigation: {
  				nextEl: "#brandhome-slider .swiper-button-next",
  				prevEl: "#brandhome-slider .swiper-button-prev",
  			}
			});
		}
	},
  videoModule: function(){
    var self = this;
    $('#start_video').on('click',function(e){
      e.preventDefault();
      $(this).toggleClass('start');
      if(self.video_status == 'pause'){
        if(!$(this).siblings('video').hasClass('up')) $(this).siblings('video').addClass('up');
        $(this).siblings('video')[0].play();
        self.video_status = 'play';
      }
      else{
        $(this).siblings('video')[0].pause();
        self.video_status = 'pause';
      }
    });
    $('#start_video').trigger('click');
  },
	sliderCollection: function(){ 
    if($('#collection-slider-1').length > 0){
      var id1 = $('#collection-slider-1 .swiper-container').attr('data-id');
  		var titleColl1 = $('#collection-slider-1 .swiper-container').attr('data-title');
  		var urlColl1   = $('#collection-slider-1 .swiper-container').attr('data-handle');
      KG.Global.getItemSlide('pro-t1',id1,titleColl1,urlColl1,1,8,'#collection-slider-1',function(){
        var swiper1 = new Swiper("#collection-slider-1 .swiper-container", {
          loop: false,
          slidesPerView: 1.22,
          grid: {
            rows: 2,
          },
          spaceBetween: 32,
          breakpoints: {
            767: {
              slidesPerView: 2.5,
            },
            1023: {
              spaceBetween: 40,
              slidesPerView: 4,
            },
            1460: {
              spaceBetween: 40,
              slidesPerView: 4,
            }
          },
          navigation: {
            nextEl: '#collection-slider-1 .swiper-button-next',
            prevEl: '#collection-slider-1 .swiper-button-prev',
          }
        });
      });
    }

    if($('#collection-slider-3').length > 0){
      var id3 = $('#collection-slider-3 .swiper-container').attr('data-id');
  		var titleColl3 = $('#collection-slider-3 .swiper-container').attr('data-title');
  		var urlColl3   = $('#collection-slider-3 .swiper-container').attr('data-handle');
      KG.Global.getItemSlide('pro-t1',id3,titleColl3,urlColl3,1,8,'#collection-slider-3',function(){
        var swiper3 = new Swiper("#collection-slider-3 .swiper-container", {
          loop: false,
          slidesPerView: 1.22,
          spaceBetween: 32,
          breakpoints: {
            767: {
              slidesPerView: 2.5,
            },
            1023: {
              spaceBetween: 40,
              slidesPerView: 4,
            },
            1460: {
              spaceBetween: 40,
              slidesPerView: 4,
            }
          },
          navigation: {
            nextEl: '#collection-slider-3 .swiper-button-next',
            prevEl: '#collection-slider-3 .swiper-button-prev',
          }
        });
      });
    }

    
    if($('#collection-slider-2').length > 0){
      var id2 = $('#collection-slider-2 .swiper-container').attr('data-id');
  		var titleColl2 = $('#collection-slider-2 .swiper-container').attr('data-title');
  		var urlColl2   = $('#collection-slider-2 .swiper-container').attr('data-handle');
      KG.Global.getItemSlide('pro-t2',id2,titleColl2,urlColl2,1,8,'#collection-slider-2',function(){
        var swiper2 = new Swiper("#collection-slider-2 .swiper-container", {
          loop: false,
          slidesPerView: 1.4,
          spaceBetween: 64,
          breakpoints: {
            735: {
              slidesPerView: 3,
            },
            1024: {
              slidesPerView: 3,
            },
            1460: {
              slidesPerView: 3,
            }
          },
          navigation: {
            nextEl: '#collection-slider-2 .swiper-button-next',
            prevEl: '#collection-slider-2 .swiper-button-prev',
          }
        });
      });
    }
	},
  tabBrands: function() {
    function sliderTab (ind) {
      new Swiper(ind, {
        loop: false,
        slidesPerView: 1.6,
        spaceBetween: 12,
        breakpoints: {
          767: {
            slidesPerView: 2.2,
          },
          991: {
            slidesPerView: 3,
          }
        },
        navigation: {
          nextEl: ind+" .swiper-button-next",
          prevEl: ind+" .swiper-button-prev",
        }
      });
    }
    $( ".section-brandcategory-tab .tab-content" ).each(function(){
  		var that = jQuery(this);
  		var id	= '#'+that.find('div[id*="brandcate-slider-"]').attr('id');
      sliderTab(id);
  	});
    $(document).on('click','.section-brandcategory-tab .tablist li a',function(e){
      e.preventDefault();
			var target = $(this).attr('data-tab');
			$('.section-brandcategory-tab .tablist li').removeClass('active-tab');
      $('.section-brandcategory-tab .tab-content').removeClass('active-tab show');
			$(this).parent().addClass('active-tab');
			$('#'+target).addClass('active-tab show');
		});
		
  },
  sliderBannerCate: function(target){
    var swiper2 = new Swiper(target, {
      loop: false,
      slidesPerView: 1.18,
      spaceBetween: 24,
      breakpoints: {
        735: {
          slidesPerView: 3,
        },
        1024: {
          slidesPerView: 3,
        },
        1460: {
          slidesPerView: 3,
        }
      },
      navigation: {
        nextEl: target + ' .swiper-button-next',
        prevEl: target + ' .swiper-button-prev'
      }
    });
  }
}

KG.IndexV2 = {
  init: function(){
    var that = this;
    that.sliderCateHome();
    that.sliderCollection();
    that.galleryAction();
    that.runVideo();
  },
  runVideo: function(){
    if($('.section-video').length > 0 && $('.section-video').find('[data-vbg]').length > 0){
      $('.section-video').find('[data-vbg]').youtube_background();
    }
  },
  sliderCateHome: function(){
    if($('#cates-slider').length > 0){
      var swiper = new Swiper("#cates-slider", {
  			loop: $('#cates-slider').find('[data-vbg]').length > 0 ? false : true,
  			autoplay: false,
  			navigation: {
  				nextEl: "#cates-slider .swiper-button-next",
  				prevEl: "#cates-slider .swiper-button-prev",
  			},
        breakpoints: {
          640: {
            slidesPerView: 1,
            spaceBetween: 0
          },
          768: {
            slidesPerView: 4,
      			spaceBetween: 51,
          }
        },
        
  		});

      if($('#cates-slider').find('[data-vbg]').length > 0){
        $('#cates-slider').find('[data-vbg]').youtube_background();
      }
    }
    
    if($('#cates-slider-2').length > 0){
      var swiper = new Swiper("#cates-slider-2", {
  			loop: true,
  			autoplay: false,
        
        slidesPerView: 2,
        spaceBetween: 10,
        
  			navigation: {
  				nextEl: "#cates-slider-2 .swiper-button-next",
  				prevEl: "#cates-slider-2 .swiper-button-prev",
  			},
        breakpoints: {
          640: {
            slidesPerView: 2,
            spaceBetween: 10
          },
          768: {
            slidesPerView: 3,
      			spaceBetween: 10
          },
          1024: {
            slidesPerView: 4,
      			spaceBetween: 10
          }
        },
  		});
    }
    
    if($('#middle-slider').length > 0){
      var swiper = new Swiper("#middle-slider", {
  			loop: true,
  			autoplay: {
  				delay: 3000,
  			},
        spaceBetween: 10,
        slidesPerView: 1,
  			navigation: false,
        breakpoints: {
          640: {
            slidesPerView: 1,
            spaceBetween: 10
          },
          768: {
            slidesPerView: 1,
      			spaceBetween: 10
          },
          1024: {
            slidesPerView: 2,
      			spaceBetween: 40
          }
        },
  		});
    }
	},
  sliderCollection: function(){
    if($('#collection-slider-2-new').length > 0){
      var id_spec = $('#collection-slider-2-new .swiper-container').attr('data-id');
  		var titleCollSpec = $('#collection-slider-2-new .swiper-container').attr('data-title');
  		var urlCollSpec   = $('#collection-slider-2-new .swiper-container').attr('data-handle');
      
      KG.Global.getItemSlide('pro-t2', id_spec, titleCollSpec, urlCollSpec, 1, 8, '#collection-slider-2-new',function(){
        var swiper2 = new Swiper("#collection-slider-2-new .swiper-container", {
          loop: false,
          slidesPerView: 1.4,
          spaceBetween: 10,
          breakpoints: {
            735: {
              slidesPerView: 3,
            },
            1024: {
              slidesPerView: 3,
            },
            1460: {
              slidesPerView: 3,
            }
          },
          navigation: {
            nextEl: '#collection-slider-2-new .slider-collection-new .swiper-button-next',
            prevEl: '#collection-slider-2-new .slider-collection-new .swiper-button-prev',
          }
        });
      });
    }
  },
  galleryAction: function(){
    Fancybox.bind('[data-fancybox="gallery"]', {
			thumbs : {
				autoStart : false
			},
			buttons: [
				"zoom",
				"close"
			]
		});

    var swiper = new Swiper("#gallery-top-slider", {
			loop: true,
			slidesPerView: 1.22,
      spaceBetween: 15,
      centeredSlides: true,
      breakpoints: {
        767: {
          slidesPerView: 2.5,
          spaceBetween: 15
        },
        1023: {
          spaceBetween: 15,
          slidesPerView: 4,
          centeredSlides: false
        },
        1460: {
          spaceBetween: 15,
          slidesPerView: 5,
          centeredSlides: false
        }
      },
      navigation: false,
      autoplay: {
				delay: 3000,
			}
		});

    var swiper = new Swiper("#gallery-bottom-slider", {
			loop: true,
			slidesPerView: 1.22,
      spaceBetween: 15,
      centeredSlides: true,
      breakpoints: {
        767: {
          slidesPerView: 2.5,
          spaceBetween: 15,
        },
        1023: {
          spaceBetween: 15,
          slidesPerView: 4,
          centeredSlides: false
        },
        1460: {
          spaceBetween: 15,
          slidesPerView: 5,
          centeredSlides: false
        }
      },
      navigation: false,
      autoplay: {
				delay: 3000,
			}
		});
  }
}

KG.Product = {
	check_recommend: false,
	current_variant: null,	
  slideImage: null,
  openSize: false,
  info_wishlist: {},
  keyGuild: '',
	init: function(){
		var that = this;
		
		that.renderProductDetail.init();
		that.fancyboxGallery();
		that.multiStore();
		that.sliderCollection();
		that.productAction();
		that.atcProduct();
    that.fixedVariant();
    that.mixProducts();
    that.recommendProducts();
    that.processGuildline();
    that.actionFormRating();
    $('.description-content table').wrap('<div class="table-responsive"></div>');

    checkUpdate = setInterval(that.updateFormRating,1000);
    checkUpdate_2 = setInterval(that.updateNotFormRating,1000);
	},
  
	renderProductDetail: {
		init: function(){
			var that = this;
      that.renderInfo();
			that.renderColor();
      that.renderSize();
      that.render3rd();
      that.selectCall();
      that.getStore();
		},
    renderInfo: function() {
      var variant = productInfo.variants[0] //tạm check 
      var brand = productInfo.vendor; 
      var textBtnATC = 'Thêm vào giỏ';
      var svgBtnATC = '<svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.834 7.50002V5.00002C13.834 3.15907 12.3416 1.66669 10.5006 1.66669C8.65968 1.66669 7.1673 3.15907 7.1673 5.00002V7.50002M3.49397 8.62666L2.99397 13.96C2.85181 15.4764 2.78072 16.2346 3.03234 16.8202C3.25338 17.3347 3.64073 17.7601 4.13232 18.0282C4.6919 18.3334 5.45344 18.3334 6.97651 18.3334H14.0248C15.5478 18.3334 16.3094 18.3334 16.8689 18.0282C17.3605 17.7601 17.7479 17.3347 17.9689 16.8202C18.2205 16.2346 18.1495 15.4764 18.0073 13.96L17.5073 8.62666C17.3872 7.34614 17.3272 6.70588 17.0392 6.22182C16.7856 5.79551 16.4109 5.45428 15.9628 5.24156C15.454 5.00002 14.8109 5.00002 13.5248 5.00002L7.47651 5.00002C6.19037 5.00002 5.54731 5.00002 5.03848 5.24156C4.59035 5.45428 4.21564 5.79551 3.96202 6.22182C3.67404 6.70588 3.61402 7.34614 3.49397 8.62666Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      if(productInfo.tags.includes('pre-order')) {
        //brand == "CHRISBELLA"
        textBtnATC = 'Đặt hàng trước';
        svgBtnATC  = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_1495_16077)"><path d="M12.0832 15.8332L13.7498 17.4998L17.4998 13.7498M18.3208 10.4581C18.329 10.3064 18.3332 10.1536 18.3332 9.99984C18.3332 5.39746 14.6022 1.6665 9.99984 1.6665C5.39746 1.6665 1.6665 5.39746 1.6665 9.99984C1.6665 14.5293 5.28026 18.2148 9.78191 18.3304M9.99984 4.99984V9.99984L13.1151 11.5575" stroke="white" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/></g><defs><clipPath id="clip0_1495_16077"><rect width="20" height="20" fill="white"/></clipPath></defs></svg>';
      }
      $(".pr-controls #btn-addtocart").html(svgBtnATC + '<span>' + textBtnATC + '</span>');
      $('.pr-title').html(productInfo.title);
      $('.pr-vendor').html(brand);
      
			if(variant.price < variant.compare_at_price){
				var pro_sold = variant.price;
				var pro_comp = variant.compare_at_price / 100;
				var sale = 100 - (pro_sold / pro_comp);
				var kq_sale = Math.round(sale);
				$('.pr-price del').html(Haravan.formatMoney(variant.compare_at_price, window.shop.moneyFormat).replace('₫','đ')).removeClass('d-none');
				$('.pr-price del').removeClass('d-none');
				$('.pr-price span.price').html(Haravan.formatMoney(variant.price,window.shop.moneyFormat).replace('₫','đ'));
				$('.pr-price span.price').addClass('reduced').attr('content',variant.price / 100);
				$('.pr-price span.price-percent').html(kq_sale+'% OFF').removeClass('d-none');
			} 
			else {
				$('.pr-price span.price').html(Haravan.formatMoney(variant.price, window.shop.moneyFormat).replace('₫','đ'));
				$('.pr-price span.price').removeClass('reduced').attr('content',variant.price / 100);
				$('.pr-price del').addClass('d-none');
				$('.pr-price span.price-percent').addClass('d-none');
			}

			if(variant.price > 0){
				$('.pr-controls #btn-addtocart').removeClass('d-none');
				if(productInfo.available && variant.price > 0){
					if(variant.available){
						$('.productdetail-info').removeClass('isSoldout');
						$('.pr-controls #btn-addtocart').removeClass('disabled').prop('disabled', false); 
					}
					else {
            
          }
				}
				else{
					$('.productdetail-info').addClass('isSoldout');
					$('.pr-controls #btn-addtocart').addClass('disabled').prop('disabled', true);
				}
			}
			else {
				$('.pr-controls #btn-addtocart').addClass('d-none');
			}		
    },
		renderColor: function(){
			var ind_color = productInfo.options.indexOf('Màu');
      ind_color = ind_color == -1 ? productInfo.options.indexOf('Màu sắc') : ind_color;
      if(ind_color > -1){
        var unique_color = [];
        var html_color = '';
        productInfo.variants.map((vr) => {
          var key_opt = 'option'+(ind_color+1);
          var color = vr[key_opt];
          if(!unique_color.includes(color)){
             unique_color.push(color);
             var bg_color = '#f6f6f6', bg_img = '';
           
             if(vr.featured_image != null){
               bg_img = vr.featured_image.src;
             }
            
             if(icon_color.length > 0){
                var find_icon = icon_color.filter(icon => icon.alt.indexOf(color) > -1);
                if(find_icon.length > 0){
                  bg_img = find_icon[0].src
               }
             }
             var class_soldout = '';
             if(productInfo.options.length == 1 && !vr.available) class_soldout = 'unavai';
             else{
               if(productInfo.options.length > 1){
                 var check_available = productInfo.variants.filter(vr1 => vr1[key_opt] == color && vr1.available);
                 if(check_available.length == 0) class_soldout = 'unavai';
               }
             }
            
             html_color += `
                <div class="swatch-element">
                    <label class="aspect-ratio ${class_soldout}" ${bg_img != '' ? 'style="background: url('+bg_img+') no-repeat; background-size: contain;"' : ''} data-value="${color}"></label>
                </div>
             `;
          }
       });
       $('.select-swap--color').html(html_color);
      }
      else{
        $('.swatch-color').remove();
      }
		},
		renderSize: function(){
			var ind_size = productInfo.options.indexOf('Kích thước');
      if(ind_size > -1){
        var unique_size = [];
        var html_size = '';
        productInfo.variants.map((vr) => {
          var key_opt = 'option'+(ind_size + 1);
          var size = vr[key_opt];
          var class_soldout = '';
          if(productInfo.options.length == 1 && !vr.available) class_soldout = 'soldout';
          
          if(!unique_size.includes(size)){
             unique_size.push(size);
             html_size += `
                <div class="swatch-element">
                    <label class="aspect-ratio ${class_soldout}" data-value="${size}">${size}</label>
                </div>
             `;
          }
       });
       $('.select-swap--size').html(html_size);
      }
      else{
        $('.swatch-size').remove();
      }
		},
    render3rd: function(){
      if(productInfo.options.length == 3){
        var unique_3rd = [];
        var html_3rd = '';
        productInfo.variants.map((vr) => {
          var key_opt = 'option3';
          var _3rd = vr[key_opt];
          var class_soldout = '';
          
          if(!unique_3rd.includes(_3rd)){
             unique_3rd.push(_3rd);
             html_3rd += `
                <div class="swatch-element">
                    <label class="aspect-ratio" data-value="${_3rd}">${_3rd}</label>
                </div>
             `;
          }
       });
       if(unique_3rd.length == 1){
         html_3rd = html_3rd.replace('aspect-ratio','aspect-ratio sd');
       }
       $('.select-swap--3rd').html(html_3rd);
      }
    },
		selectCall: function(){
      var self = this;

      var target_color = $(document).find('.select-swap--color label:not(.soldout)');
      target_color.hover(function(){
        var color = $(this).attr('data-value');
        $('.swatch-header.color .title span:eq(1)').html(color);
      },function(){
        var color = $('.select-swap--color label.sd').attr('data-value');
        $('.swatch-header.color .title span:eq(1)').html(color);
      });
      
      $(document).on('click','.select-swap--color label:not(.soldout)',function(){
        var color = $(this).attr('data-value');
        $('.swatch-header.color .title span:eq(1)').html(color);
        $('.select-swap--color label').removeClass('sd');
        $(this).addClass('sd');
        
        var first_id = '', size_first = '', first_sku = '';
        if($('.select-swap--size').length > 0){
          $('.select-swap--size label').each(function(){
            var size = $(this).attr('data-value');
            
            var available = productInfo.variants.filter(variant => variant.options.includes(color) && variant.options.includes(size) );
            if(available.length > 0 && available[0].available){
              $(this).removeClass('soldout');
              if($('.select-swap--size label.sd').length > 0){
                if($(this).hasClass('sd')){
                  first_id = available[0].id;
                  size_first = size;
                  first_sku = available[0].sku;
                } 
              } 
              else if(first_id == ''){
                first_id = available[0].id;
                size_first = size;
                first_sku = available[0].sku;
                $(this).removeClass('soldout').addClass('sd');
              }
            }
            else{
              $(this).addClass('soldout').removeClass('sd');
            }
          });
        }
        else{
          var available = productInfo.variants.filter(variant => variant.options.includes(color) );
          if(available.length > 0 && available[0].available){
            first_id = available[0].id;
            first_sku = available[0].sku;
          }
        }
        
        if(first_id != ''){
          if($('.select-swap--size').length > 0 && $('.select-swap--size label.sd').length == 0){
            $('.select-swap--size label[data-value="'+size_first+'"]').addClass('sd');
          }
          $('#product-select').val(first_id);
          $('#product-select').attr('data-sku',first_sku);
          $('#btn-addtocart').removeClass('disabled').removeAttr('disabled');
        }
        else{
          $('#btn-addtocart').addClass('disabled').attr('disabled',true);
        }
          
        self.changeImage(color);
      });
      if($('.select-swap--color').length > 0) $('.pr-infos--variants').find('.select-swap--color .swatch-element:eq(0) label').click();
      
      $(document).on('click','.select-swap--size label:not(.soldout)',function(){
        var size = $(this).attr('data-value');
        $('.select-swap--size label').removeClass('sd');
        $(this).addClass('sd');
        
        var first_id = '', first_sku = '';
        if($('.select-swap--color').length > 0){
          var color = $('.select-swap--color label.sd').attr('data-value');
          var available = productInfo.variants.filter(variant => variant.options.includes(color) && variant.options.includes(size) );
          if(available.length > 0 && available[0].available){
            first_id = available[0].id;
            first_sku = available[0].sku;
          }
        }
        else{
          var available = productInfo.variants.filter(variant => variant.options.includes(size) );
          if(available.length > 0 && available[0].available){
            first_id = available[0].id;
            first_sku = available[0].sku;
          }
        }
        
        if(first_id != ''){
          $('#product-select').val(first_id);
          $('#product-select').attr('data-sku',first_sku);
          $('#btn-addtocart').removeClass('disabled').removeAttr('disabled');
        }
        else{
          $('#btn-addtocart').addClass('disabled').attr('disabled',true);
        }
      });
    },
		changeImage: function(color){
      var html_img = '';
			var img_color = productMedia.filter(img => img.alt == color );
      if(img_color.length > 0){
        img_color.map((img,ind_img) => {
          html_img += `
            <div class="pr-gallery--item swiper-slide i-${ind_img + 1}">
              <a data-fancybox="gallery" class="pr-gallery--aspect-ratio" href="${img.src}">
                <picture>
                  <source srcset="${img.src}" media="(min-width: 768px)">
                  <source srcset="${img.src}" media="(max-width: 767px)">
                  <img class="img-default lazyload" data-src="${img.src}" alt="${color}">
                </picture>
              </a>					
            </div>
          `;
        });
      }
      else if($('.select-swap--color .swatch-element').length == 1){
        productMedia.map((img,ind_img) => {
          html_img += `
            <div class="pr-gallery--item swiper-slide i-${ind_img + 1}">
              <a data-fancybox="gallery" class="pr-gallery--aspect-ratio" href="${img.src}">
                <picture>
                  <source srcset="${img.src}" media="(min-width: 768px)">
                  <source srcset="${img.src}" media="(max-width: 767px)">
                  <img class="img-default lazyload" data-src="${img.src}" alt="${color}">
                </picture>
              </a>					
            </div>
          `;
        });
      }

      if(html_img != ''){
        $('#pr-gallery').html(html_img);
        if(window.screen.width < 768){
          KG.Product.slideImage = new Swiper('#main-slider', {
            loop: false,
            slidesPerView: 1,
            navigation: false,
            pagination: {
              el: "#main-slider .swiper-pagination",
            },
            navigation: {
              nextEl: "#main-slider .swiper-button-next",
              prevEl: "#main-slider .swiper-button-prev",
            }
          });
        }
      } 
		},
		pushUrl: function(url){
			history.replaceState(null, '', url);
		},
		getStore: function(){
			$('#stock-box').html('');
			$('#provinceStore').html('').append('<option value="all">Chọn Tỉnh/Thành phố</option>');
			var storeProvince = {};
      var variantid = $('#product-select').val();
			$.ajax({
				url: "/products/"+productDetail.handle+"?variant=" + variantid+"&view=location",
				success:function(data){
					data = JSON.parse(data);
					if( data.locations.length > 0 ){
						$('#stock-box').removeClass('d-none');
						$('#provinceStore').html('').append('<option value="all">Chọn Tỉnh/Thành phố</option>');
						var array_html = '';
						var inventory_ecom = 0; // 1576832 kho ecom 
						var inventory_phone_all = '0936570399'; //Dùng chung cho toàn cửa hàng
						$.each(data.locations,function(i,v){
							if(v.location_id == '1576832') inventory_ecom = v.inventory_location;
							if(!(storeProvince[v.province_code])){ storeProvince[v.province_code] = v.province_name; }

							var inventory_id_hide = [ '1576832','1519350'];
							if($.inArray(v.location_id, inventory_id_hide) === -1 && v.location_name.indexOf('Tiki') == -1){
								array_html += "<li data-code='"+v.province_code+"' class=''>";
                array_html += '<div class="col1">';
								array_html += "<div class='text name'>" + v.location_name + "</div>";
								array_html += "<div class='text phone'><a href='tel:"+inventory_phone_all+"' >" + /*v.location_phone*/ inventory_phone_all  + "</a></div>";
								array_html += "<div class='text desc d-none'>" + v.location_address + "</div>";
                array_html += "<div class='text time'>Giờ hoạt động: 10:00 - 20:00 hàng ngày</div>";
								array_html += '</div>'; 
                array_html += '<div class="col2">';
                if( v.inventory_location > 0 ){
									array_html += "<span class='status green'>Còn hàng</span>";
								}
								else {
									array_html += "<span class='status yellow'>Hết hàng</span>";
								}
                array_html += '</div>';
								array_html += '<div class="col3"><a class="viewmap" href="/" target="_blank">Xem bản đồ</a></div>';
                array_html += '</li>';
							}
						});
						$.each(storeProvince,function(j,k){
							$('#provinceStore').append('<option value="'+j+'">'+k+'</option>');
						});
						if( array_html != '' ){
							$('.no-stock').addClass('d-none'); 
							$('#stock-box').html(array_html);
							$('#stock-box li[data-code="'+$('#provinceStore').val()+'"]').removeClass('d-none');
						}
						else {
							$('.no-stock').removeClass('d-none'); 
						}
					} 
					else {
						$('#provinceStore').addClass('d-none');
						$('#stock-box').addClass('d-none');
						$('.no-stock').removeClass('d-none');
					}			
				}
			});
		}
	},
	fancyboxGallery: function(){
		//if($(window).width() > 1023){}
    Fancybox.bind('[data-fancybox="gallery"]', {
        Carousel: {
          Navigation: false,
        },
        Toolbar: {
          items: {
            close: {
              tpl: `<button class="f-button" title="Close" data-fancybox-close=""><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 6L6 18M6 6L18 18" stroke="#8C8C8C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`,
            },
            prev: {
              tpl: `<button class="f-button" title="prev" data-fancybox-prev><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.6668 10H3.3335M3.3335 10L8.3335 15M3.3335 10L8.3335 5" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`,
            },
            next: {
              tpl: `<button class="f-button" title="next" data-fancybox-next><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.3335 10H16.6668M16.6668 10L11.6668 5M16.6668 10L11.6668 15" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`,
            },
          },
          display: {
            left: ["prev","next"],
            middle: [
              "fullscreen",
              "zoomOut",
              "zoomIn",
            ],
            right: ["slideshow", "thumbs", "close"],
          },
          
        },
      });
	},
	multiStore: function(){
		$('#btn-findsore').on('click',function(e){
      e.preventDefault();
			$('#multistockModal').modal('show');
		});
		$('#provinceStore').on('change',function(){
			$('#stock-box li').addClass('d-none');
			if ($('#provinceStore').val() == 'all'){
				$('#stock-box li').removeClass('d-none');
			}
			else {
				$('#stock-box li[data-code="'+$('#provinceStore').val()+'"]').removeClass('d-none');
			}
		});
	},
	productAction: function(){
		$('.btn-sizeguide').on('click',function(e){
      e.preventDefault();
      var tabActive = $(this).attr('data-modal');
      
  		$('.modal .tablist .tab-item').removeClass('active');
  		$('.modal .tablist .tab-item[data-tab="'+tabActive+'"]').addClass('active');
  		$('.modal .tabcontent-item').removeClass('active');
  		$('.modal .tabcontents .tabcontent-item#'+tabActive).addClass('active');

  		$('#sizechartModal').modal('show');
      
		});
    
    // Show the first tab by default
  	$(".pr-infos--tabs .tabs-stage > div").removeClass('active');
  	$(".pr-infos--tabs .tabs-stage > div:first").addClass('active');
  	$(".pr-infos--tabs .tabs-nav li:first").addClass("tab-active");
  
  	// Change tab class and display content
  	$(".pr-infos--tabs .tabs-nav a").on("click", function(event) {
  		event.preventDefault();
  		$(".pr-infos--tabs .tabs-nav li").removeClass("tab-active");
  		$(this).parent().addClass("tab-active");
  		$(".pr-infos--tabs .tabs-stage > div").removeClass('active');
  		$($(this).attr("href")).addClass('active');
  	});
	},
	atcProduct: function(){
    var self = this;
		$(document).on('click', '#btn-addtocart:not(.loading):not(.disabled):not(.added)', function(e){
			e.preventDefault();

      if(window.screen.width < 768 && !self.openSize){
        self.openSize = true;
        $('.swatch-size').addClass('open');
        return;
      }
      
			$('#mainLoading').addClass('active');
			$('#btn-addtocart').addClass('loading');
			var id =  $('#product-select').val();
			let sku = $('#product-select').attr('data-sku');
			var quantity = parseInt($('.pr-quantity .input-quantity').val());
			var tagCTKM = $(this).attr('data-ctkm');
			
			var exist = cartJS.items.filter(item => item.variant_id == id);
			if(exist.length > 0){
				var properties = exist[0].properties;
				if(!properties.hasOwnProperty('cates')) properties.cates = productDetail.collection_title.slice(0,5).join(', ');
				if(!properties.hasOwnProperty('CTKM')) properties.CTKM = tagCTKM;
			}
			else{
				var properties = { cates: productDetail.collection_title.slice(0,5).join(', '), CTKM: tagCTKM  };
			}
		
			var param = {
				type: 'POST',
				url: '/cart/add.js',
				data:  { id: id, quantity: quantity, properties: properties },
				dataType: 'json',
				success: function(datacart) {
					KG.Global.cartAjax(function(){

            PE.getCart(() => {
        			getListBXSY();
        		});
            
						KG.Helper.getMiniCart();
						
						$('#mainLoading').removeClass('active');
						$('#btn-addtocart').addClass('added');
						$('#btn-addtocart').removeClass('loading');

            //window.location.href = '/cart';
            
						setTimeout(function(){
							$('#btn-addtocart').removeClass('added');
						},3000);
					},);
				},
				error: function(XMLHttpRequest, textStatus) {
					if ( XMLHttpRequest.status == 422 ){
						KG.Helper.SwalWarning("Thông báo","Đã có lỗi xảy ra",'error',false,false,2000);
						$('#mainLoading').removeClass('active');
						$('#btn-addtocart').removeClass('loading');
					}
				}
			}
			$.ajax(param);
		});
	},
  sliderCollection: function(){ 
    var id1        = $('#js-render-coll-1 .swiper-container').attr('data-id');
		var titleColl1 = $('#js-render-coll-1 .swiper-container').attr('data-title');
		var urlColl1   = $('#js-render-coll-1 .swiper-container').attr('data-handle');
		
		var id2        = $('#js-render-coll-2 .swiper-container').attr('data-id');
		var titleColl2 = $('#js-render-coll-2 .swiper-container').attr('data-title');
		var urlColl2   = $('#js-render-coll-2 .swiper-container').attr('data-handle');

    if($('js-render-coll-1').length > 0){
      KG.Global.getItemSlide('pro-t1',id1,titleColl1,urlColl1,1,8,'#js-render-coll-1',function(){
        var swiper = new Swiper("#js-render-coll-1 .swiper-container", {
          loop: false,
          slidesPerView: 1.2,
          spaceBetween: 16,
          breakpoints: {
            735: {
              slidesPerView: 2,
            },
            1024: {
              slidesPerView: 4,
            },
            1460: {
              slidesPerView: 4,
            }
          },
          navigation: {
            nextEl: '#js-render-coll-1 .swiper-button-next',
            prevEl: '#js-render-coll-1 .swiper-button-prev',
          },
          scrollbar: {
            el: '#js-render-coll-1 .swiper-scrollbar',
            draggable: true
          }
        });
      });
    }
    if($('js-render-coll-2').length > 0){
      KG.Global.getItemSlide('pro-t1',id2,titleColl2,urlColl2,1,8,'#js-render-coll-2',function(){
        var swiper = new Swiper("#js-render-coll-2 .swiper-container", {
          loop: false,
          slidesPerView: 1.2,
          spaceBetween: 16,
          breakpoints: {
            735: {
              slidesPerView: 2,
            },
            1024: {
              slidesPerView: 4,
            },
            1460: {
              slidesPerView: 4,
            }
          },
          navigation: {
            nextEl: '#js-render-coll-2 .swiper-button-next',
            prevEl: '#js-render-coll-2 .swiper-button-prev',
          },
          scrollbar: {
            el: '#js-render-coll-2 .swiper-scrollbar',
            draggable: true
          }
        });
      });
    }
  },
  fixedVariant: function(){
    
  },
  mixProducts: function(){
    if($('#js-mix').length > 0){
      var handle = $('#js-mix .slider-collection').attr('data-handle'),
          limit = $('#js-mix .slider-collection').attr('data-limit');

      $.get('/collections/'+handle+'/products.json?limit='+limit).done(function(data){
        if(data.products.length > 0){
          var html_loop = '';
          data.products.map(item => {
            html_loop += `<div class="swiper-slide"><div class="pro-loop">` + KG.Global.renderLoop(item) + `</div></div>`;
          });
          $('#js-mix .list-products').html(html_loop);
          KG.Wishlist.initFavorites();
          var swiper = new Swiper("#js-mix .swiper-container", {
            loop: false,
            slidesPerView: 1.2,
            spaceBetween: 16,
            breakpoints: {
              735: {
                slidesPerView: 2,
              },
              1024: {
                slidesPerView: 4,
              },
              1460: {
                slidesPerView: 4,
              }
            },
            /*navigation: {},*/
            navigation: false,
            scrollbar: {
              el: '#js-mix .swiper-scrollbar',
              draggable: true
            }
          });
        }
      });
    }
  },
  recommendProducts: function(){
    if(recommends.length > 0){
      var arrRequest = [];
			recommends.map(item => {
				var promise = new Promise(function(resolve, reject) {
					$.ajax({
						url:'/products/' + item + '.js',
						success: function(product){
							resolve(product);
						},
						error: function(err){
							resolve('');
						}
					});
				});
				arrRequest.push(promise);
			});
						
			Promise.all(arrRequest).then(function(values) {
        var html_loop = '';
        
        values.map(item => {
          if(item != ''){
            html_loop += `<div class="swiper-slide"><div class="pro-loop">` + KG.Global.renderLoop(item) + `</div></div>`;
          }
        });
        if(html_loop != ''){
          $('#js-recommend .list-products').html(html_loop);
          KG.Wishlist.initFavorites();
          var swiper = new Swiper("#js-recommend .swiper-container", {
            loop: false,
            slidesPerView: 1.2,
            spaceBetween: 16,
            breakpoints: {
              735: {
                slidesPerView: 2,
              },
              1024: {
                slidesPerView: 4,
              },
              1460: {
                slidesPerView: 4,
              }
            },
            /*navigation: {},*/
            navigation: false,
            scrollbar: {
              el: '#js-recommend .swiper-scrollbar',
              draggable: true
            }
          });
        }
        else{
          $('#js-recommend').hide();
        }
      });
    }
  },
  processGuildline: function(){
    if(data_size.length == 0){
      $('#sizechartModal [data-tab="tabcontent-2"]').hide();
    }
    
    /* Load Image Size With Tag */
    var current_size = data_size.filter(ds => productInfo.tags.includes(ds.tag1) && productInfo.tags.includes(ds.tag2));
    if(current_size.length > 0) $('#sizechartModal #tabcontent-2').html('<img src="'+current_size[0].img+'" />');
    else $('#sizechartModal #tabcontent-2').html('<p>Đang cập nhật</p>');

    var key_guidline = '';
    if(productInfo.tags.includes('Sơ mi')) key_guidline = 'Sơ mi';
    else if(productInfo.type.indexOf('Áo') > -1) key_guidline = 'Áo';
    else if(productInfo.type == 'Quần Boxer' || productInfo.type == 'Quần lót') key_guidline = 'Đồ lót';
    else if(productInfo.type.indexOf('Quần') > -1) key_guidline = 'Quần';

    if(key_guidline != ''){
      this.keyGuild = key_guidline;
    
      guildline[key_guidline].map((info,_idIf) => {
        $('#height_consult').append(`<option value="${info['Chiều cao']}">${info['Chiều cao']}</option>`);
        $('#weight_consult').append(`<option value="${info['Cân nặng']}">${info['Cân nặng']}</option>`);
      });
    }

    /* Action With Tab */
    $('#sizechartModal .tab-item').on('click',function(){
      var target = $(this).attr('data-tab');
      $('#sizechartModal .tab-item').removeClass('active');
      $(this).addClass('active');

      $('#sizechartModal .tabcontent-item').removeClass('active');
      $('#'+target).addClass('active');
    });

    /* Pick Personal Height & Weight */
    $('#height_consult,#weight_consult').on('change',function(){
      var height = $('#height_consult').val(), 
          weight = $('#weight_consult').val();
      if( height != '' && weight != '' ){
        var html_result = '';
        $.each(guildline,function(key,value){
          var result = guildline[key].filter(info => info['Chiều cao'] == height && info['Cân nặng'] == weight);
          var result_priority = -1;
          guildline[key].map((info,_indInf) => { 
            if(info['Cân nặng'] == weight) result_priority = _indInf;
          });
          if(result.length > 0){
            html_result += `<li>${key.toUpperCase()} - ${result[0]['Kết quả']}</li>`
          }
          else if(result_priority != -1){
            html_result += `<li>${key.toUpperCase()} - ${value[result_priority]['Kết quả']}</li>`;
          }
        });
        if(html_result != ''){
          $('.result_consult ul').html(html_result);
          $('.result_consult').removeClass('d-none');
        } 
      }
      else{
        $('.result_consult').addClass('d-none');
      }
    });
  },
  updateFormRating: function(){
    if(!KG.Product.updated && $('.hrv-crv-rating-question-item').length == 6){
      clearInterval(checkUpdate);
      KG.Product.updated = true;
      
      var question_cus = '<div class="hrv-crv-rating-question-groups question_cus">';
      $('.hrv-crv-rating-question-groups > div').each(function(){
        var textQuestion = $(this).find('.hrv-crv-rating-question-item_question').html().trim();
        console.log(textQuestion);
        if(textQuestion.indexOf('kênh nào') > -1 || textQuestion.indexOf('sẵn lòng giới thiệu') > -1){
          question_cus += '<div class="hrv-crv-rating-question-item_answer-groups">'+$(this).clone().html()+'</div>';
          $(this).remove();
        }
        else{
          textQuestion = textQuestion.toLowerCase();
          var type_quest = 'star';
          if(textQuestion.indexOf('về kích cỡ') > -1 || textQuestion.indexOf('về độ rộng') > -1) type_quest = 'circle';
          $(this).attr('data-type',type_quest);
          if(textQuestion.indexOf('kích cỡ') > -1) $(this).attr('data-question','size');
          if(textQuestion.indexOf('độ rộng') > -1) $(this).attr('data-question','width');
          if(textQuestion.indexOf('độ thoải mái') > -1) $(this).attr('data-question','comfortable');
          if(textQuestion.indexOf('chất lượng') > -1) $(this).attr('data-question','quality');
        }
      });
      question_cus += '</div>';
      
      $(question_cus).insertAfter($('.crv-hrvmodal--body .crv-hrvmodal--body-header'));

      $('#crv-hrvmodal--content-rating').removeAttr('rows');
    }
  },
  updateNotFormRating: function(){
    if($('.hrv-crv-rating__group-right').length > 0){
      clearInterval(checkUpdate_2);
      $('.hrv-crv-rating__group-right').prepend(html_rating_btn);
      $('.hrv-crv-rating__group-right').addClass('done');
    }
  },
  actionFormRating: function(){
    $(document).on('change','.hrv-crv-rating-question-item[data-type="star"] input',function(){
      var question = $(this).parents('.hrv-crv-rating-question-item').attr('data-question');
      var val_star = Number($(this).val()) + 1;
      $(this).parents('.hrv-crv-rating-question-item').find('.hrv-crv-rating-question-item_answer-groups').removeClass('active');
      for(var i = 2; i <= val_star; i++){
         $('[data-question="'+question+'"] .hrv-crv-rating-question-item_answer-groups:nth-child('+i+')').addClass('active');
      }
    });

    $(document).on('click','#start_rating',function(e){
      e.preventDefault();
      if(!$(".hrv-crv-rating__groups:not(.hrv-crv-modal)").hasClass('rendered')){
        $(".hrv-crv-rating__groups:not(.hrv-crv-modal) > div:eq(0)").trigger('click');
      }
      else{
        if($('.crv-hrvmodal--backdrop').length == 0){
          var backdrop = `<div class="crv-hrvmodal--backdrop bubgcedscu"></div>`;
          $(backdrop).insertBefore($('.crv-hrvmodal__rating'));
          $('.crv-hrvmodal__rating').addClass('open');
        }
      }
    });
  }
}

KG.Collection = {
  picked: {},
  firstPrice: [100000,20000000],
  //startFilterPrice: false,
  strFilter: '',
	origin: {
		total_product: 0,
		total_page: 0
	},
	allowLoadMore: true,
	paramTracking: [],
	init: function() {	
		var that = this;
    that.renderSizeFilter();
    that.renderFormFilter();
    
		var paramSearch = window.location.search.replace('?','');
    var getPosition = localStorage.getItem('log_click');
    
		if(!$.isEmptyObject(paramUrl)){
      var no_render = false;
      if(getPosition == undefined || getPosition == null || (getPosition != undefined && getPosition != null && !JSON.parse(getPosition).hasOwnProperty(collection_id))){
        no_render = true;
      }
      
			if(paramUrl.hasOwnProperty('sort_by')){
				var count_param = Object.keys(paramUrl).length;
				if(count_param == 1){
					$('input[name="cfb-sort-input"][value="'+paramUrl.sort_by+'"]').prop('checked',true);
					if(getPosition == undefined || getPosition == null || (getPosition != undefined && getPosition != null && !JSON.parse(getPosition).hasOwnProperty(collection_id))) that.getCollectionItem(1,true);
					that.backUpSidebar();
				}
				else{
          that.creatFilterPrice();
					that.backUpSidebar();
					KG.Collection.stringFilter(no_render);
				}
			}
			else{
        that.creatFilterPrice();
				that.backUpSidebar();
				KG.Collection.stringFilter(no_render);
			}
		}
		else{
			if(getPosition == undefined || getPosition == null || (getPosition != undefined && getPosition != null && !JSON.parse(getPosition).hasOwnProperty(collection_id))) that.getCollectionItem(1);
      that.creatFilterPrice();
		}
    
		that.actionFilter();
		that.loadMore();
		that.renderCollectionInfo();
    that.sliderCollection();
    that.logPosition();
    KG.Index.sliderModule();
	},
  sliderCollection: function(){
    
    
  },
  renderSizeFilter: function(){
    var count_size = 1;
    $.each(collection_sizes, function(size, types){
      var type_check = types.split(',');
      var is_render = false;
      if( type_check.filter(tc => collection_types.includes(tc)).length > 0 ){
        $('#filter-size .checkbox-list').append(`
          <li>
            <input type="checkbox" id="data-size-p${count_size}" value="${size}" name="size-filter" data-size="(variantonhand_p2:product=${size})"/>
            <label for="data-size-p${count_size}">${size}</label>   
          </li>
        `);
        count_size++;
      } 
    });
    if($('#filter-size .checkbox-list').html().trim() != ''){
      $('#filter-size').parents('sidebar-box').removeClass('d-none');
    }
  },
  renderFormFilter: function(){
    var count_form = 1;
    $.each(collection_forms, function(form, types){
      var type_check = types.split(',');
      var is_render = false;
      if( type_check.filter(tc => collection_types.includes(tc)).length > 0 ){
        $('#filter-form .checkbox-list').append(`
          <li>
            <input type="checkbox" id="data-form-p${count_form}" value="${form}" name="form-filter" data-form="(tag:product=${form})"/>
            <label for="data-form-p${count_form}">${form}</label>   
          </li>
        `);
        count_form++;
      } 
    });
    if($('#filter-form .checkbox-list').html().trim() != ''){
      $('#filter-form').parents('sidebar-box').removeClass('d-none');
    }
  },
  creatFilterPrice: function(){
    var $slider = $("#slider-range");
    $slider.slider({
      range: true,
      min: 100000,
      max: 20000000,
      values: [ 100000, 20000000 ],
      slide: function( event, ui ) {
        $( "#amount-range" ).val( KG.Helper.moneyFormat(ui.values[ 0 ], "₫") + " - " + KG.Helper.moneyFormat(ui.values[ 1 ], "₫") );
        KG.Collection.picked.price = ui.values;
      }
    }).bind({
      slidestop: function(event){
        KG.Collection.stringFilter();
      },
      slidechange: function(event,ui){
        //debugger
        $( "#amount-range" ).val( KG.Helper.moneyFormat(ui.values[ 0 ], "₫") + " - " + KG.Helper.moneyFormat(ui.values[ 1 ], "₫") );
        KG.Collection.picked.price = ui.values;
      }
    });
    $( "#amount-range" ).val( KG.Helper.moneyFormat($( "#slider-range" ).slider( "values", 0 ), "₫") + " - " + KG.Helper.moneyFormat($( "#slider-range" ).slider( "values", 1 ), "₫") ); 

    $(document).on('change', '.wrapper-filter-price-input input',function(e){
      var minVal = $('.text-price-from').val().replaceAll(',', '').replaceAll('₫', '');
      var maxVal = $('.text-price-to').val().replaceAll(',', '').replaceAll('₫', '');
      $slider.slider("values", 0, minVal);
      $slider.slider("values", 1, maxVal);
      KG.Collection.stringFilter();
    });
  
  },
  renderCollectionInfo: function(){
		//Render Color
		var indexColor = 0;
		var color_arr = collection_tags.filter(tag => tag.indexOf("color:") > -1);
		$.each(color_arr,function(i,v){
			i = v.replace('color:','');
			var style_bg = 'style="background: '+color_code[i]+'"';
			if( i == 'Màu nude'){
				style_bg = 'style="background: url('+color_code[i]+') no-repeat; background-size: 150% 150%; background-position: center;"';
			}
			var html_filter = '<li><input type="checkbox" id="data-color-p' + indexColor + '" value="' + i + '" name="color-filter" data-color="(tag:product=*'+i+')" /><label data-value="'+i.toLowerCase()+'" for="data-color-p'+ indexColor +'" '+style_bg+'>'+i+'</label><span>'+i+'</span></li>';
			indexColor ++;
			$('.filter-color ul').append(html_filter);
		});
		
		// Check collapse
		$('.sidebar-box:not(.sidebar-default)').each(function(){
			if($(this).find('.checkbox-list li').length > 0){
				$(this).find('.sidebar-box-content').addClass('show');
				$(this).find('.sidebar-box-subtitle').attr('aria-expanded','true');
				$(this).removeClass('d-none');
			}
			else {
        $(this).find('.sidebar-box-content').removeClass('show');
        $(this).find('.sidebar-box-subtitle').attr('aria-expanded','false');
        $(this).attr('aria-expanded','false');
        $(this).addClass('d-none');
			}
		});

		//render MainBanner + cate + collection sub
		var htmlBanner = '';
		var htmlCate = '';
		if(data_render != '' ){
			if(data_render.hasOwnProperty('mainbanner') && data_render.mainbanner.length > 0){
        var html_banner = '', count_banner = 0;
        
        data_render.mainbanner.map((inf_banner,ind_banner) => {
          if(inf_banner.imgdesktop != ''){
            html_banner += `
              <div class="${data_render.mainbanner.length > 1 ? 'swiper-slide' : ''}">
                <a href="${inf_banner.link}" aria-label="${collection_title} ${ind_banner + 1}">
                  <picture >
                    <source srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-srcset="${inf_banner.imgdesktop}" media="(min-width: 992px)">
                    <source srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-srcset="${inf_banner.imgmobile != '' ? inf_banner.imgmobile : inf_banner.imgdesktop}" media="(max-width: 991px)">
                    <img class="img-default lazyload" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" 
                      data-src="${inf_banner.imgdesktop}" alt="${collection_title} ${ind_banner + 1}">
                  </picture>
                </a>
              </div>
            `;
            count_banner++;
          }
        });
        $('.back-origin').html(html_banner);
        if(count_banner > 1){
          $('.back-origin').removeClass("aspect-ratio");
          KG.Collection.slideBanner();
          $('#hero-banner .swiper-button-nav').removeClass('d-none'); 
        }
        
        /*
          $('#hero-banner .aspect-ratio picture source:nth-child(1)').attr('srcset',data_render.mainbanner[0].imgdesktop);
  				$('#hero-banner .aspect-ratio picture source:nth-child(1)').attr('data-srcset',data_render.mainbanner[0].imgdesktop);
          $('#hero-banner .aspect-ratio picture source:nth-child(2)').attr('srcset',data_render.mainbanner[0].imgmobile);
          $('#hero-banner .aspect-ratio picture source:nth-child(2)').attr('data-srcset',data_render.mainbanner[0].imgmobile);
  				$('#hero-banner .aspect-ratio img').attr('src',data_render.mainbanner[0].imgdesktop);
          $('#hero-banner .aspect-ratio img').attr('data-src',data_render.mainbanner[0].imgdesktop);
        */
        if(data_render.mainbanner[0].titlebanner.length > 0) {
          $('#hero-banner .hero-title').html(data_render.mainbanner[0].titlebanner).removeClass('d-none'); 
        }
        if(data_render.mainbanner[0].desc.length > 0) {
          $('#hero-banner .hero-desc').html(data_render.mainbanner[0].desc);
          $('#hero-banner .hero-action a span').html(data_render.mainbanner[0].btn);
          $('#hero-banner .hero-action a').attr('href',data_render.mainbanner[0].link);
          $('.hero-desc').removeClass('d-none');
          $('.hero-action').removeClass('d-none');
        }
			}
      else {
        $('#hero-banner').addClass('d-none');
      }
      
      if(data_render.hasOwnProperty('collection') && data_render.collection.length > 0){
        if(data_render.collection[0].show && data_render.collection[0].handle != ' '){
					var id1 = $('#js-render-coll-1 .swiper-container').attr('data-id');
      		var titleColl1 = $('#js-render-coll-1 .swiper-container').attr('data-title');
      		var urlColl1   = data_render.collection[0].handle;
          $('#js-render-coll-1 .s-heading a').attr('href',urlColl1);
          KG.Global.getItemSlide('pro-t1',id1,titleColl1,urlColl1,1,8,'#js-render-coll-1',function(){
            var swiper = new Swiper("#js-render-coll-1 .swiper-container", {
              loop: false,
              slidesPerView: 1.2,
              spaceBetween: 16,
              breakpoints: {
                735: {
                  slidesPerView: 2,
                },
                1024: {
                  slidesPerView: 4,
                },
                1460: {
                  slidesPerView: 4,
                }
              },
              /*navigation: {},*/
              navigation: false,
              scrollbar: {
                el: '#js-render-coll-1 .swiper-scrollbar',
                draggable: true
              }
            });
          });
				} 
				else {
					$('#js-render-coll-1').addClass('d-none'); 
				}
			}
      
      if(data_render.hasOwnProperty('shortdescription') && data_render.shortdescription.length > 0 && data_render.shortdescription[0].desc != ''){
  			$('.heading-wrapper .heading-inner--left div').html(data_render.shortdescription[0].desc).removeClass('d-none');
        if($('.content_origin').html().trim() != '') $('.btn-read').removeClass('d-none');
			} 

      /*
      if(data_render.hasOwnProperty('longdescription') && data_render.longdescription.length > 0 && data_render.longdescription[0].desc != ''){
        var decodedHTML = $('<div/>').html(data_render.longdescription[0].desc).text();
        $('.collection-desc .js-content').append(decodedHTML); 
        $('.collection-desc').removeClass('d-none');
      }
      */
		}
		else {
			$('#hero-banner').addClass('d-none');
      $('#js-render-coll-1').addClass('d-none');
		}	

		if($(window).width() < 1024) {
			$('.sortBy').removeClass('dropdown-menu').appendTo($('.sort-box .layered-filter--group').addClass('sortbyfilter'));
			// Event open sort on mobile and ipad
			$(document).on("click", '.collection-sort .box-title', function(e){
				$('body').toggleClass('lock-scroll');
				jQuery('.sort-wrapper--col').toggleClass('sort-visible');
				jQuery('.sort-wrapper--col .sort-box--scroll').css('height','250px');
				$('.refinement-section').toggleClass('has-filter');
			});
      
			// Event open filter on mobile and ipad
			$(document).on("click", '.collection-filter .box-title', function(e){
				$('body').toggleClass('lock-scroll');
				jQuery('.filter-wrapper--col').toggleClass('filter-visible');
				jQuery('.filter-wrapper--col .filter-box--scroll').css('max-height','40vh');
				jQuery('.filter-wrapper--col .filter-box--scroll').css('max-height','34vh');
				$('.refinement-section').toggleClass('has-filter');
			});
			
			$(document).on("click", '.js-sortby-mb-click', function(e){
				$( ".collection-sort .box-title" ).trigger( "click" );
			});
      
			$(document).on("click", '.js-filter-mb-click', function(e){
				$( ".collection-filter .box-title" ).trigger( "click" );
			});

			var t = $(".list-btn-mb");
			var e = $(".list-btn-mb").offset().top, 
					n = $(".mb-filter-wrapper").height();
      
			$(window).scroll(function() {
				if ($(document).scrollTop() > e){
					t.addClass("sticky-refinement-mobile");
					$(".results-section").css("padding-top", n + "px")
				}
				else {
					t.removeClass("sticky-refinement-mobile").removeAttr("style");
					t.removeClass("refinement-scroll-up");
					t.removeClass("refinement-scroll-down");
					$(".results-section").removeAttr("style");
				}
			});
		}
    else {
      $(document).on("click", '.btn-hide-filter', function(e){
        $('.collection-body').toggleClass('hide-filter');
        $('.open_filter').toggleClass('d-none');
      });

      $(document).on("click", '.open_filter', function(e){
        $('.collection-body').toggleClass('hide-filter');
        $('.open_filter').toggleClass('d-none');
      });
    }
	},
	getCollectionItem: function(page,filter){
		var idColl = $('#collection-page').attr('data-id');
		var sortby = default_sort != 'manual' ? $('.sortBy input[value="'+default_sort+'"]').attr('data-filter') : '(price:product=asc)';
    
		if($('.sortBy li.active').length > 0) sortby = $('.sortBy li.active input').attr('data-filter');

		var url_get = '/search.js?q=filter=((collectionid:product'+(idColl == '0'?'>=':'=')+idColl+'))&sortby='+sortby+'&include=metafields[product]&page='+(page != undefined?page:1)+'&limit='+num_per_page;
		if((KG.Collection.strFilter == '' && filter == undefined) || (filter != undefined && filter == false)){
			KG.Collection.strFilter = '';
			var check_pathname = window.location.pathname.split('/').reverse();
			if(check_pathname[0] == ''){
				check_pathname.splice(0,1);
			}

			check_pathname = check_pathname.reverse().join('/');
			url_get = check_pathname+'/products.json?limit='+num_per_page+'&page='+(page != undefined?page:1)+'&include=metafields[product]';
		}

		if(filter != undefined && filter && KG.Collection.strFilter != ''){
			url_get = '/search.js?q=filter='+KG.Collection.strFilter+'&include=metafields[product]'+'&page='+(page != undefined?page:1)+'&limit='+num_per_page;
		}

		$.get(url_get).done(function(data){
			if(KG.Collection.strFilter == '' && url_get.indexOf('search') > -1) {
				KG.Collection.strFilter = '(collectionid:product'+(idColl == '0'?'>=':'=')+idColl+')&sortby='+sortby;
			}
      
			if(data.total > 0 || (data.hasOwnProperty('products') && data.products.length > 0)){
				if($('#collection-page .grid-products').length == 0){
					$('#collection-page .results-section .ajax-render').html('<div class="grid-products"></div>');
				}

				/*
          if(((page != undefined && page == 1) || page == undefined) && url_get.indexOf('search') > -1){
  					$('.js-ResultCount span').html(data.total+' sản phẩm');
  				}
        */
        if(url_get.indexOf('search') > -1) $('.js-ResultCount span').html(data.total+' sản phẩm');
        else $('.js-ResultCount span').html(default_products+' sản phẩm');

				if(url_get.indexOf('search') > -1){

          if(page < Math.ceil(data.total / num_per_page)){
            $('.js-ResultCountCurrent').html(page * num_per_page);
          }
          else{
            $('.js-ResultCountCurrent').html(data.total);
          }
          
					$('#js-btn-more').attr('data-current',page).attr('data-pages',Math.ceil(data.total / num_per_page));
           
					if(KG.Collection.origin.total_product == 0 && KG.Collection.origin.total_page == 0){
						KG.Collection.origin.total_product = data.total;
						KG.Collection.origin.total_page = Math.ceil(data.total / num_per_page);
						if(KG.Collection.origin.total_page == page){
							$('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none');
						}
						else {
							$('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-none');
						}
					}
					else {
						if(KG.Collection.origin.total_page == page || Math.ceil(data.total / num_per_page) == 1 || Math.ceil(data.total / num_per_page) == page){
							$('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none');
						}
            else{
              $('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-none');
            }
					}
				}
				else{

          $('.js-ResultCountCurrent').html(page * num_per_page);
          
					$('#js-btn-more').attr('data-current',page).attr('data-pages',default_total);
					if(KG.Collection.origin.total_product == 0 && KG.Collection.origin.total_page == 0){
						KG.Collection.origin.total_product = default_products;
						KG.Collection.origin.total_page = default_total;
						if(KG.Collection.origin.total_page == page){
							$('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none');
						}
						else {
							$('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-none');
						}
					}	
					else {
						if(KG.Collection.origin.total_page == page){
							$('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none');
						}
            else{
              $('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-none');
            }
					}
				}

				var html_loop = '';
				var countbanner = page == 1 ? 0 : $('#collection-page .grid-products .pro-banner').length;

				data.products.map((item,ind) => {
					var number_loop = num_per_page*(page - 1) + (ind + 1);
					html_loop += `<div class="pro-tile pro-loop pro-t1 ${number_loop}">` + KG.Global.renderLoop(item,number_loop) + `</div>`;

					//render Subbanner
					if(data_render.hasOwnProperty('subbanner') && data_render.subbanner.length > 0 && (number_loop % 6 == 0) && countbanner < data_render.subbanner.length ){
						if(data_render.subbanner[0].show && data_render.subbanner[0].type == 'banner' && data_render.subbanner[0].banner != ''  ){
							html_loop += '<div class="pro-tile pro-banner '+number_loop+'"><div class="pro-loop--wrap"><img src="'+data_render.subbanner[0].banner+'" class="img-append"></div></div>';
							countbanner++;
						}
					}
				});
        $('.collection-body').removeClass('empty_body');
				if(page == 1) $('#collection-page .grid-products').html(html_loop);
				else $('#collection-page .grid-products').append(html_loop);
				KG.Collection.allowLoadMore = true;
				$('html,body').removeClass('open-overlay open-noscroll open-sidebar-filter');
        KG.Wishlist.initFavorites();
        setTimeout(function(){
          $('#collection-page .results-section .ajax-render').removeClass('filtering');
        },2000);
        //window.customerReview?.renderLayoutStarProductRating?.();
			}
			else{
				$('.js-ResultCount span').html('0 sản phẩm');
				$('#js-btn-more').attr('data-current',0).attr('data-pages',0)
        $('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none');
				$('.results-section .ajax-render').html('<div class="grid-empty alert-info">Chưa có sản phẩm nào trong danh mục này</div>');
        $('.collection-body').addClass('empty_body');
				KG.Collection.allowLoadMore = true;
				$('html,body').removeClass('open-overlay open-noscroll open-sidebar-filter');
			}

      if($('.layered-filter--tags .filter-tags.opened').length > 0) $('.layered-filter--tags-wrapper').removeClass('d-none');
    	else $('.layered-filter--tags-wrapper').addClass('d-none');
      
      //KG.Collection.startFilterPrice = false;
		});
	},
	stringFilter: function(no_render){
		var $this = this;
		var idColl = $('#collection-page').attr('data-id');
		var query = [];
		var change_url = [];
		
		if($(window).width() < 992) {
			$('body').removeClass('lock-scroll');
			$('.filter-wrapper--col').removeClass('filter-visible');
			$('.sort-wrapper--col').removeClass('sort-visible');
			$('.refinement-section').removeClass('has-filter');
		}

		/* Filter Vendor */
		if($('#filter-vendor input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-vendor input:checked').each(function(){
				var vendor = $(this).attr('data-vendor');
				temp.push(vendor);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-vendor').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('vendor='+picked.join(','));
      KG.Collection.picked.vendor = picked;
		}

    /* Filter Gender */
		if($('#filter-gender input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-gender input:checked').each(function(){
				var gender = $(this).attr('data-gender');
				temp.push(gender);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-gender').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('gender='+picked.join(','));
      KG.Collection.picked.gender = picked;
		}
    
    /* Filter Color */
		if($('#filter-color input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-color input:checked').each(function(){
				var color = $(this).val();
				temp.push('(variantonhand_p1:product='+color+')');
				picked.push(color);
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-color').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('color='+picked.join(','));
      KG.Collection.picked.color = picked;
		}
    
    /* Filter Type */
		if($('#filter-type input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-type input:checked').each(function(){
				var type = $(this).attr('data-type');
				temp.push(type);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-type').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('type='+picked.join(','));
      KG.Collection.picked.type = picked;
		}

		/* Filter Metal */
		if($('#filter-metal input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-metal input:checked').each(function(){
				var metal = $(this).attr('data-metal');
				temp.push(metal);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-metal').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('metal='+picked.join(','));
      KG.Collection.picked.metal = picked;
		}

		/* Filter Size */
		if($('#filter-size input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-size input:checked').each(function(){
				var size = $(this).attr('data-size');
				temp.push(size);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-size').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('size='+picked.join(','));
      KG.Collection.picked.size = picked;
		}

		/* Filter Price */
    if(KG.Collection.picked.hasOwnProperty('price') && $('#filter-price #amount-range').length > 0){
      var temp = KG.Collection.picked.price;
      query.push(`((price:product>=${temp[0]}) && (price:product<=${temp[1]}))`);
      var index_group = $('#filter-price').parents('.filter-group').index();
      $('.filter-tags:eq('+index_group+') b').text($('#amount-range').val());
      $('.filter-tags:eq('+index_group+')').addClass('opened');
      change_url.push('price='+temp.join(','));
		}
    
		/* Filter BST */
		if($('#filter-cate input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-cate input:checked').each(function(){
				var cate = $(this).val();
				temp.push('(tag:product=*'+cate+')');
				picked.push(cate);
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-cate').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('cate='+picked.join(','));
      KG.Collection.picked.cate = picked;
		}

    /* Filter Form */
		if($('#filter-form input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-form input:checked').each(function(){
				var form = $(this).attr('data-form');
				temp.push(form);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-form').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('form='+picked.join(','));
      KG.Collection.picked.form = picked;
		}

		if(query.length > 0){
			query = '(collectionid:product'+(idColl == '0'?'>=':'=')+idColl+')&&'+ query.join('&&');
			KG.Collection.strFilter = '(' + encodeURIComponent( query ) + ')';
		}
    else{
      $('.layered-filter--tags-wrapper').addClass('d-none');
    }

		/* Sort */
		if($('.sortBy li.active').length > 0){
			var idColl = $('#collection-page').attr('data-id');
			var sort = $('.sortBy li.active input').attr('data-filter');
			sort = 'sortby=' + sort;
			if (idColl == '0'){
				if(query.length == 0) KG.Collection.strFilter = '(collectionid:product>='+idColl+')';
			}
			else {
				if(query.length == 0) KG.Collection.strFilter = '(collectionid:product='+idColl+')';
			}
			KG.Collection.strFilter += '&' + sort;
			change_url.push('sort_by='+$('.sortBy li.active input').val());

			$('.sortbyfilter .sort-selected').text($('.sortBy li.active input').siblings('label').text());
			$('.filter-tags-sortby b').text($('.sortBy li.active input').siblings('label').text());
			$('.filter-tags-sortby').addClass('opened');
		}

		if(no_render == undefined || no_render){
      KG.Collection.getCollectionItem(1,query.length > 0 || $('.sortBy li.active').length > 0?true:false);

  		history.pushState(null, "", window.location.pathname+( change_url.length > 0 || $this.paramTracking.length > 0 ? '?'+change_url.join('&')+$this.paramTracking.join('&') : '') );
    }
    
		/* Save query string with key is string replace on URL. Target: After refresh with url can quick load result then backup options picked. */
		var logFilter = sessionStorage.getItem('query');
		logFilter = logFilter == null?{}:JSON.parse(logFilter);
		logFilter[change_url.join('&')] = KG.Collection.strFilter;
		sessionStorage.setItem('query',JSON.stringify(logFilter));

    if(no_render == undefined || no_render){
  		var x = $('.grid-head').offset().top;
  		KG.Helper.smoothScroll(x-140, 500);
    }
	},
	backUpSidebar: function(){
		var $this = this;
		$.each(paramUrl,function(key,value){

			if(key == 'metal'){
				var metals = paramUrl.metal.split(',');
				metals.map(metal => {
					$('#filter-metal input[value="'+decodeURIComponent(metal)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-metal').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.metal));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'color'){
				var colors = paramUrl.color.split(',');
				colors.map(color => {
					$('#filter-color input[value="'+decodeURIComponent(color)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-color').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.color));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'vendor'){
				var vendors = paramUrl.vendor.split(',');
				vendors.map(vendor => {
					$('#filter-vendor input[value="'+decodeURIComponent(vendor)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-vendor').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.vendor));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
      else if(key == 'type'){
				var types = paramUrl.type.split(',');
				types.map(type => {
					$('#filter-type input[value="'+decodeURIComponent(type)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-type').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.type));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'gender'){
				var genders = paramUrl.gender.split(',');
				genders.map(gender => {
					$('#filter-gender input[value="'+decodeURIComponent(gender)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-gender').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.gender));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'size'){
				var sizes = paramUrl.size.split(',');
				sizes.map(size => {
					$('#filter-size input[value="'+decodeURIComponent(size)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-size').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.size));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'price'){
				var prices = paramUrl.price.split(',');
        $("#slider-range").slider('values',[Number(prices[0]),Number(prices[1])]);
				var index_group = $('#filter-price').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.price));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
			else if(key == 'cate'){
				var cates = paramUrl.prm.split(',');
				cates.map(cate => {
					$('#filter-cate input[value="'+decodeURIComponent(cate)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-cate').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.cate));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}
      else if(key == 'form'){
				var forms = paramUrl.form.split(',');
				forms.map(form => {
					$('#filter-form input[value="'+decodeURIComponent(form)+'"]').prop('checked',true);
				});
				var index_group = $('#filter-form').parents('.filter-group').index();
				$('.filter-tags:eq('+index_group+') b').text(decodeURIComponent(paramUrl.form));
				$('.filter-tags:eq('+index_group+')').addClass('opened');
			}  
			else if(key == 'sort_by'){
				$('.sortBy li').removeClass('default');
				$('.sortBy li').removeClass('active');
				$('.sortBy input[value="'+paramUrl.sort_by+'"]').parent().addClass('active');
				var sort = $('.sortBy input[value="'+paramUrl.sort_by+'"] + label').text();

				$('.sortbyfilter .sort-selected').text(sort);
				
				$('.filter-tags-sortby b').text(sort);
				$('.filter-tags-sortby').addClass('opened');
			}
			else {
				$this.paramTracking.push(key+'='+value);
			}
		});

		if($('.layered-filter--tags .filter-tags.opened').length > 0) $('.layered-filter--tags-wrapper').removeClass('d-none');
	},
	actionFilter: function(){

    $('.wrapper-filter-price-input input').on('keypress', function(event) {
      if (!/[0-9]/.test(String.fromCharCode(event.which)) && !event.ctrlKey && !event.metaKey) {
        event.preventDefault();
      }
    });
    
    $('.wrapper-filter-price-input input').on('input', function() {
      var $this = $(this);
      var value = $this.val().replace(/\D/g, '');
      $this.val(value);
    });
    
    $('.wrapper-filter-price-input input').focus(function() {
      var $this = $(this);
      var value = $this.val().replaceAll(',', '').replaceAll('₫', '');
      $this.val(value);
    });
    
    $('.wrapper-filter-price-input input').blur(function() {
      var $this = $(this);
      var value = $this.val();
      if (value) {
        $this.val(Haravan.formatMoney(value * 100, shop.moneyFormat));
      }
    });
    
		/* Apply Filter Picked At Sidebar */
		$('.filter-controls .btn-apply-filter-js').on('click',function(){
      $('#collection-page .results-section .ajax-render').addClass('filtering');
  		KG.Collection.stringFilter();
		});
    
    /* Clear All Filter Picked At Sidebar */
		$('.filter-controls .btn-clear-filter-js').on('click',function(){
      $('#collection-page .results-section .ajax-render').addClass('filtering');
  		$('.filter-group input[type="checkbox"]').prop('checked',false);
			$('.layered-filter--tags .filter-tags').removeClass('opened');

			$('.sortBy input').prop('checked',false);
			$('.sortBy li').removeClass('active');
			$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
			$('.sortBy li input[value="manual"]').parents('li').addClass('default');

			KG.Collection.stringFilter();
			$('body').removeClass('open-overlay open-noscroll open-sidebar-filter');
		});

		/* Checklist */
		$(document).on('click','.checkbox-list li > input',function() {
			$(this).parent().toggleClass('active');
      $('#collection-page .results-section .ajax-render').addClass('filtering');
			if ($(window).width() >= 992) {
  			KG.Collection.stringFilter();
      }
      
			var indexTitle = $(this).parents('.filter-group').index();
			if ($(this).parents('.filter-group').find('input:checked').length > 0) {
				var textFilter = [];
				$(this).parents('.filter-group').find('input:checked').each(function() {
					var textVal = $(this).siblings('label').html();
					textFilter.push(textVal);
				});
				$('.filter-tags:eq(' + indexTitle + ') b').html(textFilter.join(', ')).parent().addClass('opened');
			} 
			else {
				$('.filter-tags:eq(' + indexTitle + ') b').html('').parent().removeClass('opened');
			}

			if ($('.checkbox-list li.active').length == 0) {
				$('.layered-filter--tags-wrapper').addClass('d-none');
			}
			else {
				$('.layered-filter--tags-wrapper').removeClass('d-none');
			}
		
		});
		
		/* Sort */
		$('input[name="cfb-sort-input"]').on('change',function(){
			$('.sortBy li').removeClass('default');
			$('.sortBy li').removeClass('active');
			$(this).parent().addClass('active');
      $('#collection-page .results-section .ajax-render').addClass('filtering');
			KG.Collection.stringFilter();
		});

		/* Clear filter item */
		$('.filter-tags-remove').on('click',function(){
			var ind_tag = $(this).parent().index();
			if($(this).parent().hasClass('filter-tags_sortby')){
				$('.sortBy li').removeClass('active');
				$('.sortBy li input').prop('checked',false);
				$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
				$('.sortBy li input[value="manual"]').parents('li').addClass('default');
			}
      else{
        var type_filter = $(this).parent().attr('data-title');
        if(type_filter == 'Giá'){
          $( "#slider-range" ).slider('values',[100000,20000000]);
          delete KG.Collection.picked.price;
        }
        else{
          $('.filter-group:eq('+ind_tag+') input:checked').click();
        }
      } 

      $('#collection-page .results-section .ajax-render').addClass('filtering');
			$(this).parent().removeClass('opened');
			KG.Collection.stringFilter();
		});

		/* Clear all filter item */
		$('.filter-tags.remove-all').on('click',function(){
      $('#collection-page .results-section .ajax-render').addClass('filtering');
			$('.filter-group input[type="checkbox"]').prop('checked',false);
			$('.layered-filter--tags .filter-tags').removeClass('opened');

			$('.sortBy input').prop('checked',false);
			$('.sortBy li').removeClass('active');
			$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
			$('.sortBy li input[value="manual"]').parents('li').addClass('default');

			KG.Collection.stringFilter();
			$('body').removeClass('open-overlay open-noscroll open-sidebar-filter');
		});
	},
	loadMore: function(){
		$(document).on('click','#js-btn-more',function(e){
			if($('.pro-loop').length > 0){
				if (KG.Collection.allowLoadMore ) {
					var total = Number($("#js-btn-more").attr('data-pages'));
					var current = Number($("#js-btn-more").attr('data-current'));
					if(current + 1 <= total){
						KG.Collection.allowLoadMore = false;
						if(KG.Collection.strFilter != ''){
							KG.Collection.getCollectionItem(current + 1,true);
						}
						else{
							KG.Collection.getCollectionItem(current + 1);
						}
					}
				}
			}
		});

    $(document).on('click','.btn-read',function(e){
      e.preventDefault();
      //$('.js-content').toggleClass('d-none');
      $('.content_origin').toggleClass('mask-height');
      $(this).toggleClass('clicked');
    });
	},
  logPosition: function(){

    var getPosition = localStorage.getItem('log_click');
    if(getPosition != null && getPosition != undefined){
      getPosition = JSON.parse(getPosition);

      if(getPosition.hasOwnProperty(collection_id)){
        if(!$.isEmptyObject(getPosition[collection_id].origin)){
          $('.grid-products').html(getPosition[collection_id].origin.html);
          $('.actions-wrapper--row').html(getPosition[collection_id].origin.html_paginate);
          KG.Collection.origin = getPosition[collection_id].origin.paginates;
          setTimeout(function(){
            $("html,body").animate({ scrollTop: getPosition[collection_id].origin.position - 98 }, 200);
          },800);
        }
        else{
          $('.grid-products').html(getPosition[collection_id].filter.html);
          $('.actions-wrapper--row').html(getPosition[collection_id].filter.html_paginate);
          KG.Collection.origin = getPosition[collection_id].filter.paginates;
          setTimeout(function(){
            $("html,body").animate({ scrollTop: getPosition[collection_id].filter.position - 98 }, 200);
          },800);
        }
      }
    }
    
    $(document).on('click','.pro-loop--wrap a', function(e){
      e.preventDefault();
      var url_target = $(this).attr('href');
      var current_page = $('#js-btn-more').attr('data-current');
      var getPosition = localStorage.getItem('log_click');

      if(getPosition != undefined && getPosition != null){
        getPosition = JSON.parse(getPosition);

        if(!getPosition.hasOwnProperty(collection_id)){
          getPosition = {};
          getPosition[collection_id] = {
            origin: {},
            filter: {}
          }
        }
        
        if(KG.Collection.strFilter == ''){
          getPosition[collection_id].origin = {
            current: current_page,
            html: $('.grid-products').html(),
            html_paginate: $('.actions-wrapper--row').html(),
            position: $(this).parents('.pro-loop').offset().top,
            paginates: KG.Collection.origin
          }
          getPosition[collection_id].filter = {};
        }
        else{
          getPosition[collection_id].filter = {
            current: current_page,
            html: $('.grid-products').html(),
            html_paginate: $('.actions-wrapper--row').html(),
            position: $(this).parents('.pro-loop').offset().top,
            paginates: KG.Collection.origin
          }
          getPosition[collection_id].origin = {};
        }
        var logPosition = getPosition;
      }
      else{
        var logPosition = {};
        logPosition[collection_id] = {
            origin: {},
            filter: {}
        };
        
        if(KG.Collection.strFilter == ''){
          logPosition[collection_id].origin = {
            current: current_page,
            html: $('.grid-products').html(),
            html_paginate: $('.actions-wrapper--row').html(),
            position: $(this).parents('.pro-loop').offset().top,
            paginates: KG.Collection.origin
          };
        }
        else{
          logPosition[collection_id].filter = {
            current: current_page,
            html: $('.grid-products').html(),
            html_paginate: $('.actions-wrapper--row').html(),
            position: $(this).parents('.pro-loop').offset().top,
            paginates: KG.Collection.origin
          };
        }
      }
      
      localStorage.setItem('log_click',JSON.stringify(logPosition));
      window.location.href = url_target;
    });
  },
  slideBanner: function(){
    var swiper = new Swiper("#hero-banner", {
			loop: false,
			slidesPerView: 1,
			spaceBetween: 1,
			autoplay: false,
			navigation: {
				nextEl: "#hero-banner .swiper-button-next",
				prevEl: "#hero-banner .swiper-button-prev",
			}
		});
  }
} 
KG.Account = {
  dataOrderGiftPE: {},
	dataOrderDiscountPE: {},
	totalPageOrder: 0,
	init: function(){
		var that = this;
    that.lowerCaseEmail();
		that.inputPassword();
		that.styleInputFormCustomer();
    
    if(template.indexOf('customers[login]') != -1 || template === 'customers[register]' || template === 'customers[reset_password]' || template === 'customers[activate_account]') {
      that.slideForms();   
      that.disabledFormEnter();
      that.loginAccount();
      that.createAccount();
      that.forgotAccount();
    }
    that.warningErrorLogin();
    
    if(template == 'customers[account]'){
			that.updateInfo();
		}
    if(template === 'customers[account].orders') {
			that.initHistory.init();
		}
    if(template === 'customers[addresses]'){
			that.initAddresses.init();
		}
    if(template === 'customers[order]'){
      that.initOrderDetail();
    }
	},
  lowerCaseEmail: function(){
		var $input = $('#signup-email');
		if($input.length > 0){
			var isValue = $input.val();
			isValue = isValue.toLowerCase();
			$input.val(isValue);

			$input.on('keyup change paste propertychange', function() {
				var value = $(this).val();
				value = value.toLowerCase();
				$input.val(value);
			});
		}
	},
  inputPassword: function(){
		$('.input-password').each(function(){
			var $this = $(this),
					val = $this.val();
			if(val != ''){
				$this.addClass('hasValue');
			}
			else{
				$this.removeClass('hasValue');
			}
		});
		$('.input-password').on('input', function(){
			var $this = $(this),
					val = $this.val();
			if(val != ''){
				$this.addClass('hasValue');
			}
			else{
				$this.removeClass('hasValue');
			}
		});
		$('.eyes-password').click(function(){
			var $this = $(this);
			if ($this.parent().find('input').attr('type') === 'password') {
				$this.parent().find('input').attr('type', 'text');
			} else {
				$this.parent().find('input').attr('type', 'password');
			}
		});
	},
  warningErrorLogin: function(){
		var url = window.location.href;
		if(url.indexOf('#recover') != -1){
			$('.redirect-btn[data-target=".forgotten-password"]').click();
		}
    
		$('.forgotten-password form').submit(function(){
			localStorage.setItem('forgotPass',true);
		});
    
		if(localStorage.getItem('forgotPass') != null){
			$('.redirect-btn[data-target=".forgotten-password"]').click();
			if($('.forgotten-password .errors').length == 0){
				$('.forgotten-password .form-desc').html(isText.text86);
				localStorage.removeItem('forgotPass');
			}
		}		
	},
  styleInputFormCustomer: function(){
		$(document).on('change', '.customer-actions__forms input', function(){
			$(this).parent().removeClass('error');
			$(this).parent().find('.text-error').html('');
		});
	},
  
  slideForms: function(){
		$('.customer-actions__forms').css('height', $('.login-n-sigup').height());
		$('.register-now a').on('click', function(){
			$('.forgotten-password').removeClass('show');
			$('.login-n-sigup').addClass('show');
			$('[data-bs-target="#signup"]').trigger('click');
		});
		
		$('.redirect-btn').on('click', function(e){
			e.preventDefault();
			var $target =  $($(this).data('target'));
			var id = $(this).data('target')
			if(id == '.forgotten-password'){
				history.replaceState(null, '', '#recover');
			}
			$('.customer-actions__forms').css('height', $target.height());
			$target.addClass('show').siblings().removeClass('show');
		});
		
		$('#change_login-phone').on('click',function(e){
			if (e.cancelable) e.preventDefault();
      $(this).parent().addClass('d-none');
			$('.login-phone').siblings('form').addClass('d-none');
			$('.login-phone').removeClass('d-none');
		});

		$('#change_login-email').on('click',function(e){
			if (e.cancelable) e.preventDefault();
			$('.login-phone').siblings('form').removeClass('d-none');
			$('.login-phone').addClass('d-none');
      $(this).parent().addClass('d-none');
		});
	},
  disabledFormEnter: function(){
		$('.customer-actions form').on('keyup keypress', function(e) {
			if (e.key === 'Enter') { 
				if (e.cancelable) e.preventDefault();
				return false;
			}
		});
	},
  loginAccount: function(){
		$('.btn-login-form-page').click(function(e){
			if (e.cancelable) e.preventDefault();
			var $form = $("#customer_login"),
					$email = $form.find('input[name="customer[email]"]').val(),
					$password = $form.find('input[name="customer[password]"]').val();
			
			$form.find('.error-status').addClass('d-none');
			
			if($email == ''){
				$form.find('input[name="customer[email]"]').parent().addClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html(isText.text155);
				return;
			}
			else if(!KG.Helper.validateEmail($email)){
				$form.find('input[name="customer[email]"]').parent().addClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html(isText.text156);
				return;
			}
			else {
				$form.find('input[name="customer[email]"]').parent().removeClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html('');
			}
			
			if($password == ''){
				$form.find('input[name="customer[password]"]').parent().addClass('error');
				$form.find('input[name="customer[password]"]').parent().find('.text-error').html(isText.text157);
				return;
			}
			else {
				$form.find('input[name="customer[password]"]').parent().removeClass('error');
				$form.find('input[name="customer[password]"]').parent().find('.text-error').html('');
			}

      $.ajax({  
        type: "POST",
        url: '/account/login',
        data: $form.serialize(),
        success:function(data){  
          var parsedResponse = $.parseHTML(data);
          var result = $(parsedResponse);
          if(result.find('#customer_login .errors').length > 0){
            var titleError = result.find('#customer_login .errors li').html();
            if(titleError.indexOf(isText.text164) != -1){
              $form.find('.error-status').html(isText.text164).removeClass('d-none');
            }
            if(titleError.indexOf(isText.text165) != -1){
              $form.find('.error-status').html(isText.text166).removeClass('d-none');
            }
            if(titleError.indexOf(isText.text168) != -1){
              $form.find('.error-status').html(isText.text168).removeClass('d-none');
            }
          }
          else {
            window.location = '/account?logged=true';
          }
        },  
        error: function(x,y){
          Swal.fire({
            icon: "info",
            title: "Thông báo",
            text: isText.text109,
            button: false,
            timer: 5000,
          }).then((result) => {
            location.reload(); 
          });
        }
      });
      
      /*
			grecaptcha.ready(function() {	
				grecaptcha.execute('6LdD18MUAAAAAHqKl3Avv8W-tREL6LangePxQLM-', {action: 'submit'}).then(function(token) {
					$.ajax({  
						type: "POST",
						url: '/account/login',
						data: {
							"customer": {
								"email": $email,
								"password": $password
							},
							"g-recaptcha-response": token
						},
						form_type: "customer_login",
						utf8: "✓",
						success:function(data){  
							var parsedResponse = $.parseHTML(data);
							var result = $(parsedResponse);
							if(result.find('#customer_login .errors').length > 0){
								var titleError = result.find('#customer_login .errors li').html();
								if(titleError.indexOf(isText.text164) != -1){
									$form.find('.error-status').html(isText.text164).removeClass('d-none');
								}
								if(titleError.indexOf(isText.text165) != -1){
									$form.find('.error-status').html(isText.text166).removeClass('d-none');
								}
								if(titleError.indexOf(isText.text168) != -1){
									$form.find('.error-status').html(isText.text168).removeClass('d-none');
								}
							}
							else {
								window.location = '/account?logged=true';
							}
						},  
						error: function(x,y){
              Swal.fire({
                icon: "info",
                title: "Thông báo",
                text: isText.text109,
                button: false,
                timer: 5000,
              }).then((result) => {
                location.reload(); 
              });
						}
					});
				});
			});
			*/
		});
	},
  createAccount: function(){
		var self = this;
    var checkagree2 = false;
    $(document).on('change','#input-agree1',function(){
			if($(this).is(':checked')) {
				$('.item-input-form .btn-register-form-page').prop('disabled', false).removeClass('disabled');
			} else {
				$('.item-input-form .btn-register-form-page').prop('disabled', true).addClass('disabled');
			}
		});
    
    $(document).on('change','#input-agree2',function(){
			if($(this).is(':checked')) {
				checkagree2 = true;
			} else {
				checkagree2 = false;
			}
		});
    
		$('.btn-register-form-page').click(function(e){
			if (e.cancelable) e.preventDefault();
			var $this = $(this),
					$form = $('#create_customer'),
					$lastName = $form.find('input[name="customer[last_name]"]').val(),
					$firstName = $form.find('input[name="customer[first_name]"]').val(),
					$email = $form.find('input[name="customer[email]"]').val(),
					$phone = $form.find('input[name="customer[phone]"]').val(),
					$password = $form.find('input[name="customer[password]"]').val(),
          $tags = $form.find('input[name="customer[tags]"]').val();

			$form.find('.error-status').addClass('d-none');
			$form.find('.success-status').addClass('d-none');

			if($lastName == ''){
				$form.find('input[name="customer[last_name]"]').parent().addClass('error');
				$form.find('input[name="customer[last_name]"]').parent().find('.text-error').html(isText.text201);
				return;
			}
			else {
				$form.find('input[name="customer[last_name]"]').parent().removeClass('error');
				$form.find('input[name="customer[last_name]"]').parent().find('.text-error').html('');
			}

			if($firstName == ''){
				$form.find('input[name="customer[first_name]"]').parent().addClass('error');
				$form.find('input[name="customer[first_name]"]').parent().find('.text-error').html(isText.text202);
				return;
			}
			else {
				$form.find('input[name="customer[first_name]"]').parent().removeClass('error');
				$form.find('input[name="customer[first_name]"]').parent().find('.text-error').html('');
			}

			if($email == ''){
				$form.find('input[name="customer[email]"]').parent().addClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html(isText.text155);
				return;
			}
			else if(!KG.Helper.validateEmail($email)){
				$form.find('input[name="customer[email]"]').parent().addClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html(isText.text156);
				return;
			}
			else {
				$form.find('input[name="customer[email]"]').parent().removeClass('error');
				$form.find('input[name="customer[email]"]').parent().find('.text-error').html('');
			}
      
			if($password == ''){
				$form.find('input[name="customer[password]"]').parent().addClass('error');
				$form.find('input[name="customer[password]"]').parent().find('.text-error').html(isText.text157);
				return;
			}
			else if($password != ''){
				if($password.length < 8){
					$form.find('input[name="customer[password]"]').parent().addClass('error');
					$form.find('input[name="customer[password]"]').parent().find('.text-error').html(isText.text163);
					return;
				}
				else {
					var validatePasssword = KG.Helper.checkPasswordValidation($password);
					if(validatePasssword != null){
						$form.find('input[name="customer[password]"]').parent().addClass('error');
						$form.find('input[name="customer[password]"]').parent().find('.text-error').html(validatePasssword);
						return;
					}
				}
			}
			else {
				$form.find('input[name="customer[password]"]').parent().removeClass('error');
				$form.find('input[name="customer[password]"]').parent().find('.text-error').html('');
			}

			$('.loading-ovl').addClass('open');
      
      if(checkagree2) {
  			KG.CustomerVerify.omniFormRegister($form, $lastName, $firstName, $email, '', $password , $tags);
      }
      else {
        KG.CustomerVerify.omniFormRegister($form, $lastName, $firstName, $email, '', $password , '');
      }
		});
	},
	forgotAccount: function(){
		var self = this;
		$('.btn-send-forgot-form-page').click(function(e){
			if (e.cancelable) e.preventDefault();
			
			var $this = $(this),
					$form = $('form[action="/account/recover"]'),
					$email = $form.find('input[name="email"]').val();

			$form.find('.error-status').addClass('d-none');

			if($email == ''){
				$form.find('input[name="email"]').parent().addClass('error');
				$form.find('input[name="email"]').parent().find('.text-error').html(isText.text155);
				return false;
			}
			else if(!KG.Helper.validateEmail($email)){
				$form.find('input[name="email"]').parent().addClass('error');
				$form.find('input[name="email"]').parent().find('.text-error').html(isText.text156);
				return false;
			}
			else {
				$form.find('input[name="email"]').parent().removeClass('error');
				$form.find('input[name="email"]').parent().find('.text-error').html('');
			}

      
      var site_key = $form.find('script:eq(0)').attr('src').split('render=')[1];
			grecaptcha.ready(function() {	
				grecaptcha.execute(site_key, {action: 'submit'}).then(function(token) {
          $form.find('input[name="g-recaptcha-response"]').val(token);
					$.ajax({  
						type: "POST",
						url: '/account/recover',
						data: $form.serialize(),
						success:function(data){  
              console.log(data);
							var parsedResponse = $.parseHTML(data);
							var result = $(parsedResponse);
              
							if(result.find('form[action="/account/recover"] .errors').length > 0){
								var titleError = result.find('form[action="/account/recover"] .errors li').html();
								if(titleError.indexOf(isText.text165) != -1){
									$form.find('.error-status').html(isText.text165).removeClass('d-none');
								}
								if(titleError.indexOf(isText.text170) != -1){
									$form.find('.error-status').html(isText.text170).removeClass('d-none');
								}
							}
							else {
								$form.find('.error-status').html(isText.text169).removeClass('d-none');
							}
						},  
						error: function(x,y){
              Swal.fire({
                icon: "info",
                title: "Thông báo",
                text: isText.text109,
                button: false,
                timer: 5000,
              }).then((result) => {
                //location.reload(); 
              });
						}
					});
				});
			});
		});
	},
  initHistory: {
		init: function(){
			var that = this;
			/*
      that.getOrders('history');
  		that.actions();
      */
		},
		getOrders: function(view){
			function renderHtmlOrderMini(data) {
				var status = '';
				var status_icon = '';
				var status_text = '';
				if(data.pos_order_status == 'pos_cancel' || data.pos_order_status == 'pos_cancel_refund' || data.pos_order_status == 'pos_cancel_restock'){
					status = 'cancel';
					status_icon = '';
					status_text = 'Đã huỷ';
				}
				else if(data.pos_order_status == 'pos_pending' || data.pos_order_status == 'pos_user_assigned' || data.pos_order_status == 'pos_stock_on_hand'){
					status = 'new';
					status_icon = '';
					status_text = 'Mới';
				} 
				else if(data.pos_order_status == 'pos_confirmed'){
					status = 'processing';
					status_icon = '';
					status_text = 'Đang xử lý';
				}
				else if(data.pos_order_status == 'pos_request_cancel'){
					status = 'processing';
					status_icon = '';
					status_text = 'Yêu cầu huỷ';
				}
				else if(data.pos_order_status == 'pos_store_assigned'){
					status = 'processing';
					status_icon = '';
					status_text = 'Chuyển chi nhánh';
				}
				else if(data.pos_order_status == 'pos_output'){
					status = 'processing';
					status_icon = '';
					status_text = 'Đã giao cho ĐVVC';
				}
				else if(data.pos_order_status == 'pos_delivering_nvc' || data.pos_order_status == 'pos_delivering_self'){
					status = 'delivering';
					status_icon = '';
					status_text = 'Đang vận chuyển';
					if (data.fulfillments.length > 0){
						status_text = data.fulfillments[0].carrier_status_name;
						status = data.fulfillments[0].carrier_status_code;
					}
				}
				else if(data.pos_order_status == 'pos_complete'){
					status = 'complete';
					status_icon = '';
					status_text = 'Giao hàng thành công';
				}

				var html = '';
				html += 		'<div class="order-item" data-search="'+data.order_number+'" data-stt="'+status+'">';
				html += 			'<div class="order-item-head">';
				html += 				'<div class="stt-order" data-stt="'+status+'">';
				html +=						status_icon+'<span>'+status_text+'</span>';
				html += 				'</div>';
				html += 				'<div class="code-order"><a href="/account/orders/'+data.cart_token+'">'+data.order_number+'</a></div>';
				html += 			'</div>';
				html += 			'<div class="order-item-body" data-count="'+data.line_items.length+'">';
				html += 			'<div class="order-scroll">';
				for(var j = 0; j < data.line_items.length; j++) {
					html += 				'<div class="order-item-line '+((j > 1) ? 'd-none' : '' )+'">';
					html += 						'<div class="img-line">';
					html += 							'<a href="/account/orders/'+data.cart_token+'">';
					if ( data.line_items[j].image == null ) { 
						html +=								'<img src="//theme.hstatic.net/200000636033/1001033735/14/no-image.jpg" alt="'+data.line_items[j].title+'" />';
					}
					else {
						html +=								'<img src="'+data.line_items[j].image.src+'" alt="'+data.line_items[j].title+'" />';
					}
					html +=								'</a>';
					html += 							'<div class="qty-line">x'+data.line_items[j].quantity+'</div>';
					html += 						'</div>';
					html += 				'</div>';
				}
				html += 			'</div>';
				html += 			'</div>';

				html += 					'<div class="order-item-foot text-right">';
				html += 						'<span>Tổng: </span>';
				html += 						'<span>'+ KG.Helper.moneyFormat(data.total_price,'₫') +'</span>';
				html += 					'</div>';
				html += 		'</div>';
				return html;	 
			};
			function renderHtmlOrder(data) {
				var status = '';
				var status_icon = '';
				var status_text = '';
				if(data.pos_order_status == 'pos_cancel' || data.pos_order_status == 'pos_cancel_refund' || data.pos_order_status == 'pos_cancel_restock'){
					status = 'cancel';
					status_icon = '';
					status_text = 'Đã huỷ';
				}
				else if(data.pos_order_status == 'pos_pending' || data.pos_order_status == 'pos_user_assigned' || data.pos_order_status == 'pos_stock_on_hand'){
					status = 'new';
					status_icon = '';
					status_text = 'Mới';
				} 
				else if(data.pos_order_status == 'pos_confirmed'){
					status = 'processing';
					status_icon = '';
					status_text = 'Đang xử lý';
				}
				else if(data.pos_order_status == 'pos_request_cancel'){
					status = 'processing';
					status_icon = '';
					status_text = 'Yêu cầu huỷ';
				}
				else if(data.pos_order_status == 'pos_store_assigned'){
					status = 'processing';
					status_icon = '';
					status_text = 'Chuyển chi nhánh';
				}
				else if(data.pos_order_status == 'pos_output'){
					status = 'processing';
					status_icon = '';
					status_text = 'Đã giao cho ĐVVC';
				}
				else if(data.pos_order_status == 'pos_delivering_nvc' || data.pos_order_status == 'pos_delivering_self'){
					status = 'delivering';
					status_icon = '';
					status_text = 'Đang vận chuyển';
					if (data.fulfillments.length > 0){
						status_text = data.fulfillments[0].carrier_status_name;
						status = data.fulfillments[0].carrier_status_code;
					}
				}
				else if(data.pos_order_status == 'pos_complete'){
					status = 'complete';
					status_icon = '';
					status_text = 'Giao hàng thành công';
				}
        var datebuy = data.created_at;
        var d = new Date(datebuy);
        var date = d.getDate() > 9 ? d.getDate() : '0' + d.getDate();
        var month = (d.getMonth()+1) > 9 ? (d.getMonth()+1) : '0' + (d.getMonth()+1);
        var finalDate = date+'/'+month+'/'+d.getFullYear()+ ', ' + ((d.getHours() == 0) ? '12' : d.getHours()) + ':' + d.getMinutes();

				var html = '';
        html += '<div class="history-item" data-search="'+data.order_number+'" data-stt="'+status+'">';
        html += '  <div class="history-item-head">';
        html += '    <div class="left">';
        html += '      <div class="title">';
        html += '        <span>Đơn hàng </span><span class="code-order">#'+data.order_number+'</span>';
        html += '      </div>';
        html += '      <div class="date">Đặt ngày '+finalDate+'</div>';
        html += '    </div>';
        html += '    <div class="right">';
        html += '      <div class="view-order">';
        html += '       <a href="/account/orders/'+data.cart_token+'" data-id="'+data._id+'" title="Xem chi tiết">CHI TIẾT<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.5 15L12.5 10L7.5 5" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/></svg></a>';
        html += '    </div>';
        html += '   </div>';
        html += '  </div>';
        html += '  <div class="history-item-foot">';
        html += '    <div class="stt-order" data-stt="new"><span>Trạng thái đơn hàng</span><span>'+status_text+'</span></div>';
        html += '    <div class="total-order">';
        html += '      <span>Tổng thanh toán ('+data.line_items.length+' món ) </span>';
        html += '      <span>'+ KG.Helper.moneyFormat(data.total_price,'₫') +'</span>';
        html += '    </div>';
        html += '  </div>';
        html += '</div>';
				return html;	 
			};
			function renderHtmlEmpty(){
				var htmlEmpty = '<div class="empty-products empty-orders">';
        htmlEmpty += 			 '<div class="action-btn">';
        htmlEmpty += 			  '<a class="btn " href="/">ĐẾN CỬA HÀNG NGAY</a>';
        htmlEmpty += 			 '</div>';
				htmlEmpty += 		'</div>';
				return htmlEmpty;	 
			} 
			function loadOrders(page){
				if (view == 'profile'){
					var limit = 2;
				}
				else {
					var limit = 10;
				}
				var paramUrl =  '/apps/kges/auth/api/orders/listbycustomer?page='+page+'&limit='+limit;
				$.get(paramUrl).done(function(result){	
					if (result.total > 0){
						$('.js-render-history').html('');

						if (view == 'profile'){
							var html = '<div class="order-title">Đơn hàng gần đây</div>';
							for (var i=0, l=result.items.length; i<l; i++){
								html += renderHtmlOrderMini(result.items[i]);
							}
							$('.js-render-history').html(html);
						}
						else {
							KG.Account.totalPageOrder = Math.ceil(result.total / limit);
							if(page < KG.Account.totalPageOrder){
								$('.loadmore-history').find('span').html(result.total - page * limit);
								$('.loadmore-history').find('button').attr('data-current',page+1);
								$('.loadmore-history').removeClass('d-none');
							}
							else{
								$('.loadmore-history').addClass('d-none');
							}
							$('.status-list .status-item[data-stt="all"] .count').html('('+result.total+')');
							for (var i=0, l=result.items.length; i<l; i++){
								$('.js-render-history').append(renderHtmlOrder(result.items[i]));
							}
						}
					}
					else {
						$('.js-render-history').html('');
            $('.account-page-title').append('<p>Bạn chưa có đơn hàng nào.</p>');
						$('.js-render-history').append(renderHtmlEmpty);
					}
				});
			}
			loadOrders(1);
			
			$(document).on('click','#btn-loadmore',function(e){
				e.preventDefault();
				var page = Number($(this).attr('data-current'));
				loadOrders(page);
			});
		},
		actions: function(){
			$(document).on('click','.more-line',function(e){
				e.preventDefault();
				var count = $(this).find('span').html();
				if ($(this).parents('.history-item').find('.history-item-body').hasClass('opened')) {		
					$(this).removeClass('btn-closemore').addClass('btn-viewmore').html('Xem thêm <span>'+count+'</span> sản phẩm');
					$(this).parents('.history-item').find('.history-item-line:not(:nth-child(1)):not(:nth-child(2))').addClass('d-none');
					$(this).parents('.history-item').find('.history-item-body').removeClass('opened');
				} 
				else {
					$(this).parents('.history-item').find('.history-item-body').addClass('opened');
					$(this).removeClass('btn-viewmore').addClass('btn-closemore').html('Ẩn bớt <span>'+count+'</span> sản phẩm');
					$(this).parents('.history-item').find('.history-item-line').removeClass('d-none');
				}
			}); 
		}
	},
	initOrderDetail: function(){
		function renderTime(dt){
			var time = new Date(dt);
			var _date = (time.getDate() < 10 ? ('0' + time.getDate()):time.getDate());
			var _month = time.getMonth()+1;
			_month = _month < 10 ? ('0' + _month): _month;
			
			time  = (time.getHours() < 10 ? ('0' + time.getHours()): time.getHours()) + ':' + (time.getMinutes() < 10 ? '0' + time.getMinutes() : time.getMinutes()) + ' - '+_date+'.'+_month+'.'+time.getFullYear();
			
			return time;
		};
		function renderHtmlTracking(data){
			var icon_x = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><mask id="path-1-inside-1" fill="white"><path d="M5.47027 6L0.116464 0.646198C-0.236691 0.293042 0.293042 -0.236691 0.646198 0.116464L6 5.47027L11.3538 0.116464C11.707 -0.236691 12.2367 0.293042 11.8835 0.646198L6.52973 6L11.8835 11.3538C12.2367 11.707 11.707 12.2367 11.3538 11.8835L6 6.52973L0.646198 11.8835C0.293042 12.2367 -0.236691 11.707 0.116464 11.3538L5.47027 6Z"></path></mask><path d="M5.47027 6L6.17737 6.70711L6.88448 6L6.17737 5.29289L5.47027 6ZM0.116464 0.646198L-0.590642 1.3533L0.116464 0.646198ZM0.646198 0.116464L1.3533 -0.590642L0.646198 0.116464ZM6 5.47027L5.29289 6.17737L6 6.88448L6.70711 6.17737L6 5.47027ZM11.3538 0.116464L10.6467 -0.590642V-0.590642L11.3538 0.116464ZM11.8835 0.646198L12.5906 1.3533V1.3533L11.8835 0.646198ZM6.52973 6L5.82263 5.29289L5.11552 6L5.82263 6.70711L6.52973 6ZM11.8835 11.3538L12.5906 10.6467L11.8835 11.3538ZM11.3538 11.8835L10.6467 12.5906L11.3538 11.8835ZM6 6.52973L6.70711 5.82263L6 5.11552L5.29289 5.82263L6 6.52973ZM0.646198 11.8835L1.3533 12.5906H1.3533L0.646198 11.8835ZM0.116464 11.3538L-0.590642 10.6467H-0.590642L0.116464 11.3538ZM6.17737 5.29289L0.823571 -0.0609092L-0.590642 1.3533L4.76316 6.70711L6.17737 5.29289ZM0.823571 -0.0609092C0.927161 0.0426804 1.01094 0.218208 0.99886 0.423499C0.98823 0.604207 0.908018 0.739124 0.823571 0.823571C0.739124 0.908018 0.604207 0.98823 0.423499 0.99886C0.218208 1.01094 0.0426804 0.927161 -0.0609092 0.823571L1.3533 -0.590642C1.07314 -0.87081 0.698959 -1.0208 0.306055 -0.997689C-0.0622675 -0.976023 -0.373762 -0.807523 -0.590642 -0.590642C-0.807523 -0.373762 -0.976023 -0.0622675 -0.997689 0.306055C-1.0208 0.698959 -0.87081 1.07314 -0.590642 1.3533L0.823571 -0.0609092ZM-0.0609092 0.823571L5.29289 6.17737L6.70711 4.76316L1.3533 -0.590642L-0.0609092 0.823571ZM6.70711 6.17737L12.0609 0.823571L10.6467 -0.590642L5.29289 4.76316L6.70711 6.17737ZM12.0609 0.823571C11.9573 0.927161 11.7818 1.01094 11.5765 0.99886C11.3958 0.98823 11.2609 0.908019 11.1764 0.823572C11.092 0.739125 11.0118 0.604208 11.0011 0.423499C10.9891 0.218209 11.0728 0.0426806 11.1764 -0.0609092L12.5906 1.3533C12.8708 1.07314 13.0208 0.698959 12.9977 0.306054C12.976 -0.0622683 12.8075 -0.373763 12.5906 -0.590643C12.3738 -0.807523 12.0623 -0.976023 11.6939 -0.997689C11.301 -1.0208 10.9269 -0.87081 10.6467 -0.590642L12.0609 0.823571ZM11.1764 -0.0609093L5.82263 5.29289L7.23684 6.70711L12.5906 1.3533L11.1764 -0.0609093ZM5.82263 6.70711L11.1764 12.0609L12.5906 10.6467L7.23684 5.29289L5.82263 6.70711ZM11.1764 12.0609C11.0728 11.9573 10.9891 11.7818 11.0011 11.5765C11.0118 11.3958 11.092 11.2609 11.1764 11.1764C11.2609 11.092 11.3958 11.0118 11.5765 11.0011C11.7818 10.9891 11.9573 11.0728 12.0609 11.1764L10.6467 12.5906C10.9269 12.8708 11.301 13.0208 11.6939 12.9977C12.0623 12.976 12.3738 12.8075 12.5906 12.5906C12.8075 12.3738 12.976 12.0623 12.9977 11.6939C13.0208 11.301 12.8708 10.9269 12.5906 10.6467L11.1764 12.0609ZM12.0609 11.1764L6.70711 5.82263L5.29289 7.23684L10.6467 12.5906L12.0609 11.1764ZM5.29289 5.82263L-0.0609093 11.1764L1.3533 12.5906L6.70711 7.23684L5.29289 5.82263ZM-0.0609092 11.1764C0.0426806 11.0728 0.218209 10.9891 0.423499 11.0011C0.604208 11.0118 0.739125 11.092 0.823572 11.1764C0.908019 11.2609 0.98823 11.3958 0.99886 11.5765C1.01094 11.7818 0.927161 11.9573 0.823571 12.0609L-0.590642 10.6467C-0.87081 10.9269 -1.0208 11.301 -0.997689 11.6939C-0.976023 12.0623 -0.807523 12.3738 -0.590643 12.5906C-0.373763 12.8075 -0.0622683 12.976 0.306054 12.9977C0.698959 13.0208 1.07314 12.8708 1.3533 12.5906L-0.0609092 11.1764ZM0.823571 12.0609L6.17737 6.70711L4.76316 5.29289L-0.590642 10.6467L0.823571 12.0609Z" mask="url(#path-1-inside-1)"></path></svg>';
			var icon_check = '<svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.2744 0.47078L6.69658 10.1165L2.72738 6.11917C2.42795 5.81773 2.02188 5.64842 1.59851 5.6485C1.17513 5.64857 0.769121 5.81802 0.469801 6.11957C0.170482 6.42112 0.00236659 6.83007 0.00244143 7.25645C0.00251627 7.68283 0.170775 8.09171 0.470201 8.39315L5.56799 13.5271C5.86735 13.8285 6.2733 13.9978 6.69658 13.9978C7.11986 13.9978 7.52582 13.8285 7.82517 13.5271L18.534 2.74155C18.8247 2.43835 18.9856 2.03226 18.982 1.61075C18.9784 1.18923 18.8105 0.786018 18.5145 0.487952C18.2186 0.189885 17.8182 0.0208135 17.3996 0.0171506C16.9811 0.0134878 16.5779 0.175527 16.2768 0.468369L16.2744 0.47078Z" fill="white"/></svg>';

			var htmlFinal = '<div class="box" id="order-box-0">';
			var htmlHead = '<div class="tracking-w d-none">';
			htmlHead += 		'<ul class="tracking-head">';
			htmlHead += 			'<li class="tracking_quantity"><span>'+data.line_items.length+'</span> Sản phẩm</li>';
			htmlHead += 			'<li class="tracking_orderid">Đơn hàng - <span>'+data.name+'</span></li>';
			htmlHead += 			'<li class="tracking_date_buy">Ngày mua: <span>'+renderTime(data.created_at)+'</span></li>';
			htmlHead += 			'<li class="tracking_phone d-none">Số điện thoại: <span>'+data.customer.phone+'</span></li>';
			htmlHead += 		'</ul>';
			htmlHead += 	 '</div>';

			var htmlBody = '<div class="collapse-box__body">';
			htmlBody += 		'<div class="order-tracking" id="odt-0">';
			htmlBody += 			'<div class="order-tracking-wrap">';
			if(data.pos_order_status == 'pos_cancel'){
				htmlBody += 			'<div class="ort-block active" id="ort-canceled">';
				htmlBody += 				'<div class="ort-block-circle">';
				htmlBody += 					'<svg viewBox="0 0 42 50" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40"><path d="M27.7932185,-1.42108547e-13 C31.5753806,-1.42108547e-13 34.6520518,3.07705189 34.6520518,6.85921402 L34.6520518,6.85921402 L34.6520518,30.8207756 C38.5769872,32.0920298 41.4233174,35.7820555 41.4233174,40.1254122 C41.4233174,45.5165351 37.0376998,49.9029141 31.6465768,49.9029141 C27.3332978,49.9029141 23.6638315,47.0946568 22.3689721,43.2108401 L22.3689721,43.2108401 L6.8588333,43.2108401 C3.07667119,43.2108401 0,40.1337882 0,36.3512454 L0,36.3512454 L0,6.85921402 C0,3.07705189 3.07667119,-1.42108547e-13 6.8588333,-1.42108547e-13 L6.8588333,-1.42108547e-13 L27.7932185,-1.42108547e-13 Z M31.6465768,33.2715283 C27.8678413,33.2715283 24.7938352,36.3459152 24.7938352,40.1254122 C24.7938352,43.9041477 27.8678413,46.9789152 31.6465768,46.9789152 C35.4253124,46.9789152 38.4993185,43.9041477 38.4993185,40.1254122 C38.4993185,36.3459152 35.4253124,33.2715283 31.6465768,33.2715283 Z M33.1146679,36.5895817 C33.6853808,36.0188689 34.6113137,36.0188689 35.1820266,36.5895817 C35.7531201,37.1606753 35.7531201,38.0862275 35.1820266,38.6569404 L35.1820266,38.6569404 L33.7139355,40.1250315 L35.1820266,41.5931226 C35.7527393,42.164216 35.7527393,43.0897683 35.1820266,43.6608618 C34.8964798,43.9464086 34.5222231,44.0891819 34.1483473,44.0891819 C33.7740906,44.0891819 33.3998341,43.9464086 33.1146679,43.6608618 L33.1146679,43.6608618 L31.6465768,42.1927707 L30.1784857,43.6608618 C29.892939,43.9464086 29.5186824,44.0891819 29.1448065,44.0891819 C28.7705499,44.0891819 28.3962932,43.9464086 28.1107464,43.6608618 C27.5400337,43.0897683 27.5400337,42.164216 28.1107464,41.5931226 L28.1107464,41.5931226 L29.5788375,40.1250315 L28.1107464,38.6569404 C27.5400337,38.0862275 27.5400337,37.1602946 28.1107464,36.5895817 C28.68184,36.0188689 29.607773,36.0188689 30.1784857,36.5895817 L30.1784857,36.5895817 L31.6465768,38.0576728 L33.1146679,36.5895817 Z M27.7932185,2.92399887 L6.8588333,2.92399887 C4.68905861,2.92399887 2.92399887,4.68943931 2.92399887,6.85921402 L2.92399887,6.85921402 L2.92399887,36.3512454 C2.92399887,38.5214007 4.68905861,40.2868413 6.8588333,40.2868413 L6.8588333,40.2868413 L21.87174,40.2868413 C21.8709785,40.2327777 21.8698363,40.1790949 21.8698363,40.1254122 C21.8698363,34.7335277 26.2554539,30.3475294 31.6465768,30.3475294 C31.6739893,30.3475294 31.7010211,30.3482909 31.7280529,30.3482909 L31.7280529,30.3482909 L31.7280529,6.85921402 C31.7280529,4.68943931 29.9629932,2.92399887 27.7932185,2.92399887 L27.7932185,2.92399887 Z M12.3405697,34.6337768 C13.148096,34.6337768 13.8025691,35.28825 13.8025691,36.0957762 C13.8025691,36.9029217 13.148096,37.5577757 12.3405697,37.5577757 L12.3405697,37.5577757 L7.5814569,37.5577757 C6.7743114,37.5577757 6.1194575,36.9029217 6.1194575,36.0957762 C6.1194575,35.28825 6.7743114,34.6337768 7.5814569,34.6337768 L7.5814569,34.6337768 L12.3405697,34.6337768 Z M27.1768181,15.8543178 C27.9843445,15.8543178 28.6388176,16.508791 28.6388176,17.3163172 C28.6388176,18.1234628 27.9843445,18.7783167 27.1768181,18.7783167 L27.1768181,18.7783167 L7.5814569,18.7783167 C6.7743114,18.7783167 6.1194575,18.1234628 6.1194575,17.3163172 C6.1194575,16.508791 6.7743114,15.8543178 7.5814569,15.8543178 L7.5814569,15.8543178 L27.1768181,15.8543178 Z M24.3590427,10.8366901 C25.1665689,10.8366901 25.8210421,11.491544 25.8210421,12.2986896 C25.8210421,13.1062158 25.1665689,13.760689 24.3590427,13.760689 L24.3590427,13.760689 L7.5814569,13.760689 C6.7739307,13.760689 6.1194575,13.1062158 6.1194575,12.2986896 C6.1194575,11.491544 6.7743114,10.8366901 7.5814569,10.8366901 L7.5814569,10.8366901 L24.3590427,10.8366901 Z M27.2830416,5.81944305 C28.0905678,5.81944305 28.745041,6.47391625 28.745041,7.28144248 C28.745041,8.088588 28.0905678,8.74344192 27.2830416,8.74344192 L27.2830416,8.74344192 L7.5814569,8.74344192 C6.7743114,8.74344192 6.1194575,8.088588 6.1194575,7.28144248 C6.1194575,6.47391625 6.7743114,5.81944305 7.5814569,5.81944305 L7.5814569,5.81944305 L27.2830416,5.81944305 Z"></path></svg>';
				htmlBody += 					'<span>'+icon_x+'</span>';
				htmlBody += 				'</div>';
				htmlBody += 				'<div class="ort-block-title">Huỷ</div>';
				htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_cancel_at) +'</div>';
				htmlBody += 			'</div>';
			}
			else{
				var aStatus = ['','','','',''];
				var stepPrev = ['','','','',''];
				var delivery_cancel = '';
				var delivery_time = '';
				var delivery_status = 'Đang giao';
				var complete_status = 'Đã nhận hàng';			
				var complete_time = '';			
				
				if(data.pos_order_status == 'pos_pending' || data.pos_order_status == 'pos_user_assigned'){
					aStatus[0] = 'active';
				}
				if(data.pos_order_status == 'pos_confirmed'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					stepPrev[0] = 'checked';
				}
				if(data.pos_order_status == 'pos_request_cancel'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					stepPrev[0] = 'checked';
				}
				if(data.pos_order_status == 'pos_store_assigned' || data.pos_order_status == 'pos_output' || data.pos_order_status == 'pos_stock_on_hand' || data.pos_order_status == 'pos_out_of_stock'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					aStatus[2] = 'active';
					stepPrev[0] = 'checked';
					stepPrev[1] = 'checked';
				}
				
				if(data.fulfillments.length > 0){
					delivery_status = data.fulfillments[0].carrier_status_name;
					delivery_time = renderTime(data.fulfillments[0].delivered_date);
				}
				if(data.pos_order_status == 'pos_delivering_nvc' || data.pos_order_status == 'pos_delivering_self'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					aStatus[2] = 'active';
					aStatus[3] = 'active';
					stepPrev[0] = 'checked';
					stepPrev[1] = 'checked';
					stepPrev[2] = 'checked';
				}
				if(data.pos_order_status == 'pos_delivering_self'){
					
					if(data.fulfillments[0].carrier_status_code == 'delivering'){
						delivery_time = renderTime(data.fulfillments[0].delivering_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'readytopick') {
						delivery_time = renderTime(data.fulfillments[0].ready_to_pick_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'pickupfail') {
						delivery_time = renderTime(data.fulfillments[0].created_at); // lấy tạm, 10/4 mới build
						delivery_status = 'Chờ lấy hàng';
					}
					else if (data.fulfillments[0].carrier_status_code == 'delivered'){
						delivery_time = renderTime(data.fulfillments[0].delivered_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'waitingforreturn'){
						delivery_time = renderTime(data.fulfillments[0].waiting_for_return_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'return'){
						delivery_time = renderTime(data.fulfillments[0].return_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'picking'){
						delivery_time = renderTime(data.fulfillments[0].picking_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'notmeetcustomer'){
						delivery_time = renderTime(data.fulfillments[0].not_meet_customer_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'cancel'){
						delivery_time = renderTime(data.fulfillments[0].cancel_date);
						delivery_cancel = ' delivery_cancel';
						delivery_status = 'Huỷ giao hàng';
					}
					else {
						delivery_time = renderTime(data.pos_delivering_self_at);
					}
				}
				if(data.pos_order_status == 'pos_delivering_nvc'){
					if(data.fulfillments[0].carrier_status_code == 'delivering'){
						delivery_time = renderTime(data.fulfillments[0].delivering_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'readytopick') {
						delivery_time = renderTime(data.fulfillments[0].ready_to_pick_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'pickupfail') {
						delivery_time = renderTime(data.fulfillments[0].created_at); // lấy tạm, 10/4 mới build
						delivery_status = 'Chờ lấy hàng';
					}
					else if (data.fulfillments[0].carrier_status_code == 'delivered'){
						delivery_time = renderTime(data.fulfillments[0].delivered_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'waitingforreturn'){
						delivery_time = renderTime(data.fulfillments[0].waiting_for_return_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'return'){
						delivery_time = renderTime(data.fulfillments[0].return_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'picking'){
						delivery_time = renderTime(data.fulfillments[0].picking_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'notmeetcustomer'){
						delivery_time = renderTime(data.fulfillments[0].not_meet_customer_date);
					}
					else if (data.fulfillments[0].carrier_status_code == 'cancel'){
						delivery_time = renderTime(data.fulfillments[0].cancel_date);
						delivery_cancel = ' delivery_cancel';
						delivery_status = 'Huỷ giao hàng';
					}
					else {
						delivery_time = renderTime(data.pos_delivering_nvc_at);
					}
				}
				if(data.pos_order_status == 'pos_cancel_restock'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					aStatus[2] = 'active';
					aStatus[3] = 'active';
					stepPrev[0] = 'checked';
					stepPrev[1] = 'checked';
					stepPrev[2] = 'checked';
					delivery_cancel = ' delivery_cancel';
					delivery_time =  renderTime(data.pos_cancel_restock_at);
					if (data.fulfillments[0].carrier_status_code == 'cancel'){
						delivery_status = 'Huỷ giao hàng';
					}
					else {
						delivery_status = 'Huỷ - Trả hàng';
					}
				}
				if(data.pos_order_status == 'pos_complete'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					aStatus[2] = 'active';
					aStatus[3] = 'active';
					aStatus[4] = 'active';	
					stepPrev[0] = 'checked';
					stepPrev[1] = 'checked';
					stepPrev[2] = 'checked';
					stepPrev[3] = 'checked';
					complete_status = 'Đã nhận hàng';
					complete_time = renderTime(data.pos_complete_at);			
				}
				if(data.pos_order_status == 'pos_cancel_refund'){
					aStatus[0] = 'active';
					aStatus[1] = 'active';
					aStatus[2] = 'active';
					aStatus[3] = 'active';
					aStatus[4] = 'active';	
					stepPrev[0] = 'checked';
					stepPrev[1] = 'checked';
					stepPrev[2] = 'checked';
					stepPrev[3] = 'checked';
					complete_status = 'Huỷ - Trả hàng';
					complete_time = renderTime(data.pos_cancel_refund_at);			
				}				
				
				htmlBody += 			'<div class="ort-block '+aStatus[0] + ' ' + stepPrev[0] +'" id="ort-ordered">';
				htmlBody += 				'<div class="ort-block-circle">';
				htmlBody += 					'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M422.052 56.069h-75.026V46.035c0-9.925-8.075-18-18-18h-31.558C290.783 11.252 274.537 0 256 0c-18.536 0-34.783 11.252-41.469 28.035h-31.558c-9.925 0-18 8.075-18 18V56.07H89.948c-16.303 0-29.565 13.263-29.565 29.565v396.8c0 16.303 13.263 29.565 29.565 29.565h332.104c16.303 0 29.565-13.263 29.565-29.565v-396.8c0-16.303-13.263-29.566-29.565-29.566zM180.974 46.035c0-1.084.916-2 2-2h37.389a8 8 0 0 0 7.777-6.124C231.251 25.01 242.708 16 256 16s24.749 9.01 27.859 21.91a8.001 8.001 0 0 0 7.777 6.125h37.389c1.084 0 2 .916 2 2v36.07c0 1.084-.916 2-2 2H182.974c-1.084 0-2-.916-2-2zm254.643 436.4c0 7.48-6.085 13.565-13.565 13.565H89.948c-7.48 0-13.565-6.085-13.565-13.565v-396.8c0-7.48 6.085-13.565 13.565-13.565h75.025v10.036c0 9.925 8.075 18 18 18h146.052c9.925 0 18-8.075 18-18V72.069h75.026c7.48 0 13.565 6.085 13.565 13.565v396.801zM236.596 201.734a8 8 0 0 1 8-8h69a8 8 0 0 1 0 16h-69a8 8 0 0 1-8-8zm122-33.5a8 8 0 0 1-8 8h-106a8 8 0 0 1 0-16h106a8 8 0 0 1 8 8zm0 116.545a8 8 0 0 1-8 8h-106a8 8 0 0 1 0-16h106c4.418.001 8 3.582 8 8zm-122 33.501a8 8 0 0 1 8-8h69a8 8 0 0 1 0 16h-69a8 8 0 0 1-8-8zm122 83.045a8 8 0 0 1-8 8h-106a8 8 0 0 1 0-16h106a8 8 0 0 1 8 8zm-37 33.5a8 8 0 0 1-8 8h-69a8 8 0 0 1 0-16h69c4.418.001 8 3.582 8 8zm-129.68-62.25h-59.473c-8.692 0-15.764 7.071-15.764 15.764v59.473c0 8.692 7.071 15.764 15.764 15.764h59.473c8.692 0 15.764-7.071 15.764-15.764v-59.473c0-8.693-7.072-15.764-15.764-15.764zm-.236 75h-59v-59h21.5v9.224a8 8 0 0 0 16 0v-9.224h21.5zm.236-191.546h-59.473c-8.692 0-15.764 7.071-15.764 15.764v59.473c0 8.692 7.071 15.764 15.764 15.764h59.473c8.692 0 15.764-7.071 15.764-15.764v-59.473c0-8.692-7.072-15.764-15.764-15.764zm-.236 75h-59v-59h21.5v9.224a8 8 0 0 0 16 0v-9.224h21.5zm.236-191.546h-59.473c-8.692 0-15.764 7.072-15.764 15.764v59.473c0 8.692 7.071 15.763 15.764 15.763h59.473c8.692 0 15.764-7.071 15.764-15.763v-59.473c0-8.692-7.072-15.764-15.764-15.764zm-.236 75h-59v-59h21.5v9.224a8 8 0 0 0 16 0v-9.224h21.5z" fill="currentColor" opacity="1" data-original="#000000" class=""></path></g></svg>';
				htmlBody += 					'<span>'+icon_check+'</span>';
				htmlBody += 				'</div>';
				htmlBody +=					'<div class="ort-block-title">Đơn hàng đã đặt</div>';
				htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.created_at)+'</div>';
				htmlBody +=				'</div>';
				htmlBody += 			'<div class="ort-block '+aStatus[1] + ' ' + stepPrev[1] +'" id="ort-processing">';
				htmlBody +=					'<div class="ort-block-circle">';
				htmlBody += 					'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M415.506 258.282V131.606a8 8 0 0 0-5.101-7.456L210.901 46.578a7.992 7.992 0 0 0-5.799 0L5.601 124.15A8 8 0 0 0 .5 131.606v230.366a8 8 0 0 0 5.101 7.456L205.103 447a7.992 7.992 0 0 0 5.798 0l102.873-39.999c16.813 34.857 52.51 58.965 93.731 58.965 57.343 0 103.994-46.651 103.994-103.994.001-54.652-42.374-99.592-95.993-103.69zm-207.504-57.687-43.969-17.096c59.145-22.994 118.286-45.991 177.428-68.989l43.97 17.096zm-111.385-43.31L274.04 88.294l45.347 17.632c-59.143 22.998-118.285 45.996-177.428 68.989zm-14.074 11.694 51.416 19.992v38.337l-21.984-18.725a8.002 8.002 0 0 0-7.563-1.549l-21.868 6.801v-44.856zM208.002 62.617l43.963 17.094-177.422 68.991-43.968-17.096zM16.5 143.3l50.043 19.458v58.346c0 3.376 1.621 6.585 4.335 8.582a10.69 10.69 0 0 0 9.478 1.586l24.6-7.65 27.446 23.376a10.675 10.675 0 0 0 11.371 1.568 10.685 10.685 0 0 0 6.187-9.673v-43.7l50.043 19.458V427.85L16.5 356.5zm199.502 284.551v-213.2L399.506 143.3v114.982c-53.619 4.098-95.994 49.039-95.994 103.69 0 10.471 1.562 20.582 4.453 30.121zm191.504 22.115c-48.521 0-87.994-39.474-87.994-87.994 0-48.521 39.474-87.995 87.994-87.995s87.994 39.475 87.994 87.995-39.474 87.994-87.994 87.994zm61.682-137.427c-4.14-4.139-9.643-6.418-15.496-6.418s-11.356 2.279-15.497 6.418l-50.521 50.523-13.828-17.401c-4.177-5.254-10.426-8.268-17.144-8.268a21.962 21.962 0 0 0-13.612 4.755 21.745 21.745 0 0 0-8.126 14.65 21.743 21.743 0 0 0 4.612 16.104l28.42 35.763a21.967 21.967 0 0 0 17.845 9.158c5.84 0 11.334-2.279 15.473-6.417l67.875-67.876c8.543-8.544 8.543-22.447-.001-30.991zm-11.314 19.678-67.875 67.876a5.772 5.772 0 0 1-4.159 1.731 5.876 5.876 0 0 1-4.883-2.541 7.776 7.776 0 0 0-.298-.398l-28.558-35.937a5.848 5.848 0 0 1-1.241-4.333 5.848 5.848 0 0 1 2.187-3.942 5.82 5.82 0 0 1 3.655-1.28c1.812 0 3.495.811 4.618 2.223l19.406 24.421a8 8 0 0 0 5.808 3.01 7.973 7.973 0 0 0 6.112-2.33l56.862-56.864a5.88 5.88 0 0 1 4.184-1.732c1.58 0 3.065.615 4.182 1.732a5.92 5.92 0 0 1 0 8.364z" fill="currentColor" opacity="1" data-original="#000000" class=""></path></g></svg>';
				htmlBody += 					'<span>'+icon_check+'</span>';
				htmlBody += 				'</div>';
				htmlBody +=					'<div class="ort-block-title">Đã xác nhận</div>';
				htmlBody +=					'<div class="ort-block-time">'+ ((data.pos_confirmed_at != null) ? renderTime(data.pos_confirmed_at) : '' ) +'</div>';
				htmlBody += 			'</div>';
				htmlBody += 			'<div class="ort-block '+aStatus[2] + ' ' + stepPrev[2] +'" id="ort-delivering">';
				htmlBody +=					'<div class="ort-block-circle">';
				htmlBody += 					'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 128 128" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M94.581 96.596c0-1.106.907-1.984 2.013-1.984s1.984.878 1.984 1.984v29.392c0 1.105-.879 2.013-1.984 2.013H11.416c-1.105 0-1.984-.907-1.984-2.013V75.451c0-1.106.878-1.984 1.984-1.984s2.013.878 2.013 1.984v48.552h81.152z" fill="" opacity="1" data-original="" class=""></path><path d="M29.104 120.8c0 1.105-.907 2.013-2.013 2.013s-1.983-.907-1.983-2.013V95.263c0-3.798 1.53-7.256 4.053-9.75 2.495-2.494 5.953-4.054 9.751-4.054s7.256 1.56 9.75 4.054a13.775 13.775 0 0 1 4.054 9.75V120.8a2.02 2.02 0 0 1-2.012 2.013c-1.106 0-1.985-.907-1.985-2.013V95.263c0-2.692-1.105-5.131-2.891-6.915-1.786-1.786-4.224-2.892-6.917-2.892s-5.159 1.105-6.944 2.892c-1.758 1.784-2.863 4.223-2.863 6.915zM65.584 104.843h18.367V90.869H65.584zm20.38 3.997H63.6c-1.105 0-2.013-.879-2.013-1.984V88.857c0-1.105.907-1.984 2.013-1.984h22.364c1.105 0 2.013.879 2.013 1.984v17.998c0 1.106-.908 1.985-2.013 1.985z" fill="" opacity="1" data-original="" class=""></path><path fill-rule="evenodd" d="M42.256 110.058a2.008 2.008 0 0 0 1.984-1.983c0-1.105-.907-2.013-1.984-2.013a2.021 2.021 0 0 0-2.013 2.013c0 1.076.907 1.983 2.013 1.983z" clip-rule="evenodd" fill="" opacity="1" data-original="" class=""></path><path d="M44.58 61.959v-.114l1.333-24.744H38.23l-4.535 24.971c.028 1.587.624 3.005 1.616 4.054a5.237 5.237 0 0 0 3.826 1.644 5.221 5.221 0 0 0 3.798-1.644c1.021-1.077 1.616-2.551 1.616-4.167zm5.301-24.857-1.304 24.857c0 1.616.624 3.09 1.616 4.167a5.239 5.239 0 0 0 7.624 0c1.021-1.077 1.616-2.551 1.616-4.167h.028l-.681-12.471a2 2 0 0 1 1.9-2.098 1.998 1.998 0 0 1 2.097 1.899l.652 12.556v.114h.028c0 1.616.624 3.09 1.616 4.167a5.237 5.237 0 0 0 3.826 1.644c1.104 0 1.983.907 1.983 2.012s-.879 2.013-1.983 2.013c-2.636 0-5.018-1.134-6.718-2.919-.255-.283-.51-.566-.737-.879-.226.313-.481.596-.736.879-1.701 1.785-4.083 2.919-6.69 2.919-2.636 0-5.017-1.134-6.718-2.919-.255-.283-.51-.566-.737-.879-.227.313-.481.596-.736.879-1.701 1.785-4.082 2.919-6.69 2.919-2.636 0-5.017-1.134-6.718-2.919-.255-.283-.51-.566-.737-.879-.227.313-.482.596-.737.879-1.701 1.785-4.082 2.919-6.689 2.919-2.636 0-5.018-1.134-6.718-2.919-.255-.283-.51-.566-.737-.879-.227.313-.482.596-.737.879-1.7 1.785-4.081 2.919-6.689 2.919-2.239 0-4.28-.822-5.896-2.154A9.736 9.736 0 0 1 .19 64.228c-.169-.708-.226-1.389-.169-2.069.056-.68.227-1.36.51-2.041l8.277-20.181c.85-2.098 2.239-3.798 3.94-4.988a10.438 10.438 0 0 1 5.981-1.843h36.565a2.02 2.02 0 0 1 2.012 2.013c0 1.077-.907 1.984-2.012 1.984h-5.413zm-15.675 0h-8.107l-7.284 25.084c.057 1.531.652 2.92 1.616 3.94a5.243 5.243 0 0 0 7.625 0c1.021-1.077 1.616-2.551 1.616-4.167h.028c0-.114 0-.255.028-.369zm-12.245 0H18.73c-1.389 0-2.665.396-3.713 1.134-1.077.765-1.956 1.842-2.522 3.231L4.217 61.619a3.19 3.19 0 0 0-.227.851c0 .283 0 .567.085.878a5.77 5.77 0 0 0 1.956 3.231 5.182 5.182 0 0 0 3.345 1.19 5.223 5.223 0 0 0 3.798-1.644c1.021-1.077 1.616-2.551 1.616-4.167h.028c0-.199.028-.369.057-.567zM60.624 115.585c-1.105 0-2.013-.878-2.013-1.983s.908-2.013 2.013-2.013H88.94c1.104 0 1.983.907 1.983 2.013s-.879 1.983-1.983 1.983zM124.003 46.767 98.267 90.303a1.97 1.97 0 0 1-2.722.708 1.842 1.842 0 0 1-.736-.736l-25.71-43.508a.63.63 0 0 0-.085-.142c-1.247-2.268-2.211-4.733-2.891-7.284a31.816 31.816 0 0 1-.992-7.908c0-8.673 3.515-16.524 9.184-22.221C80.012 3.514 87.863 0 96.565 0c8.673 0 16.525 3.514 22.223 9.211S128 22.76 128 31.433c0 2.721-.368 5.357-1.021 7.908a31.603 31.603 0 0 1-2.948 7.369zm-27.438-34.41a19.004 19.004 0 0 1 13.492 5.583 19 19 0 0 1 5.584 13.492c0 5.272-2.126 10.034-5.584 13.492s-8.221 5.612-13.492 5.612a19.09 19.09 0 0 1-13.521-5.612c-3.43-3.458-5.583-8.22-5.583-13.492s2.153-10.034 5.583-13.492a19.07 19.07 0 0 1 13.521-5.583zm10.658 8.418c-2.721-2.749-6.491-4.422-10.657-4.422a15.042 15.042 0 0 0-10.687 4.422 15.039 15.039 0 0 0-4.422 10.657c0 4.167 1.701 7.937 4.422 10.686a15.134 15.134 0 0 0 10.687 4.393c4.166 0 7.937-1.672 10.657-4.393 2.722-2.749 4.423-6.519 4.423-10.686 0-4.166-1.702-7.935-4.423-10.657zM96.565 85.371l24.008-40.645a27.484 27.484 0 0 0 2.551-6.406c.567-2.183.879-4.479.879-6.888 0-7.567-3.09-14.427-8.049-19.387-4.962-4.96-11.821-8.049-19.389-8.049-7.597 0-14.456 3.089-19.416 8.049a27.327 27.327 0 0 0-8.022 19.387c0 2.409.283 4.705.85 6.888a28.85 28.85 0 0 0 2.523 6.349l.028.057z" fill="" opacity="1" data-original="" class=""></path><path d="M96.565 22.278c2.495 0 4.79 1.049 6.462 2.693 1.645 1.644 2.665 3.939 2.665 6.462s-1.021 4.818-2.665 6.462c-1.672 1.672-3.938 2.693-6.462 2.693a9.155 9.155 0 0 1-6.492-2.693c-.028-.028-.057-.085-.113-.113a9.106 9.106 0 0 1-2.55-6.349 9.133 9.133 0 0 1 2.663-6.462c.057-.028.085-.085.142-.114a9.131 9.131 0 0 1 6.35-2.579zm3.628 5.498a5.19 5.19 0 0 0-3.628-1.474 5.185 5.185 0 0 0-3.571 1.417l-.085.085a5.093 5.093 0 0 0-1.504 3.628c0 1.389.539 2.636 1.419 3.572l.085.085c.936.907 2.211 1.502 3.656 1.502 1.418 0 2.693-.595 3.628-1.502a5.113 5.113 0 0 0 1.502-3.657 5.096 5.096 0 0 0-1.502-3.628z" fill="" opacity="1" data-original="" class=""></path></g></svg>';
				htmlBody += 					'<span>'+icon_check+'</span>';
				htmlBody += 				'</div>';
				htmlBody +=					'<div class="ort-block-title">Cửa hàng đang xử lý</div>';
				if (data.pos_delivering_self_at != null){
					if(data.fulfillments[0].carrier_status_code == 'delivering' || data.fulfillments[0].carrier_status_code == 'readytopick' || data.fulfillments[0].carrier_status_code == 'delivered' || data.fulfillments[0].carrier_status_code == 'waitingforreturn' || data.fulfillments[0].carrier_status_code == 'return' || data.fulfillments[0].carrier_status_code == 'picking' || data.fulfillments[0].carrier_status_code == 'notmeetcustomer' || data.fulfillments[0].carrier_status_code == 'cancel' || data.fulfillments[0].carrier_status_code == 'pickupfail'){
						htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_store_assigned_at) +'</div>';
					}
					else {
						htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_delivering_self_at) +'</div>';
					}
				}
				else if (data.pos_delivering_nvc_at != null) {
					if(data.fulfillments[0].carrier_status_code == 'delivering' || data.fulfillments[0].carrier_status_code == 'readytopick' || data.fulfillments[0].carrier_status_code == 'delivered' || data.fulfillments[0].carrier_status_code == 'waitingforreturn' || data.fulfillments[0].carrier_status_code == 'return' || data.fulfillments[0].carrier_status_code == 'picking' || data.fulfillments[0].carrier_status_code == 'notmeetcustomer' || data.fulfillments[0].carrier_status_code == 'cancel' || data.fulfillments[0].carrier_status_code == 'pickupfail'){
						htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_store_assigned_at) +'</div>';
					}
					else {
						htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_delivering_nvc_at) +'</div>';
					}
				}
				else {			
					if (aStatus[2] == 'active') htmlBody +=					'<div class="ort-block-time">'+ renderTime(data.pos_store_assigned_at) +'</div>';
				}
				htmlBody +=				'</div>';
				htmlBody += 			'<div class="ort-block '+aStatus[3] + ' ' + stepPrev[3] + delivery_cancel+'" id="ort-fulfilled">';
				htmlBody +=					'<div class="ort-block-circle">';
				htmlBody += 					'<svg viewBox="0 0 60 40" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40"><path d="M48.6693371,28.5712647 C47.2147119,28.5712647 45.8328179,29.1409929 44.7903364,30.1713525 C43.747855,31.2138339 43.1660049,32.5714842 43.1660049,34.0261094 C43.1660049,35.4807347 43.7357331,36.8383849 44.7903364,37.8808664 C45.8449397,38.911226 47.2147119,39.4809542 48.6693371,39.4809542 C51.6513189,39.4809542 54.0756944,37.032335 54.0756944,34.0261094 C54.0756944,31.0198839 51.6513189,28.5712647 48.6693371,28.5712647 Z M48.6693371,37.0565787 C46.9965181,37.0565787 45.5903803,35.6746847 45.5903803,34.0261094 C45.5903803,32.3775341 46.9965181,30.9956401 48.6693371,30.9956401 C50.3179124,30.9956401 51.6513189,32.3532904 51.6513189,34.0261094 C51.6513189,35.6989285 50.3179124,37.0565787 48.6693371,37.0565787 Z M50.0754749,11.3029771 C49.8572811,11.0969052 49.5663561,10.9878083 49.2633091,10.9878083 L43.0447861,10.9878083 C42.3780828,10.9878083 41.8325984,11.5332928 41.8325984,12.199996 L41.8325984,22.1399353 C41.8325984,22.8066386 42.3780828,23.3521231 43.0447861,23.3521231 L52.9119942,23.3521231 C53.5786974,23.3521231 54.1241819,22.8066386 54.1241819,22.1399353 L54.1241819,15.4850247 C54.1241819,15.1456122 53.9787194,14.8183215 53.7241599,14.5880058 L50.0754749,11.3029771 Z M51.6998064,20.9277476 L44.2569738,20.9277476 L44.2569738,13.4000619 L48.7905559,13.4000619 L51.6998064,16.0183873 L51.6998064,20.9277476 Z M19.0677129,28.5712647 C17.6130876,28.5712647 16.2311936,29.1409929 15.1887122,30.1713525 C14.1462307,31.2138339 13.5643806,32.5714842 13.5643806,34.0261094 C13.5643806,35.4807347 14.1341089,36.8383849 15.1887122,37.8808664 C16.2433155,38.911226 17.6130876,39.4809542 19.0677129,39.4809542 C22.0496947,39.4809542 24.4740702,37.032335 24.4740702,34.0261094 C24.4740702,31.0198839 22.0496947,28.5712647 19.0677129,28.5712647 Z M19.0677129,37.0565787 C17.3948938,37.0565787 15.9887561,35.6746847 15.9887561,34.0261094 C15.9887561,32.3775341 17.3948938,30.9956401 19.0677129,30.9956401 C20.7162882,30.9956401 22.0496947,32.3532904 22.0496947,34.0261094 C22.0496947,35.6989285 20.7162882,37.0565787 19.0677129,37.0565787 Z M10.9824208,30.964662 L8.54592346,30.964662 L8.54592346,27.7402426 C8.54592346,27.0735394 8.00043898,26.5280549 7.33373573,26.5280549 C6.66703248,26.5280549 6.12154801,27.0735394 6.12154801,27.7402426 L6.12154801,32.1768497 C6.12154801,32.843553 6.66703248,33.3890374 7.33373573,33.3890374 L10.9824208,33.3890374 C11.649124,33.3890374 12.1946085,32.843553 12.1946085,32.1768497 C12.1946085,31.5101465 11.649124,30.964662 10.9824208,30.964662 Z M17.1282125,23.4558325 C17.1282125,22.7891292 16.5827281,22.2436447 15.9160248,22.2436447 L1.21218772,22.2436447 C0.545484476,22.2436447 5.15143483e-14,22.7891292 5.15143483e-14,23.4558325 C5.15143483e-14,24.1225357 0.545484476,24.6680202 1.21218772,24.6680202 L15.9160248,24.6680202 C16.5827281,24.6680202 17.1282125,24.1346576 17.1282125,23.4558325 Z M3.67292881,19.9822412 L18.3767659,20.0670943 C19.0434692,20.0670943 19.5889536,19.5337317 19.6010755,18.8670285 C19.6131974,18.1882034 19.0677129,17.6427189 18.4010097,17.6427189 L3.69717256,17.5578658 C3.68505068,17.5578658 3.68505068,17.5578658 3.68505068,17.5578658 C3.01834743,17.5578658 2.47286296,18.0912284 2.47286296,18.7579316 C2.46074108,19.4367567 3.00622556,19.9822412 3.67292881,19.9822412 Z M6.14579176,15.3813153 L20.8496289,15.3813153 C21.5163321,15.3813153 22.0618166,14.8358309 22.0618166,14.1691276 C22.0618166,13.5024244 21.5163321,12.9569399 20.8496289,12.9569399 L6.14579176,12.9569399 C5.47908851,12.9569399 4.93360404,13.5024244 4.93360404,14.1691276 C4.93360404,14.8358309 5.47908851,15.3813153 6.14579176,15.3813153 Z M59.0820297,12.9652127 L50.4027656,5.8198864 C50.1845718,5.6391445 49.9178905,5.5427489 49.6269654,5.5427489 L39.4203448,5.5427489 L39.4203448,1.20494541 C39.4203448,0.54222544 38.8748603,0 38.2081571,0 L7.33373573,0 C6.66703248,0 6.12154801,0.54222544 6.12154801,1.20494541 L6.12154801,9.5731298 C6.12154801,10.2358498 6.66703248,10.7780752 7.33373573,10.7780752 C8.00043898,10.7780752 8.54592346,10.2358498 8.54592346,9.5731298 L8.54592346,2.40989083 L37.0080912,2.40989083 L37.0080912,30.9791466 L27.0681519,30.9791466 C26.4014486,30.9791466 25.8559642,31.521372 25.8559642,32.184092 C25.8559642,32.846812 26.4014486,33.3890374 27.0681519,33.3890374 L41.868964,33.3890374 C42.5356673,33.3890374 43.0811517,32.846812 43.0811517,32.184092 C43.0811517,31.521372 42.5356673,30.9791466 41.868964,30.9791466 L39.4324667,30.9791466 L39.4324667,7.9526397 L49.2026997,7.9526397 L57.1061637,14.459345 L57.0213106,30.9550477 L55.7606353,30.9550477 C55.0939321,30.9550477 54.5484476,31.4972731 54.5484476,32.1599931 C54.5484476,32.8227131 55.0939321,33.3649385 55.7606353,33.3649385 L58.2213764,33.3649385 C58.8880797,33.3649385 59.4335641,32.8347625 59.4335641,32.1720426 L59.5305391,13.9050701 C59.5184173,13.5435865 59.3608329,13.1941523 59.0820297,12.9652127 Z"></path></svg>';
				htmlBody += 					'<span>'+icon_check+'</span>';
				htmlBody += 				'</div>';
				htmlBody +=					'<div class="ort-block-title">'+ delivery_status +'</div>';
				htmlBody +=					'<div class="ort-block-time">'+ ((delivery_time != '') ? delivery_time : '' ) +'</div>';
				htmlBody +=				'</div>';
				if(data.pos_order_status == 'pos_cancel_refund'){
					htmlBody += 			'<div class="ort-block '+aStatus[4] + ' ' + stepPrev[3] +'" id="ort-refund">';
					htmlBody +=					'<div class="ort-block-circle">';
					htmlBody += 					'<svg viewBox="0 0 42 50" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40"><path d="M27.7932185,-1.42108547e-13 C31.5753806,-1.42108547e-13 34.6520518,3.07705189 34.6520518,6.85921402 L34.6520518,6.85921402 L34.6520518,30.8207756 C38.5769872,32.0920298 41.4233174,35.7820555 41.4233174,40.1254122 C41.4233174,45.5165351 37.0376998,49.9029141 31.6465768,49.9029141 C27.3332978,49.9029141 23.6638315,47.0946568 22.3689721,43.2108401 L22.3689721,43.2108401 L6.8588333,43.2108401 C3.07667119,43.2108401 0,40.1337882 0,36.3512454 L0,36.3512454 L0,6.85921402 C0,3.07705189 3.07667119,-1.42108547e-13 6.8588333,-1.42108547e-13 L6.8588333,-1.42108547e-13 L27.7932185,-1.42108547e-13 Z M31.6465768,33.2715283 C27.8678413,33.2715283 24.7938352,36.3459152 24.7938352,40.1254122 C24.7938352,43.9041477 27.8678413,46.9789152 31.6465768,46.9789152 C35.4253124,46.9789152 38.4993185,43.9041477 38.4993185,40.1254122 C38.4993185,36.3459152 35.4253124,33.2715283 31.6465768,33.2715283 Z M33.1146679,36.5895817 C33.6853808,36.0188689 34.6113137,36.0188689 35.1820266,36.5895817 C35.7531201,37.1606753 35.7531201,38.0862275 35.1820266,38.6569404 L35.1820266,38.6569404 L33.7139355,40.1250315 L35.1820266,41.5931226 C35.7527393,42.164216 35.7527393,43.0897683 35.1820266,43.6608618 C34.8964798,43.9464086 34.5222231,44.0891819 34.1483473,44.0891819 C33.7740906,44.0891819 33.3998341,43.9464086 33.1146679,43.6608618 L33.1146679,43.6608618 L31.6465768,42.1927707 L30.1784857,43.6608618 C29.892939,43.9464086 29.5186824,44.0891819 29.1448065,44.0891819 C28.7705499,44.0891819 28.3962932,43.9464086 28.1107464,43.6608618 C27.5400337,43.0897683 27.5400337,42.164216 28.1107464,41.5931226 L28.1107464,41.5931226 L29.5788375,40.1250315 L28.1107464,38.6569404 C27.5400337,38.0862275 27.5400337,37.1602946 28.1107464,36.5895817 C28.68184,36.0188689 29.607773,36.0188689 30.1784857,36.5895817 L30.1784857,36.5895817 L31.6465768,38.0576728 L33.1146679,36.5895817 Z M27.7932185,2.92399887 L6.8588333,2.92399887 C4.68905861,2.92399887 2.92399887,4.68943931 2.92399887,6.85921402 L2.92399887,6.85921402 L2.92399887,36.3512454 C2.92399887,38.5214007 4.68905861,40.2868413 6.8588333,40.2868413 L6.8588333,40.2868413 L21.87174,40.2868413 C21.8709785,40.2327777 21.8698363,40.1790949 21.8698363,40.1254122 C21.8698363,34.7335277 26.2554539,30.3475294 31.6465768,30.3475294 C31.6739893,30.3475294 31.7010211,30.3482909 31.7280529,30.3482909 L31.7280529,30.3482909 L31.7280529,6.85921402 C31.7280529,4.68943931 29.9629932,2.92399887 27.7932185,2.92399887 L27.7932185,2.92399887 Z M12.3405697,34.6337768 C13.148096,34.6337768 13.8025691,35.28825 13.8025691,36.0957762 C13.8025691,36.9029217 13.148096,37.5577757 12.3405697,37.5577757 L12.3405697,37.5577757 L7.5814569,37.5577757 C6.7743114,37.5577757 6.1194575,36.9029217 6.1194575,36.0957762 C6.1194575,35.28825 6.7743114,34.6337768 7.5814569,34.6337768 L7.5814569,34.6337768 L12.3405697,34.6337768 Z M27.1768181,15.8543178 C27.9843445,15.8543178 28.6388176,16.508791 28.6388176,17.3163172 C28.6388176,18.1234628 27.9843445,18.7783167 27.1768181,18.7783167 L27.1768181,18.7783167 L7.5814569,18.7783167 C6.7743114,18.7783167 6.1194575,18.1234628 6.1194575,17.3163172 C6.1194575,16.508791 6.7743114,15.8543178 7.5814569,15.8543178 L7.5814569,15.8543178 L27.1768181,15.8543178 Z M24.3590427,10.8366901 C25.1665689,10.8366901 25.8210421,11.491544 25.8210421,12.2986896 C25.8210421,13.1062158 25.1665689,13.760689 24.3590427,13.760689 L24.3590427,13.760689 L7.5814569,13.760689 C6.7739307,13.760689 6.1194575,13.1062158 6.1194575,12.2986896 C6.1194575,11.491544 6.7743114,10.8366901 7.5814569,10.8366901 L7.5814569,10.8366901 L24.3590427,10.8366901 Z M27.2830416,5.81944305 C28.0905678,5.81944305 28.745041,6.47391625 28.745041,7.28144248 C28.745041,8.088588 28.0905678,8.74344192 27.2830416,8.74344192 L27.2830416,8.74344192 L7.5814569,8.74344192 C6.7743114,8.74344192 6.1194575,8.088588 6.1194575,7.28144248 C6.1194575,6.47391625 6.7743114,5.81944305 7.5814569,5.81944305 L7.5814569,5.81944305 L27.2830416,5.81944305 Z"></path></svg>';
					htmlBody += 					'<span>'+icon_x+'</span>';
					htmlBody += 				'</div>';
					htmlBody +=					'<div class="ort-block-title">'+complete_status+'</div>';
					htmlBody +=					'<div class="ort-block-time">'+ complete_time +'</div>';
					htmlBody +=				'</div>';
				}
				else {
					htmlBody += 			'<div class="ort-block '+aStatus[4] + ' ' + stepPrev[3] +'" id="ort-completed">';
					htmlBody +=					'<div class="ort-block-circle">';
					htmlBody += 					'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="40" height="40" x="0" y="0" viewBox="0 0 48 48" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="hand receive package"><path d="M44 26V6a1 1 0 0 0-1-1H15a1 1 0 0 0-1 1v16.34c-1.54-.1-1.89 0-6 .53V22a1 1 0 0 0-1-1H1a1 1 0 0 0-1 1v17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-1c3.54 0 1.69-.49 11.63 4a11.27 11.27 0 0 0 5.09 1c3.5 0 3.65-.52 21.11-9.44A4 4 0 0 0 44 26ZM32 7v3.38c-3.62-1.81-2.39-1.8-6 0V7ZM16 7h8v5a1 1 0 0 0 1.45.89L29 11.12c3.77 1.88 3.89 2.12 4.53 1.73S34 12.38 34 7h8v19.53l-11 5.62a4.09 4.09 0 0 0-.23-1.5C30 28.56 29.42 28.71 18 23.33a11.47 11.47 0 0 0-2-.68ZM6 38H2V23h4Zm38.92-6.22C27.42 40.72 27.56 41 24.72 41a9.32 9.32 0 0 1-4.26-.8C10.34 35.61 12 36 8 36V24.88c8.22-1 5.44-1.47 19.85 5.3a2 2 0 0 1 .95 2.68 2 2 0 0 1-2.65 1l-7.89-3.76a1 1 0 0 0-.86 1.8l7.89 3.71a3.92 3.92 0 0 0 3.93-.3l13.86-7.09a2 2 0 1 1 1.84 3.56Z" fill="currentColor" opacity="1" data-original="currentColor"></path><path d="M35 25h4a1 1 0 0 0 0-2h-4a1 1 0 0 0 0 2Z" fill="currentColor" opacity="1" data-original="#000000"></path></g></g></svg>';
					htmlBody += 					'<span>'+icon_check+'</span>';
					htmlBody += 				'</div>';
					htmlBody +=					'<div class="ort-block-title">'+complete_status+'</div>';
					if (aStatus[4] == 'active') htmlBody +=					'<div class="ort-block-time">'+ complete_time +'</div>';
					htmlBody +=				'</div>';
				}
			}
			htmlBody += 			'</div>';
			if (data.hasOwnProperty('tracking_url') && data.hasOwnProperty('tracking_number') ){
				htmlBody += 			'<div class="tracking-delivery"><a target="_blank" href="'+data.tracking_url+data.tracking_number+'">Tình trạng giao hàng</a></div>';
			}
			htmlBody += 		'</div>';
			htmlBody += 	 '</div>';

			htmlFinal += htmlHead + htmlBody + '</div>';
			$('.tracking-detail').html(htmlFinal);

		};
		function renderHtmlOrderDetail(data,type,line){
			var html = '';
			html += 		'<div id="'+data.id+'" data-vrid="'+ data.variant_id +'" data-prid="'+data.product_id+'" class="line-item">';
			html += 			'<div class="left">';
			html += 				'<div class="image">';
			if ( data.image == null ) {
				html +=					'<img src="//theme.hstatic.net/200000636033/1001033735/14/no-image.jpg" alt="'+data.title+'" />';
			}
			else {
				html +=					'<img src="'+data.image.src+'" alt="'+data.title+'" />';
			}
			html += 				'</div>';
			html += 			'</div>';
			html += 			'<div class="right">';
      html += 				'<div class="info">';
      html +=           '<div class="vendor">'+data.vendor+'</div>'
			html += 					'<div class="name">'+data.title+'</div>';
			if (data.custom_total_discount > 0){
				html += 					'<div class="discount">•Giảm giá '+KG.Helper.moneyFormat(data.custom_total_discount,'₫')+'</div>';
			}	
			if (!$.isEmptyObject(KG.Account.dataOrderGiftPE)) {
				$.each(KG.Account.dataOrderGiftPE, function(keyGiftPE,htmlGiftFE){
					if(data.properties.filter(x => x.name == ('PE-gift-item-buy ' + keyGiftPE) ).length > 0) {
						html += htmlGiftFE;
					}
				})
			}
		
			html += 				'</div>';
			html += 				'<div class="total money text-right">';
      html += 				  '<div class="total-price-original">';
      if (data.custom_total_price_original > data.custom_total_price){
				html += 				 '<span>'+ KG.Helper.moneyFormat(data.custom_total_price_original,'₫')+'</span>';
			}
      html +=           '</div>';
			html += 					'<div class="total-price"><span>'+ KG.Helper.moneyFormat(data.custom_total_price,'₫') +'</span></div>';
			html += 				'</div>';
      html += 		'<div class="bottom">';
      html += 			'<div class="meta">';
			if (data.variant_title != 'Default Title') {
				html += 						'<span class="variant">'+data.variant_title+'</span>';
			}
			html += 			'</div>';
      html += 			'<div class="quantity"><span>x'+data.quantity+'</span></div>';
      html += 		 '</div>';	
			html += 			'</div>';  
      
			html += 	 '</div>';	
			return html;	 
		};
		function renderHtmlGiftOrder(data,line){
			var itemOjProperties = {}
			var htmlGift = '';
			htmlGift +=	'<div class="line-gift" data-line="'+(line+1)+'" data-variant-id="'+data.variant_id+'" data-pro-id="'+data.product_id+'">';
			htmlGift +=			'<div class="gift-info">•Tặng: '+ data.title;
			htmlGift +=				'<span> Trị giá: ' + KG.Helper.moneyFormat(data.custom_total_price_original,'₫') +'</span>';
			htmlGift +=			'</div>';
			htmlGift +=	'</div>';
			return htmlGift;
		};
		function checkItemOrder(order) {
			var itemOjProperties = {}
			var countPromo = 0;
			var typePromo = '';

			var Combos = []; //mã combo
			var titleCombos = []; //tên combo
			var lineCombo = [];

			var Gift = []; //mã gift
			var titleGift = []; //tên program gift
			var lineGift = [];
			
			var Discount = []; //mã Discount
			var titleDiscount = []; //tên Discount
			var lineDiscount = [];

			var checkItemGiftOmni = false;
			var checkItemGift = false;
			var checkItemCombo = false;
			var checkItemDiscount = false;

			for(var i = 0; i < order.line_items.length; i++) {
				var item = order.line_items[i];
				itemOjProperties = item.properties;
				$.each(itemOjProperties,function(j,properties){
					if (properties.name.indexOf('PE-combo-item') > -1){
						checkItemCombo = true;
						// PE-combo-item: "ma-combo | tên combo"
						var temp1 = properties.value.split('|')[0].trim();
						var titleTemp1 = properties.value.split('|')[1].trim();
						if(Combos.includes(temp1)) {
							var indexExist = Combos.indexOf(temp1);
							lineCombo[indexExist].push(i);
						}
						else {
							Combos.push(temp1);
							titleCombos.push(titleTemp1);
							var temp11 = [];
							temp11.push(i);
							lineCombo.push(temp11);
						}
					}
					else if(properties.name.indexOf('PE-gift-item ') > -1) {
						checkItemGift = true;
						//PE-gift-item-buy magift: "tên sản phẩm"
						//PE-gift-item magift: "tên sản phẩm"
						var temp3 = properties.value;
						var titleTemp3 = temp3;
						var codeTemp3 = properties.name.split(' ')[1].trim();
						if(Gift.includes(codeTemp3)) {
							var indexExist = Gift.indexOf(codeTemp3);
							lineGift[indexExist].push(i);
						}
						else {
							Gift.push(codeTemp3);
							titleGift.push(titleTemp3);
							var temp33 = [];
							temp33.push(i);
							lineGift.push(temp33);
						}
					}
					else if(properties.name.indexOf('Khuyến mãi') > -1) {
						checkItemGiftOmni = true;
					}		
				})
			}

			//Khuyến mãi
			if(Gift.length > 0) {
				for(var i = 0; i < Gift.length; i++) {
					var gf = Gift[i];
					var itemInGift = [];
					order.line_items.map((x,index) => {
						var findGift = x.properties.filter(v => v.name == ('PE-gift-item ' + gf) && v.value.indexOf(titleGift[i]) > -1);
						if (findGift.length > 0){
							itemInGift.push(x);
						}
					});
					if (itemInGift.length > 0) {
						var htmlGiftApp = '<div class="gifts-list"><div>Quà tặng khuyến mãi</div>';
						for(var j = 0; j < itemInGift.length; j++) {
							countPromo = countPromo + itemInGift[j].quantity;
							htmlGiftApp += renderHtmlGiftOrder(itemInGift[j],lineGift[i][j]);
						}
						htmlGiftApp += '</div>';	
						KG.Account.dataOrderGiftPE[gf] = htmlGiftApp;
					}
				}
			}
			
			//Combo
			if(Combos.length > 0) {
				for(var i = 0; i < Combos.length; i++) {
					var cmb = Combos[i];
					var html = 	'<div class="order-group combo">';
					html += 			'<div class="quantity-combo-mini d-none align-items-center">';
					html +=  				'<div>Ưu đãi: ' + titleCombos[i] + '</div>';
					html +=  			'</div>';

					var itemInCombo = [];
					order.line_items.map((x,index) => {
						var findCombo = x.properties.filter(v => v.name == ('PE-combo-item') && v.value.indexOf(cmb) > -1);
						if (findCombo.length > 0){
							itemInCombo.push(x);
						}
					});							 
					if (itemInCombo.length > 0) {
						for(var j = 0; j < itemInCombo.length; j++) {
							countPromo = countPromo + itemInCombo[j].quantity;
							html += renderHtmlOrderDetail(itemInCombo[j],'comboApp',lineCombo[i][j]);
						}
					}
					html += '</div>';

					$('#order_details .table-order').append(html);
				}
			}

			var promoGroup  = lineCombo.join(',').split(',');
			var promoGift   = lineGift.join(',').split(',');
			var promoDiscount  = lineDiscount.join(',').split(',');
			var promoSingle = lineGift.join(',').split(',');

			if(order.line_items.length > countPromo) {
				var htmlHead = '';
				var parent = null;
				if (countPromo >= 0) {
					htmlHead += '<div class="order-group single"></div>';
					$('#order_details .table-order').append(htmlHead);
				} 
				else {
					parent = $('#order_details .table-order');
				}
				for(var i = 0; i < order.line_items.length; i++) {
					if (!promoGroup.includes(i+"") && !promoGift.includes(i+"")) {
						var item = order.line_items[i];
						var htmlNormal =	renderHtmlOrderDetail(item,'',i,);
						$('#order_details .table-order .order-group.single').append(htmlNormal);
					}
				}
			}
		};

		var phone = $('#get_phone_order').val().trim();
		var email = $('#get_email').val();
		var ordernum = $('#get_id_order').val();
		var ordercode = $('#get_code_order').val();

		var paramUrl =  '/apps/kges/auth/api/orders/'+ordernum+'/detail';	
		setTimeout(function() {
			$.get(paramUrl).done(function(result){									
				var resultItem = result.item;
				
				console.log(result);
				//var resultItem = result.orders[0];		
				//renderHtmlTracking(result.orders[0]);
				if (result.item != null){
					renderHtmlTracking(resultItem);
					
					$('#shipping_method').html(resultItem.shipping_lines[0].code);
					if (resultItem.fulfillments.length > 0) {
						if (resultItem.fulfillments[0].carrier_status_code == 'delivered') {
							if (resultItem.pos_order_status == 'pos_cancel_refund' || resultItem.pos_order_status == 'pos_cancel_refund' || resultItem.pos_order_status == 'pos_cancel_restock') {
								$('.order-status').html('<strong style="color:#ff1100;">Huỷ - Trả hàng</strong>');
							}
							else {
								$('.order-status').html('<strong>'+resultItem.fulfillments[0].carrier_status_name+'</strong>');
							}
						}
						else if (resultItem.fulfillments[0].carrier_status_code == 'return') {	
							//if (resultItem.pos_order_status == 'pos_cancel_restock' ) {}
							$('.order-status').html('<strong style="color:#ff1100;">Huỷ - Trả hàng</strong>');

						}
						else if (resultItem.fulfillments[0].carrier_status_code == 'cancel' || resultItem.pos_order_status == 'pos_cancel_refund' ) {
							$('.order-status').html('<strong style="color:#ff1100;">'+resultItem.fulfillments[0].carrier_status_name+'</strong>');
						}
						else {
							$('.order-status').html('<strong>Chưa nhận hàng</strong>');
						}
					}
					else {
						if ( resultItem.pos_order_status == 'pos_cancel' ) {
							$('.order-status').html('<strong style="color:#ff1100;">Đã huỷ</strong>');
						}
						else {
							$('.order-status').html('<strong>Đang xử lý</strong>');
						}
					}

					if (resultItem.gateway_code == 'cod'){
						if(resultItem.pos_order_status == 'pos_complete'){
							$('#order_payment .info-box--body').html('<div>'+resultItem.gateway+'</div><div class="paid"><span><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="14" height="14" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill-rule="evenodd" clip-rule="evenodd"><path fill="#1887db" d="M256 0C114.8 0 0 114.8 0 256s114.8 256 256 256 256-114.8 256-256S397.2 0 256 0z" opacity="1" data-original="#1887db" class=""></path><path fill="#ffffff" d="M379.8 169.7c6.2 6.2 6.2 16.4 0 22.6l-150 150c-3.1 3.1-7.2 4.7-11.3 4.7s-8.2-1.6-11.3-4.7l-75-75c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l63.7 63.7 138.7-138.7c6.2-6.3 16.4-6.3 22.6 0z" opacity="1" data-original="#ffffff"></path></g></g></svg>Thanh toán thành công <strong class="d-none">'+result.item.fulfillments[0].cod_amount+'</strong></span></div>');
						}
						else {
							$('#order_payment .info-box--body').html('<div>'+resultItem.gateway+'</div><div class="unpaid"><span><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="14" height="14" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Flat Color"><circle cx="12" cy="12" r="10" fill="#ff1100" opacity="1" data-original="#ff1100" class=""></circle><path fill="#edebea" d="m13.06 12 2.47-2.47a.75.75 0 0 0-1.06-1.06L12 10.94 9.53 8.47a.75.75 0 0 0-1.06 1.06L10.94 12l-2.47 2.47a.75.75 0 0 0 0 1.06.75.75 0 0 0 1.06 0L12 13.06l2.47 2.47a.75.75 0 0 0 1.06 0 .75.75 0 0 0 0-1.06z" opacity="1" data-original="#edebea"></path></g></g></svg>Chưa thanh toán</span></div>');
						}
					}
					else {
						if(resultItem.pos_order_status == 'pos_pending'){
							$('#order_payment .info-box--body').html('<div>'+resultItem.gateway+'</div><div class="unpaid red"><span><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="14" height="14" x="0" y="0" viewBox="0 0 24 24" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g data-name="Flat Color"><circle cx="12" cy="12" r="10" fill="#ff1100" opacity="1" data-original="#ff1100" class=""></circle><path fill="#edebea" d="m13.06 12 2.47-2.47a.75.75 0 0 0-1.06-1.06L12 10.94 9.53 8.47a.75.75 0 0 0-1.06 1.06L10.94 12l-2.47 2.47a.75.75 0 0 0 0 1.06.75.75 0 0 0 1.06 0L12 13.06l2.47 2.47a.75.75 0 0 0 1.06 0 .75.75 0 0 0 0-1.06z" opacity="1" data-original="#edebea"></path></g></g></svg>Chưa thanh toán</span></div>');
						}
						else {
							$('#order_payment .info-box--body').html('<div>'+resultItem.gateway+'</div><div class="paid"><span><svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="14" height="14" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><g fill-rule="evenodd" clip-rule="evenodd"><path fill="#1887db" d="M256 0C114.8 0 0 114.8 0 256s114.8 256 256 256 256-114.8 256-256S397.2 0 256 0z" opacity="1" data-original="#1887db" class=""></path><path fill="#ffffff" d="M379.8 169.7c6.2 6.2 6.2 16.4 0 22.6l-150 150c-3.1 3.1-7.2 4.7-11.3 4.7s-8.2-1.6-11.3-4.7l-75-75c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l63.7 63.7 138.7-138.7c6.2-6.3 16.4-6.3 22.6 0z" opacity="1" data-original="#ffffff"></path></g></g></svg>Thanh toán thành công </span></div>');
						}
					}

					$('#order_customer .name-receive span').html(resultItem.shipping_address.name);
          $('#order_customer .phone-receive span').html(resultItem.shipping_address.phone);
					$('#order_customer .address-receive span').html(resultItem.shipping_address.address1);
          $('#order_shipping .name-shipping span:first-child').html(resultItem.shipping_lines[0].title);
          $('#order_shipping .name-shipping span:last-child').html(KG.Helper.moneyFormat(resultItem.shipping_lines[0].price,'₫'));
          $('#order_info .info-box--body .mail span').html(resultItem.customer.email);

					$('#order_details .table-order').append(checkItemOrder(resultItem));

					$('#order_details_total .subtotal-price .line--r span').html(KG.Helper.moneyFormat(resultItem.total_line_items_price,'₫'));
					if (resultItem.shipping_lines[0].price > 0){
						$('#order_details_total .shipping-fee .line--r span').html(KG.Helper.moneyFormat(resultItem.shipping_lines[0].price,'₫'));
					}
					else {
						$('#order_details_total .shipping-fee .line--r span').html('Miễn phí');
					}
					if (resultItem.total_discounts > 0){
						$('#order_details_total .discounts-fee .line--r span').html('- ' + KG.Helper.moneyFormat(resultItem.total_discounts,'₫'));
						$('#order_details_total .discounts-fee').removeClass('d-none');
					}

					$('#order_details_total .maintotal-price .line--r span').html(KG.Helper.moneyFormat(resultItem.total_price,'₫'));

					//Check can cancel order
					var posStatus = resultItem.pos_order_status;
					var arrayPosStatus = ['pos_pending','pos_user_assigned','pos_confirmed','pos_store_assigned','pos_output','pos_out_of_stock','pos_stock_on_hand'];
					if(arrayPosStatus.includes(posStatus) && resultItem.is_available_cancel /*&& resultItem.source_name == 'web'*/){
						$('.view-orderdetail .js-cancel-order').removeClass('d-none');
					}	
				}
				else {
					$('.cus-order').html('<div class="alert-danger alert text-center">Đơn hàng này không thuộc tài khoản của bạn. Vui lòng đăng nhập đúng tài khoản để xem chi tiết đơn hàng!</div>')
				}
				$('.cus-order').removeClass('d-none');
			});
		},800); 

		/*Order Cancle*/
		$('body').on('click', '.view-orderdetail .js-cancel-order', function(e){
			e.preventDefault();
			Swal.fire({
				title: '',
				text: 'Bạn muốn huỷ đơn hàng này?',
				icon: 'question',
				showCancelButton: true,
				showConfirmButton: true,
				confirmButtonText: 'Có',
				cancelButtonText: 'Không',
			}).then((result) => {
				if (result.isConfirmed) {
					$('#cancel-order-modal').modal('show');
				} 
			})	
		});
		$('body').on('click', '#cancel-order-modal .btn-cancel-submit', function(e){
			//debugger;
			e.preventDefault();
			var noteReason = $('#cancel-reason-text').val();
			
			if (phone != '') {
				var dataPost = {
					order_number: ordercode,
					phone: phone,
					order_cancel_note: noteReason
				}
			}
			else {
				var dataPost = {
					order_number: ordercode,
					email: email,
					order_cancel_note: noteReason
				}
			}			
			
			$.ajax({
				url: '/apps/kges/auth/api/orders/cancel',
				type: 'POST',
				data: JSON.stringify(dataPost),
				contentType: 'application/json',
				dataType: 'JSON',
				success: function(data){
					console.log(data);
					if(data.error){
						KG.Helper.SwalWarning(data.message,'Không thể xoá đơn hàng này!','warning',false,false,4000);
					}
					else{
						Swal.fire({
							title: '',
							text: 'Huỷ đơn hàng thành công!',
							icon: 'success',
							showCancelButton: false,
							showConfirmButton: false,
							timer: 3000,
						}).then((result) => {
							window.location.reload(); 
						})
					}
				}
			});
			
		});
	},
  initAddresses: {
		init: function(){
			var that = this;
			that.getAddresses();
			that.getProvinceAndDistrict();
			that.updateAddress();
			that.createAddress();
		},
		getAddresses: function(){
			function renderHtmlAddress(data) {
				var html = '';
				html +=	'<div id="line-address-'+data.id+'" class="user-address '+data.id+' '+ ((data.default)?"default":"")+'">';
        html +=		'<div class="head">';
				html +=		 '<div class="title"><span class="lastname">'+data.last_name+'</span> <span class="firstname">'+data.first_name+'</span></div>';
        html +=		'<div class="action">';
				html +=			'<a data-id="'+data.id+'" data-default="'+((data.default)?'1':'0')+'" data-first-name="'+data.first_name+'" data-last-name="'+data.last_name+'" data-phone="'+data.phone+'" data-province="'+data.province_name+'" data-provinceid="'+data.province_code+'" data-district="'+data.district_name+'" data-districtid="'+data.district_code+'" data-ward="'+data.ward_name+'" data-wardid="'+data.ward_code+'" data-address="'+data.address1+'" data-type="'+((data.company != null)?"Văn phòng":"Nhà riêng")+'" href="javascript:void(0);" class="action-edit js-edit-customer">';
				html +=				'<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.3964 25.0963C12.4347 24.7517 12.4538 24.5794 12.5059 24.4184C12.5522 24.2755 12.6175 24.1396 12.7002 24.0142C12.7934 23.8729 12.916 23.7503 13.1611 23.5052L24.1664 12.4999C25.0868 11.5795 26.5792 11.5795 27.4997 12.4999C28.4202 13.4204 28.4202 14.9128 27.4997 15.8333L16.4944 26.8385C16.2493 27.0836 16.1267 27.2062 15.9854 27.2994C15.86 27.3821 15.7241 27.4474 15.5812 27.4937C15.4202 27.5458 15.2479 27.5649 14.9033 27.6032L12.083 27.9166L12.3964 25.0963Z" stroke="#262626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
				html +=			'</a>';
				if (!data.default){
					html +=		'<a href="#" data-provincecode="'+data.province_code+'" data-districtcode="'+data.district_code+'" data-wardcode="'+data.ward_code+'" data-id="'+data.id+'" class="action-delete js-delete-customer">';
					html +=			'<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M23.3333 15.0001V14.3334C23.3333 13.4 23.3333 12.9333 23.1517 12.5768C22.9919 12.2632 22.7369 12.0082 22.4233 11.8484C22.0668 11.6667 21.6001 11.6667 20.6667 11.6667H19.3333C18.3999 11.6667 17.9332 11.6667 17.5767 11.8484C17.2631 12.0082 17.0081 12.2632 16.8483 12.5768C16.6667 12.9333 16.6667 13.4 16.6667 14.3334V15.0001M18.3333 19.5834V23.7501M21.6667 19.5834V23.7501M12.5 15.0001H27.5M25.8333 15.0001V24.3334C25.8333 25.7335 25.8333 26.4336 25.5608 26.9684C25.3212 27.4388 24.9387 27.8212 24.4683 28.0609C23.9335 28.3334 23.2335 28.3334 21.8333 28.3334H18.1667C16.7665 28.3334 16.0665 28.3334 15.5317 28.0609C15.0613 27.8212 14.6788 27.4388 14.4392 26.9684C14.1667 26.4336 14.1667 25.7335 14.1667 24.3334V15.0001" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"/></svg>';
					html +=		'</a>';
				}
				html +=		'</div>';
        html +=		'</div>';
				html +=		'<span class="phone">'+data.phone+'</span>';
        html +=		'<div class="desc">'+((data.address1 != null)?data.address1:"") + ((data.ward_name != null)?", "+data.ward_name:"") + ((data.district_name != null)?", "+data.district_name:"") + ((data.province_name != null)?", "+data.province_name:"") + ((data.country_name != null)?", "+data.country_name:"")+'</div>';
				html +=		'<div class="tag d-none"><span>'+((data.company != null)?'Văn phòng':'Nhà riêng')+'</span></div>';
				html +=		'<div class="default">';
        if (data.default){
					html +=		'<div class="line-checkbox"><input type="checkbox" checked readonly><label>Mặc định</label></div>';
				}
        else {
          html +=			'<a href="#" data-provincecode="'+data.province_code+'" data-districtcode="'+data.district_code+'" data-wardcode="'+data.ward_code+'" data-id="'+data.id+'" class="action-setup-df js-setdefault-customer">';
    			html +=       '<span class="span-input"></span>';
          html +=				'<span class="span-text">Đặt làm địa chỉ mặc định</span>';
					html +=			'</a>';
        }
        html +=	'</div>';
        
				html +=	'</div>';
				return html;	 
			}
			var paramUrl =  '/account/addresses.js';
			setTimeout(function() {
				$.get(paramUrl).done(function(result){									
					var resultItem = result;
					$('.js-render-addresses').html('');
					for (var i=0, l = resultItem.length - 1; i <= l; i++){
						$('.js-render-addresses').append(renderHtmlAddress(resultItem[i]));
					}
				});
			},1000);
		},
		getProvinceAndDistrict: function(){
			/* Get list countries */
			countries = addressData.countries;
			let countryId = 241;
			let provinces = addressData[countryId];
			$.each(provinces.provinces, function(i, data) {
				$('select[name="address[province]"]').append('<option value="' + data.n + '" data-province="'+ data.i + '" data-code="'+ data.c +'">' + data.n + '</option>');
			});
			$(document).on('change','select[name="address[province]"]',function(e){
				let provinceName = $(this).val();
				let	provinceId = $(this).find('option[value="'+provinceName+'"]').attr('data-province');
				let	provinceCode = $(this).find('option[value="'+provinceName+'"]').attr('data-code');
				if($('.modal-address.show select[name="address[district]"] option').length > 1){ 
					$('.modal-address.show select[name="address[district]"] option:not(:first-child)').remove();
				}
				if($('.modal-address.show select[name="address[ward]"] option').length > 1){
					$('.modal-address.show select[name="address[ward]"] option:not(:first-child)').remove();
				}
				if(provinceName != '' && countryId == 241){
					async function getDistrict(){
						districts = await addressData.getProvince(countryId, provinceId);
						if(!jQuery.isEmptyObject(districts)){
							if($('.modal-address.show select[name="address[district]"] option').length > 1){
								$('.modal-address.show select[name="address[district]"] option:not(:first-child)').remove();
							}
							$.each(districts.districts,function(indx,vlue){
								if(provinceId === '50') {
									if (vlue.n === 'Quận 2' || vlue.n === 'Quận 9' || vlue.n === 'Quận Thủ Đức') {
										return;
									}
								}
								$('.modal-address.show select[name="address[district]"]').append('<option data-district="'+vlue.i+'" value="'+vlue.n+'" data-code="'+vlue.c+'">'+vlue.n+'</option>');					
							});
						}
					}
					getDistrict();
				}
			});
			$(document).on('change','select[name="address[district]"]',function(e){
				let provinceName = $('.modal-address.show select[name="address[province]"]').val(),
						districtName = $(this).val();

				let provinceId = 		$('.modal-address.show select[name="address[province]"] option[value="'+provinceName+'"]').attr('data-province'),
						provinceCode = 	$('.modal-address.show select[name="address[province]"] option[value="'+provinceName+'"]').attr('data-code'),
						districtId = 		$(this).find('option[value="'+districtName+'"]').attr('data-district'),
						districtCode = 	$(this).find('option[value="'+districtName+'"]').attr('data-code');

				if($('.modal-address.show select[name="address[ward]"] option').length > 1){
					$('.modal-address.show select[name="address[ward]"] option:not(:first-child)').remove();
				}

				if(districtId != '' && districtId != undefined ){
					async function getWard(){
						districts = await addressData.getProvince(countryId, provinceId);
						if(!jQuery.isEmptyObject(districts)){
							let wards = districts[districtId].wards;
							if(wards.length > 0){
								if($('.modal-address.show select[name="address[ward]"] option').length > 1){
									$('.modal-address.show select[name="address[ward]"] option:not(:first-child)').remove();
								}

								$.each(wards,function(indx,vlue){
									$('.modal-address.show select[name="address[ward]"]').append('<option data-ward="'+vlue.i+'" value="'+vlue.n+'" data-code="'+vlue.i+'">'+vlue.n+'</option>');
								});
							}
						}
					}
					getWard();
				}
			});
		},
		updateAddress: function(){	
			$('body').on('click', '.user-address .js-edit-customer', function(e){
				e.preventDefault();
				$('#address_form input[type="text"]').val();
				$('#address_form select option[value=""]').prop('selected',true);
				$('#address_form input[type="checkbox"]').val('0');

				var id_address = $(this).attr('data-id'),
						last_name =  $(this).attr('data-last-name'),
						first_name = $(this).attr('data-first-name'),
						phone = $(this).attr('data-phone'),
						province = $(this).attr('data-province'),
						province_id = $(this).attr('data-provinceid'),
						district = $(this).attr('data-district'),
						district_id = $(this).attr('data-districtid'),
						ward = $(this).attr('data-ward'),
						ward_id = $(this).attr('data-wardid'),
						address = $(this).attr('data-address'),
						type = $(this).attr('data-type'),
						df_address =  $(this).attr('data-default');

				$('#address_form').attr('data-id',id_address);
				$('#address_form input[name="address[last_name]"]').val(last_name);
				$('#address_form input[name="address[first_name]"]').val(first_name);
				$('#address_form input[name="address[phone]"]').val(phone);
				if (province != '') {
					//$('#address_form select[name="address[province]"]').val(province).change();
          $('#address_form select[name="address[province]"] option').removeAttr('selected');
          $('#address_form select[name="address[province]"] option[value="'+province+'"]').attr('selected',true);
					async function getDistrict(district,ward){
						districts = await addressData.getProvince(241, province_id);
						if(!jQuery.isEmptyObject(districts)){
							if($('#address_form select[name="address[district]"] option').length > 1){
								$('#address_form select[name="address[district]"] option:not(:first-child)').remove();
							}
							$.each(districts.districts,function(indx,vlue){
								if(province_id === '50') {
									if (vlue.n === 'Quận 2' || vlue.n === 'Quận 9' || vlue.n === 'Quận Thủ Đức') {
										return;
									}
								}
                var selected_district = '';
                if(district != undefined && district != '' && district == vlue.n) selected_district = 'selected';
								$('#address_form select[name="address[district]"]').append('<option data-district="'+vlue.i+'" '+selected_district+' value="'+vlue.n+'"  data-code="'+vlue.c+'" '+(vlue.i == district_id?'selected':'')+'>'+vlue.n+'</option>');
							});
						}

						let wards = districts[district_id].wards;
            console.log('wards: ',wards);
						if(wards.length > 0){
							if($('#address_form select[name="address[ward]"] option').length > 1){
								$('#address_form select[name="address[ward]"] option:not(:first-child)').remove();
							}
							$.each(wards,function(indx,vlue){
                
								$('#address_form select[name="address[ward]"]').append('<option data-ward="'+vlue.c+'" value="'+vlue.n+'" '+(vlue.c == ward_id?'selected':'')+' data-code="'+vlue.c+'">'+vlue.n+'</option>');
							});
						}	
					}
					getDistrict(district,ward);		
				}

				$('#address_form input[name="address[address1]"]').val(address);
				$('#address_form input[name="address[type]"][value="'+type+'"]').prop('checked',true);
				$('#address_form input[name="address[default]"]').val(df_address);
				if ($('#address_form input[type="text"]').val().length > 0) {
					$('#address_form input').addClass('is-filled');
				}

				$('#editAddressModal').modal();
			});
      
			$('#address_form').submit(function(e){
				e.preventDefault();
				var id_address = $(this).attr('data-id');
				var //fullName = $(this).find('input[name="address[fullname]"]').val().split(' '),
				last_name = $('.modal-address.show #address_lastname').val(),//fullName[0],
						first_name = $('.modal-address.show #address_firstname').val(),//fullName.slice(1,fullName.length).join(' '),
						phone = $('#address_form').find('input[name="address[phone]"]').val(),
						province = $('#address_form').find('select[name="address[province]"] option:selected').val(),
						province_code = $('#address_form').find('select[name="address[province]"] option:selected').attr('data-code'),
						district = $('#address_form select[name="address[district]"] option:selected').val(),
						district_code = $('#address_form select[name="address[district]"] option:selected').attr('data-code'),
						ward = $('#address_form select[name="address[ward]"] option:selected').val(),
						ward_code = $('#address_form select[name="address[ward]"] option:selected').attr('data-code'),
						address = $('#address_form input[name="address[address1]"]').val(),
						type = $('#address_form input[name="address[type]"]:checked').val(),
						df_address = $('#address_form input[name="address[default]"]:checked').val();;

				var allowSubmit = true;

				//Kiểm tra đúng định dạng
				if(!KG.Helper.validatePhone(phone)){
					$('#address_form').find('input[name="address[phone]"]').parents('.form-group').addClass('is-invalid');
					allowSubmit = false;
				}
				else $('#address_form').find('input[name="address[phone]"]').parents('.form-group').removeClass('is-invalid');

				if(allowSubmit){
					var data = {
						"ward_code": ward_code,
						//"ward": ward,
						"district_code": district_code,
						//"district": district,
						"province_code": province_code,
						//"province": province,
						"phone": phone,
						"last_name": last_name,
						"first_name": first_name,
						"country_code": "VN",
						//"country": "Vietnam",
						"company": type,
						"address1": address,
						"address2": ''
					};
					$.ajax({
						url: '/account/addresses/'+id_address+'.js',
						type: 'PUT',
						data: JSON.stringify(data),
						contentType: 'application/json',
						dataType: 'JSON',
						success: function(data){
							if(data.error){
								KG.Helper.SwalWarning(data.message,'Vui lòng kiểm tra lại thông tin!','warning',false,false,4000);
							}
							else{
								$('#editAddressModal').modal('hide');
								Swal.fire({
									title: '',
									text: 'Địa chỉ đã được cập nhật thành công!',
									icon: 'success',
									showCancelButton: false,
									showConfirmButton: false,
									timer: 4000,
								}).then((result) => {
									setTimeout(function(){
										window.location.reload(); 
									},1500);
								})
							}
						}
					});
				}
			});
			
			$('body').on('click', '.user-address .js-setdefault-customer', function(e){
				e.preventDefault();
				var id_address = $(this).attr('data-id');
				var data = {
					"ward_code": $(this).attr('data-wardcode'),
					"ward": $(this).parents('.address_actions').find('.action_edit a').attr('data-ward'),
					"district_code": $(this).attr('data-districtcode'),
					"district": $(this).parents('.address_actions').find('.action_edit a').attr('data-district'),
					"province_code": $(this).attr('data-provincecode'),
					"province": $(this).parents('.address_actions').find('.action_edit a').attr('data-province'),
					"phone": $(this).parents('.address_actions').find('.action_edit a').attr('data-phone'),
					"last_name": $(this).parents('.address_actions').find('.action_edit a').attr('data-last-name'),
					"first_name": $(this).parents('.address_actions').find('.action_edit a').attr('data-first-name'),
					"country_code": "VN",
					"country": "Vietnam",
					"company": $(this).parents('.address_actions').find('.action_edit a').attr('data-type'),
					"address1": $(this).parents('.address_actions').find('.action_edit a').attr('data-address'),
					"address2": '',
					"default": true
				};
				$.ajax({
					url: '/apps/kges/auth/api/customers[addresses]/'+id_address+'/default',
					type: 'POST',
					data: JSON.stringify(data),
					contentType: 'application/json',
					dataType: 'JSON',
					success: function(data){
						if(data.error){
							KG.Helper.SwalWarning(data.message,'Vui lòng kiểm tra lại thông tin!','warning',false,false,4000);
						}
						else{
							Swal.fire({
								title: '',
								text: 'Thiết lập mặc định thành công!',
								icon: 'success',
								showCancelButton: false,
								showConfirmButton: false,
								timer: 3000,
							}).then((result) => {
								window.location.reload(); 
							})
						}
					}
				});
			});
			$('body').on('click', '.user-address .js-delete-customer', function(e){
				e.preventDefault();
				var id_address = $(this).attr('data-id');
				var data = {};

				Swal.fire({
					title: '',
					text: 'Bạn muốn xoá địa chỉ này?',
					icon: 'question',
					showCancelButton: true,
					showConfirmButton: true,
					confirmButtonText: 'Có',
					cancelButtonText: 'Không',
				}).then((result) => {
					if (result.isConfirmed) {
						$.ajax({
							url: '/account/addresses/'+id_address+'.js',
							type: 'DELETE',
							data: JSON.stringify(data),
							contentType: 'application/json',
							dataType: 'JSON',
							success: function(data){
								if(data.error){
									KG.Helper.SwalWarning(data.message,'Vui lòng kiểm tra lại thông tin!','warning',false,false,4000);
								}
								else{
									Swal.fire({
										title: '',
										text: 'Xoá địa chỉ thành công!',
										icon: 'success',
										showCancelButton: false,
										showConfirmButton: false,
										timer: 3000,
									}).then((result) => {
										window.location.reload(); 
									})
								}
							}
						});
					} 
				})	
			});
		},
		createAddress: function(){
			$(document).on('click','#js-btn-addnew',function(e){
				e.preventDefault();
				$('#addNewAddressModal').modal('show');
			});
			$('#address_form_new').submit(function(e){
				e.preventDefault();
				var //fullName = $(this).find('input[name="address[fullname]"]').val().split(' '),
				last_name = $('.modal-address.show #address_lastname_new').val(),//fullName[0],
						first_name = $('.modal-address.show #address_firstname_new').val(),//fullName.slice(1,fullName.length).join(' '),
						phone = $('#address_form_new').find('input[name="address[phone]"]').val(),
						province = $('#address_form_new').find('select[name="address[province]"] option:selected').val(),
						province_code = $('#address_form_new').find('select[name="address[province]"] option:selected').attr('data-code'),
						district = $('#address_form_new select[name="address[district]"] option:selected').val(),
						district_code = $('#address_form_new select[name="address[district]"] option:selected').attr('data-code'),
						ward = $('#address_form_new select[name="address[ward]"] option:selected').val(),
						ward_code = $('#address_form_new select[name="address[ward]"] option:selected').attr('data-code'),
						address = $('#address_form_new input[name="address[address1]"]').val(),
						type = $('#address_form_new input[name="address[type]"]:checked').val(),
						df_address = $('#address_form_new input[name="address[default]"]:checked').val();;

				var allowSubmit = true;

				//Kiểm tra đúng định dạng
				if(!KG.Helper.validatePhone(phone)){
					$('#address_form_new').find('input[name="address[phone]"]').parents('.form-group').addClass('is-invalid');
					allowSubmit = false;
				}
				else $('#address_form_new').find('input[name="address[phone]"]').parents('.form-group').removeClass('is-invalid');

				if(allowSubmit){
					var data = {
						"ward_code": ward_code,
						"ward": ward,
						"district_code": district_code,
						"district": district,
						"province_code": province_code,
						"province": province,
						"phone": phone,
						"last_name": last_name,
						"first_name": first_name,
						"country_code": "VN",
						"country": "Vietnam",
						"company": type,
						"address1": address,
						"address2": ''
					};
					$.ajax({
						url: '/account/addresses.js',
						type: 'POST',
						data: JSON.stringify(data),
						contentType: 'application/json',
						dataType: 'JSON',
						success: function(data){
							if(data.error){
								KG.Helper.SwalWarning(data.message,'Vui lòng kiểm tra lại thông tin!','warning',false,false,4000);
							}
							else{
								$('#addNewAddressModal').modal('hide');
								if (template === 'customers[account]') {
									Swal.fire({
										title: '',
										text: 'Địa chỉ mới đã được tạo thành công!',
										icon: 'success',
										showCancelButton: false,
										showConfirmButton: false,
										timer: 4000,
									}).then((result) => {
										window.location = '/account/addresses';
									});
								}
								else {
									Swal.fire({
										title: '',
										text: 'Địa chỉ mới đã được tạo thành công!',
										icon: 'success',
										showCancelButton: false,
										showConfirmButton: false,
										timer: 4000,
									}).then((result) => {
										setTimeout(function(){
											window.location.reload(); 
										},1500);
									});
								}
							}
						}
					});
				}
			});
		}
	},
  updateInfo: function(){
    $('#update_customer button').on('click',function(e){
      //debugger;
      if($(this).closest('#update_customer')[0].checkValidity() == true){
        e.preventDefault();
        var bd = $('#birthday').val().split('/');
        $('input[name="customer[birthday]"]').val(bd[1]+'/'+bd[0]+'/'+bd[2]);
        $('#update_customer').submit();
      }
    });
  }
}
KG.Search = {
  picked: {},
  firstPrice: [100000,20000000],
	totalPageItem: 0,
  keySearch: '',
  strFilter: '',
  allowLoadMore: true,
	init: function(){
		var that = this;
		that.searchApi();
    that.creatFilterPrice();
    that.actionFilter();
	},
  loadItems: function(page,keySearch,hasFilter){
    if( keySearch != '' || (hasFilter != undefined && hasFilter) ) {
      var url = '/search.js?q=filter=((title:product ** '+keySearch+'))&include=metafields[product]&page=' + page + '&limit=' + limit_search ;
      if(hasFilter != undefined && hasFilter){
        url = '/search.js?q=filter='+this.strFilter+'&include=metafields[product]&page=' + page + '&limit=' + limit_search ;
      }
     
      if(this.strFilter == '') this.strFilter = '((title:product ** '+keySearch+'))';
      $.ajax({
        type: 'GET',
        url: url,
        success: function(data){
          if (data.total > 0) {
            $('.js-ResultCount span').html(data.total + ' sản phẩm');
            KG.Search.totalPageItem = Math.ceil(data.total / limit_search);
            if(page < KG.Search.totalPageItem ){
              $('#js-btn-more').attr('data-current',page+1);
              $('#js-btn-more').attr('data-pages',KG.Search.totalPageItem);
              $('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-none').addClass('d-flex');
              $('.js-ResultCountCurrent').html(limit_search <= data.total ? page  * limit_search : data.total);
            }
            else{
              $('#js-btn-more').parents('.actions-wrapper--row').addClass('d-none').removeClass('d-flex');
            }

            $('.search-result-count').html(data.total + ' kết quả cho từ khoá ' + '<span class="search-keywords">' +keySearch+ '</span>');
            if(data.hasOwnProperty('products')){
              var items = '';
              data.products.map((item,ind) => {
                var number_loop = limit_search * (page - 1) + (ind + 1);
                items += `<div class="pro-tile pro-loop ${number_loop}">` + KG.Global.renderLoop(item,number_loop) + `</div>`;
              });
              
              if(page == 1) $('.js-results-render').html(items);
              else $('.js-results-render').append(items);
              
              $('.expanded-message').addClass('d-none');
              $('.results-section').removeClass('d-none');
            }
            else {
              var empty = "<div class='empty'>"+ textMain.text26 +"</div>";
              $('.js-results-render').html(empty);
              $('#js-btn-more').attr('data-current','').parents('.actions-wrapper--row').addClass('d-none').removeClass('d-flex');
              $('.results-section').addClass('d-none');
              $('.expanded-message').removeClass('d-none');
            }
            
          }
          else {
            if(hasFilter != undefined){
              $('.js-ResultCount span').html('0 sản phẩm');
      				$('#js-btn-more').attr('data-current',0).attr('data-pages',0)
              $('#js-btn-more').parents('.actions-wrapper--row').removeClass('d-flex').addClass('d-none');
      				$('.results-section .ajax-render .js-results-render').html('<div class="grid-empty alert-info">Chưa có sản phẩm nào trong danh mục này</div>');
              $('.search-body').addClass('empty_body');
      				
      				$('html,body').removeClass('open-overlay open-noscroll open-sidebar-filter');
            }
            else{
              $('.results-section').addClass('d-none');
              $('.expanded-message').removeClass('d-none');
              $('.actions-wrapper--row').addClass('d-none');
              $('.heading-inner--right').addClass('d-none');
            }
            
          }
          KG.Search.allowLoadMore = true;
          $('#mainLoading').removeClass('active');
        },
        error: function(){}
      });
    }
    else {
      alert('Vui lòng nhập từ khoá');
    }
  },
	searchApi: function(){	
    var self = this;
		$(document).on('click','#search-page form #go',function(e){
			e.preventDefault();
			$('#mainLoading').addClass('active');
			var q = $(this).parents('form').find('input[name=q]').val();
			keySearch = q;
			if ($('.js-results-render').length > 0){
				$('.js-results-render').html('');
			}
      $('.heading-inner--left h1').html('Kết quả tìm kiếm: '+ keySearch);
      history.replaceState(null, '', '/search?type=product&q='+keySearch.replace(/\ /g,'+'));
			self.loadItems(1,q);
		});
    
		$(document).on('click','#js-btn-more',function(e){
			e.preventDefault();
			var page = Number($(this).attr('data-current'));
      if (self.allowLoadMore ) {
        self.allowLoadMore = false;
  			self.loadItems(page,'',true);
      }
		});	
    
		$(document).ready(function() {
			if (!$.isEmptyObject(paramUrl)) { // check paramUrl khác rỗng
				$('#mainLoading').addClass('active');
				if (paramUrl.hasOwnProperty('q')) {
					if(paramUrl.q != undefined){
						self.keySearch = paramUrl.q.replace(/\+/g,' ');
						self.loadItems(1,self.keySearch);
					}
				}
				else {
          $('.heading-inner--right').addClass('d-none');
					$('.results-section').addClass('d-none');
					$('.expanded-message').removeClass('d-none');
					$('#mainLoading').removeClass('active');
				}
			}
			else {
        $('.heading-inner--right').addClass('d-none');
				$('.results-section').addClass('d-none');
				$('.expanded-message').removeClass('d-none');
				$('#mainLoading').removeClass('active');
			}
		});	

    if($(window).width() < 1024) {
			$('.sortBy').removeClass('dropdown-menu').appendTo($('.sort-box .layered-filter--group').addClass('sortbyfilter'));
			// Event open sort on mobile and ipad
			$(document).on("click", '.search-sort .box-title', function(e){
				$('body').toggleClass('lock-scroll');
				jQuery('.sort-wrapper--col').toggleClass('sort-visible');
				jQuery('.sort-wrapper--col .sort-box--scroll').css('height','250px');
				$('.refinement-section').toggleClass('has-filter');
			});
			// Event open filter on mobile and ipad
			$(document).on("click", '.search-filter .box-title', function(e){
				$('body').toggleClass('lock-scroll');
				jQuery('.filter-wrapper--col').toggleClass('filter-visible');
				jQuery('.filter-wrapper--col .filter-box--scroll').css('max-height','40vh');
				jQuery('.filter-wrapper--col .filter-box--scroll').css('max-height','34vh');
				$('.refinement-section').toggleClass('has-filter');
			});
			
			$(document).on("click", '.js-sortby-mb-click', function(e){
				 $( ".search-sort .box-title" ).trigger( "click" );
			});
			$(document).on("click", '.js-filter-mb-click', function(e){
				$( ".search-filter .box-title" ).trigger( "click" );
			});

			var t = $(".list-btn-mb");
			var e = $(".list-btn-mb").offset().top, 
					n = $(".mb-filter-wrapper").height();
			$(window).scroll(function() {
				if ($(document).scrollTop() > e){
					t.addClass("sticky-refinement-mobile");
					$(".results-section").css("padding-top", n + "px")
				}
				else {
					t.removeClass("sticky-refinement-mobile").removeAttr("style");
					t.removeClass("refinement-scroll-up");
					t.removeClass("refinement-scroll-down");
					$(".results-section").removeAttr("style");
				}
			});
		}
    else {
      $(document).on("click", '.btn-hide-filter', function(e){
        $('.search-body').toggleClass('hide-filter');
        $('.open_filter').toggleClass('d-none');
      });

      $(document).on("click", '.open_filter', function(e){
        $('.search-body').toggleClass('hide-filter');
        $('.open_filter').toggleClass('d-none');
      });
    }
	},
  creatFilterPrice: function(){},
  actionFilter: function(){
    var self = this;
		/* Apply Filter Picked At Sidebar */
		$('.filter-controls .btn-apply-filter-js').on('click',function(){
  		self.stringFilter();
		});
    
    /* Clear All Filter Picked At Sidebar */
		$('.filter-controls .btn-clear-filter-js').on('click',function(){
  		$('.filter-group input[type="checkbox"]').prop('checked',false);
			$('.layered-filter--tags .filter-tags').removeClass('opened');

			$('.sortBy input').prop('checked',false);
			$('.sortBy li').removeClass('active');
			$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
			$('.sortBy li input[value="manual"]').parents('li').addClass('default');

			self.stringFilter();
			$('body').removeClass('open-overlay open-noscroll open-sidebar-filter');
		});

		/* Checklist */
		$(document).on('click','.checkbox-list li > input',function() {
			$(this).parent().toggleClass('active');
			if ($(window).width() >= 992) {
  			self.stringFilter();
      }
			var indexTitle = $(this).parents('.filter-group').index();
			if ($(this).parents('.filter-group').find('input:checked').length > 0) {
				var textFilter = [];
				$(this).parents('.filter-group').find('input:checked').each(function() {
					var textVal = $(this).siblings('label').html();
					textFilter.push(textVal);
				});
				$('.filter-tags:eq(' + indexTitle + ') b').html(textFilter.join(', ')).parent().addClass('opened');
			} 
			else {
				$('.filter-tags:eq(' + indexTitle + ') b').html('').parent().removeClass('opened');
			}

			if ($('.checkbox-list li.active').length == 0) {
				$('.layered-filter--tags-wrapper').addClass('d-none');
			}
			else {
				$('.layered-filter--tags-wrapper').removeClass('d-none');
			}
		
		});
		
		/* Sort */
		$('input[name="cfb-sort-input"]').on('change',function(){
			$('.sortBy li').removeClass('default');
			$('.sortBy li').removeClass('active');
			$(this).parent().addClass('active');
			self.stringFilter();
		});

		/* Clear filter item */
		$('.filter-tags-remove').on('click',function(){
			var ind_tag = $(this).parent().index();
			if($(this).parent().hasClass('filter-tags_sortby')){
				$('.sortBy li').removeClass('active');
				$('.sortBy li input').prop('checked',false);
				$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
				$('.sortBy li input[value="manual"]').parents('li').addClass('default');
			}
      else{
        var type_filter = $(this).parent().attr('data-title');
        if(type_filter == 'Giá'){
          $( "#slider-range" ).slider('values',[100000,20000000]);
          delete self.picked.price;
        }
        else{
          $('.filter-group:eq('+ind_tag+') input:checked').click();
        }
      } 

			$(this).parent().removeClass('opened');
			self.stringFilter();
		});

		/* Clear all filter item */
		$('.filter-tags.remove-all').on('click',function(){
			$('.filter-group input[type="checkbox"]').prop('checked',false);
			$('.layered-filter--tags .filter-tags').removeClass('opened');

			$('.sortBy input').prop('checked',false);
			$('.sortBy li').removeClass('active');
			$('.sortbyfilter .sort-selected').text('Sản phẩm nổi bật');
			$('.sortBy li input[value="manual"]').parents('li').addClass('default');

			self.stringFilter();
			$('body').removeClass('open-overlay open-noscroll open-sidebar-filter');
		});
	},
  stringFilter: function(){
		var $this = this;
		var query = [];
		var change_url = ['q='+$this.keySearch];
		
		if($(window).width() < 992) {
			$('body').removeClass('lock-scroll');
			$('.filter-wrapper--col').removeClass('filter-visible');
			$('.sort-wrapper--col').removeClass('sort-visible');
			$('.refinement-section').removeClass('has-filter');
		}

		/* Filter Vendor */
		if($('#filter-vendor input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-vendor input:checked').each(function(){
				var vendor = $(this).attr('data-vendor');
				temp.push(vendor);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-vendor').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('vendor='+picked.join(','));
      this.picked.vendor = picked;
		}

    /* Filter Gender */
		if($('#filter-gender input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-gender input:checked').each(function(){
				var gender = $(this).attr('data-gender');
				temp.push(gender);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-gender').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('gender='+picked.join(','));
      this.picked.gender = picked;
		}
    
    /* Filter Color */
		if($('#filter-color input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-color input:checked').each(function(){
				var color = $(this).val();
				temp.push('(variantonhand_p1:product='+color+')');
				picked.push(color);
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-color').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('color='+picked.join(','));
      this.picked.color = picked;
		}
    
    /* Filter Type */
		if($('#filter-type input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-type input:checked').each(function(){
				var type = $(this).attr('data-type');
				temp.push(type);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-type').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('type='+picked.join(','));
      this.picked.type = picked;
		}

		/* Filter Metal */
		if($('#filter-metal input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-metal input:checked').each(function(){
				var metal = $(this).attr('data-metal');
				temp.push(metal);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-metal').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('metal='+picked.join(','));
      this.picked.metal = picked;
		}

		/* Filter Size */
		if($('#filter-size input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-size input:checked').each(function(){
				var size = $(this).attr('data-size');
				temp.push(size);
				picked.push($(this).val());
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-size').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('size='+picked.join(','));
      this.picked.size = picked;
		}

		/* Filter Price */
    if(this.picked.hasOwnProperty('price') && $('#filter-price #amount-range').length > 0){
      var temp = this.picked.price;
      query.push(`((price:product>=${temp[0]}) && (price:product<=${temp[1]}))`);
      var index_group = $('#filter-price').parents('.filter-group').index();
      $('.filter-tags:eq('+index_group+') b').text($('#amount-range').val());
      $('.filter-tags:eq('+index_group+')').addClass('opened');
      change_url.push('price='+temp.join(','));
		}
    
		/* Filter BST */
		if($('#filter-cate input:checked').length > 0){
			var temp = [];
			var picked = [];
			$('#filter-cate input:checked').each(function(){
				var cate = $(this).val();
				temp.push('(tag:product=*'+cate+')');
				picked.push(cate);
			});
			query.push('('+temp.join('||')+')');
			var index_group = $('#filter-cate').parents('.filter-group').index();
			$('.filter-tags:eq('+index_group+') b').text(picked.join(','));
			$('.filter-tags:eq('+index_group+')').addClass('opened');
			change_url.push('cate='+picked.join(','));
      this.picked.cate = picked;
		}

    var key = decodeURIComponent(this.keySearch);
		if(query.length > 0){
			query = `((title:product ** ${key})||(tag:product ** ${key})||(sku:product ** ${key})||(barcode:product ** ${key}))&&`+ query.join('&&');
		}
    else{
      query = `((title:product ** ${key})||(tag:product ** ${key})||(sku:product ** ${key})||(barcode:product ** ${key}))`;
      $('.layered-filter--tags-wrapper').addClass('d-none');
    }
    this.strFilter = '(' + encodeURIComponent( query ) + ')';

		/* Sort */
		if($('.sortBy li.active').length > 0){
			var sort = $('.sortBy li.active input').attr('data-filter');
			sort = 'sortby=' + sort;
			this.strFilter += '&' + sort;
			change_url.push('sort_by='+$('.sortBy li.active input').val());

			$('.sortbyfilter .sort-selected').text($('.sortBy li.active input').siblings('label').text());
			$('.filter-tags-sortby b').text($('.sortBy li.active input').siblings('label').text());
			$('.filter-tags-sortby').addClass('opened');
		}

		if($('.layered-filter--tags .filter-tags.opened').length > 0) $('.layered-filter--tags-wrapper').removeClass('d-none');
		else $('.layered-filter--tags-wrapper').addClass('d-none');

		//$('#collection-page .products-grid').html('');
		this.loadItems(1,'',true);

    /*
		history.pushState(null, "", window.location.pathname+( change_url.length > 0 ? '?'+change_url.join('&') : '') );
    */

		/* Save query string with key is string replace on URL. Target: After refresh with url can quick load result then backup options picked. */
		var logFilter = sessionStorage.getItem('query');
		logFilter = logFilter == null?{}:JSON.parse(logFilter);
		logFilter[change_url.join('&')] = $this.strFilter;
		sessionStorage.setItem('query',JSON.stringify(logFilter));
		
		var x = $('.grid-head').offset().top;
		KG.Helper.smoothScroll(x-140, 500);
	},
}

KG.Pages = {
	init: function(){
		var that = this;
    that.progressBarScroll();
    that.accordion();
    if(template.indexOf('about-us') > -1){
  		that.initAboutUs.init();
    }
    if(template.indexOf('nhuong-quyen') > -1){
  		that.initPartner.init();
    }
    if(template.indexOf('loyalty') > -1){
  		that.initLoyalty.init();
    }
    if(template.indexOf('wishlist') > -1){
      that.initWishlist.init();
    }
    if(template.indexOf('ldp-black-friday-') > -1){
      that.initBlackFriday1.init();
    }
	}, 
  progressBarScroll: function() {
		jQuery(window).on("scroll", function() {
			var viewedJetProgress = false;
			var viewedTextCounter = false;
			function isScrolledIntoView(elem) {
				var docViewTop = $(window).scrollTop() + 50;
				var docViewBottom = docViewTop + $(window).height();
				var elemTop = $(elem).offset().top + 50;
				var elemBottom = elemTop + $(elem).height();
				return ((elemTop <= docViewBottom) && (elemBottom >= docViewTop));
			}
			if ($('.section-counter ').length > 0) {
				if (isScrolledIntoView($(".section-counter")) && !viewedTextCounter) {
					viewedTextCounter = true;
					$('.section-counter .number').each(function() {
						$(this).prop('Counter', 0).animate({
							Counter: $(this).data('counter')
						}, {
							duration: 2500,
							easing: 'swing',
							step: function(now) {
								$(this).text(Math.ceil(now));
							}
						});
					});
				}
			}
		});
	},
  accordion: function() {
    var $accordion = $(".js-accordion");
    var $allPanels = $(" .accordion-panel").hide();
    var $allItems = $(".accordion-item");
    $accordion.on("click", ".accordion-toggle", function () {
      if($(this).parent('.accordion-item').hasClass('is-open')){
        $allPanels.slideUp();
        $allItems.removeClass("is-open");
      }
      else{
        if($('.accordion-item.is-open').length > 0){
          $allPanels.slideUp();
          $allItems.removeClass("is-open");
        }
        $(this).siblings().slideDown();
        $(this).parent().addClass('is-open');
      }
      
      
    });
  },
  initAboutUs: {
    init: function(){
      var that = this;
      that.toogle();
    }, 
    toogle: function(){
      if($(window).width() < 992){
    		$('.line-value .box-toggle .subtitle').click(function(e){
      		e.preventDefault();
    			$(this).siblings('.text').slideToggle(400);
          $(this).parents('.inner').toggleClass('open');
    		});
        $('.line-culture .box-toggle .top').click(function(e){
      		e.preventDefault();
    			$(this).siblings('.bottom').slideToggle(400);
          $(this).parents('.inner').toggleClass('open');
    		});
      }
    }
  },
  initPartner: {
    init: function(){
      var that = this;
      that.formRegister();
    }, 
    formRegister: function(){
       $(document).on('click','#register-partner .btn-submit',function(e){
        if($(this).closest('#register-partner form')[0].checkValidity() == true){
          e.preventDefault();
      
          var registerName       = $('#register-partner').find('#register-name').val(); // Họ và Tên
          var registerCompany 	 = $('#register-partner').find('#register-company').val(); // Tên
          var registerPhone      = $('#register-partner').find('#register-phone').val(); // Phone
          var registerMail     	 = $('#register-partner').find('#register-email').val(); // Mail
          var registerBody     	 = $('#register-partner').find('#register-body').val(); // Nội dung
      
          var registerMessage = '...' + ' \n - Công ty: ' + registerCompany + ' \n - Nội dung: ' + registerBody;
            $('[name="contact[name]"]').val(registerName);
            $('[name="contact[phone]"]').val(registerPhone);
            $('[name="contact[email]"]').val(registerMail);
            $('[name="contact[body]"]').val(registerMessage);
          
          grecaptcha.ready(function() {
            grecaptcha.execute('6LdD18MUAAAAAHqKl3Avv8W-tREL6LangePxQLM-', {action: 'submit'}).then(function(token) {
              $('#register-partner input[name="g-recaptcha-response"]').val(token);
              $.ajax({
                type: 'POST',
                url: $('#register-partner form').attr('action'),
                data: $('#register-partner form').serialize(),
                async: false,
                success: function(result) {
                  console.log(result);
                  if (result.indexOf('contact_posted=true') > -1 ){
                    Swal.fire({
                      title: 'Đăng ký thành công!',
                      text: 'Cảm ơn bạn đã đăng ký, chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất.',
                      html: '',
                      icon: 'success',
                      showCancelButton: false,
                      showConfirmButton: true,
                      confirmButtonText: 'OK',
                    }).then((result) => {
                      if (result.isConfirmed) {
                        location.reload();
                      } 
                    })	
                  } else {
                    var mess_err = $(result).find('errors').html();
                    Swal.fire({
                      title: 'Có lỗi xảy ra!',
                      text: 'Vui lòng đăng ký lại.',
                      html: '',
                      icon: 'error',
                      showCancelButton: false,
                      showConfirmButton: true,
                      confirmButtonText: 'OK',
                    }).then((result) => {
                      if (result.isConfirmed) {
                        location.reload();
                      } 
                    })	
                  }
                },
                error: function(xhr, textStatus, errorThrown) {}
              });
            });
          });
        }
      });
    }
  },
  initLoyalty: {
    init: function(){
      var that = this;
      that.toogle();
      that.tableTab();
    },
    toogle: function(){
      if($(window).width() < 992){
    		$('.line-toogle .line-title').click(function(e){
      		e.preventDefault();
    			$(this).siblings('.line-content').slideToggle(400);
          $(this).parents('.line-toogle').toggleClass('open');
    		});
      }
    },
    tableTab: function(){
      if($(window).width() < 992){
        $('.level-current').click(function(e){
      		e.preventDefault();
    			$(this).addClass('open');
    		});
        $(document).on('click','.line-loyalty .level-tablist .level',function(){
          var target = $(this).attr('data-level');
          var text = $(this).text();
          $('.line-loyalty .level-current').html(text);
          $('.line-loyalty .level-current').removeClass('open');
          $('.line-loyalty .level-tablist .level').removeClass('active');
          $('.line-loyalty .col-content').removeClass('open');
          $(this).addClass('active');
          $('.line-loyalty '+target+'.col-content').addClass('open');
        });
      }
    }
  },
  initWishlist: {
    init: function(){
      this.sliderCollection();
    },
    sliderCollection: function(){
      var id1 = $('#js-render-coll-1 .swiper-container').attr('data-id');
  		var titleColl1 = $('#js-render-coll-1 .swiper-container').attr('data-title');
  		var urlColl1   = $('#js-render-coll-1 .swiper-container').attr('data-handle');
      KG.Global.getItemSlide('pro-t1',id1,titleColl1,urlColl1,1,8,'#js-render-coll-1',function(){
        var swiper = new Swiper("#js-render-coll-1 .swiper-container", {
          loop: false,
          slidesPerView: 1.2,
          spaceBetween: 16,
          breakpoints: {
            735: {
              slidesPerView: 2,
            },
            1024: {
              slidesPerView: 4,
            },
            1460: {
              slidesPerView: 4,
            }
          },
          navigation: {
            nextEl: '#js-render-coll-1 .swiper-button-next',
            prevEl: '#js-render-coll-1 .swiper-button-prev',
          },
          scrollbar: {
            el: '#js-render-coll-1 .swiper-scrollbar',
            draggable: true
          }
        });
      });
    },
  },
  initBlackFriday1: {
    video_status: 'pause',
    init: function(){
      var self = this;
      KG.Index.sliderBannerHome();
      if($('.section-flash-bf1').length > 1) self.countDown(time_flash);
      self.videoModule();
      self.slide3Banner();
      if($('.grid-products').length > 0){
        $('.grid-products').each(function(){
          var handle = $(this).attr('data-handle'),
              limit = $(this).attr('data-limit');
          self.loadProduct(handle,limit);
        });
      }
    },
    videoModule: function(){
      var self = this;
      $('#start_video').on('click',function(e){
        e.preventDefault();
        $(this).toggleClass('start');
        if(self.video_status == 'pause'){
          if(!$(this).siblings('video').hasClass('up')) $(this).siblings('video').addClass('up');
          $(this).siblings('video')[0].play();
          self.video_status = 'play';
        }
        else{
          $(this).siblings('video')[0].pause();
          self.video_status = 'pause';
        }
      });
      $('#start_video').trigger('click');
    },
    loadProduct: function(handle,limit){
      function slideDesktop(target){
        if($(target).hasClass('one_row')){
          var option = {
            slidesPerView: 2,
            spaceBetween: 16,
            breakpoints: {
    					767: {
    						slidesPerView: 4,
                spaceBetween: 16,
    					}
    				},
            autoplay: {
              delay: 5000,
            },
          };
        }
        else{
          var option = {
            slidesPerView: 2,
            grid: {
              fill: 'row',
              rows: 2
            },
            spaceBetween: 16,
            breakpoints: {
    					767: {
    						slidesPerView: 4,
                spaceBetween: 16,
                grid: {
                  fill: 'row',
                  rows: 2
                }
    					}
    				},
            autoplay: {
              delay: 5000,
            },
          }
        }
        var swiper = new Swiper(target, option);
      }
      
      $.get(`/collections/${handle}/products.json?include=metafields[product]&page=1&limit=${limit}`).done(function(data){
        if(data.products.length > 0){
          var html_loop = '';
          data.products.map((item,ind) => {
            /*if(window.screen.width < 768 && (ind + 1) % 2 > 0){
              html_loop += `<div class="pro-loop-column">`;
            }*/
            html_loop += `<div class="swiper-slide"><div class="pro-loop">` + KG.Global.renderLoop(item) + `</div></div>`;
            /*if(window.screen.width < 768 && (ind + 1) % 2 == 0){
              html_loop += `</div>`;
            }*/
          });
          $('.grid-products[data-handle="'+handle+'"] .swiper-wrapper').html(html_loop);
          var target = $('.grid-products[data-handle="'+handle+'"]').attr('id');
          slideDesktop('#'+target);
        }
      });
    },
    countDown: function(date){
      var temp = date.split('/');
      date = temp[1] + '/' + temp[0] + '/' + temp[2];
      var countDownDate = new Date(date).getTime();

      // Update the count down every 1 second
      var x = setInterval(function() {
      
        // Get today's date and time
        var now = new Date().getTime();
      
        // Find the distance between now and the count down date
        var distance = countDownDate - now;
      
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
      
        // Display the result in the element with id="demo"
        document.getElementById("day").innerHTML = days;
        document.getElementById("hour").innerHTML = hours;
        document.getElementById("minute").innerHTML = minutes;
        document.getElementById("second").innerHTML = seconds;
      
        // If the count down is finished, write some text
        if (distance < 0) {
          clearInterval(x);
          //document.getElementById("text_countdown").innerHTML = "";
          $('.cus_countdown').hide();
        }
      }, 1000);
    },
    slide3Banner: function(){
      if(window.screen.width < 768){
        var swiper = new Swiper(".section-main-bf .slider-swiper", {
    			loop: true,
    			slidesPerView: 1,
    			spaceBetween: 1,
    			autoplay: false,
    			navigation: {
    				nextEl: ".section-main-bf .swiper-button-next",
    				prevEl: ".section-main-bf .swiper-button-prev",
    			}
    		});
      }
    }
  }
}
KG.Store = {
  init: function(){
		var that = this;
    that.stores();
  },
  stores: function(){
    var urlData = 'https://script.googleusercontent.com/a/macros/haravan.com/echo?user_content_key=5kfyreaZMoEaSlp03fZ25sjKWWricZk-OLu6Km_PSyWP4ZmyM29IP54JG5j-STCMZ7qVZKMjideDhrc27m98LZHeM7xZwE4uOJmA1Yb3SEsKFZqtv3DaNYcMrmhZHmUMi80zadyHLKDhsOetBAj8KXlpoiAPGQ2JelfDA88TH5pQ8TnBUl-pA5qa3uZqGdDbr8h3WBtMTz_k25tsGiSzOvAk9pMnzOoXXelGuzTry2HNfuNZgdTiDoPZcIsONqDaSRGxd7PY--Y&lib=MP16xYI5vTBp17uZ0rTq-t66G7HDSSQzj';
    var getData = {};
    var getData2 = {};
    
    function groupStoresByLocation(data) {
      var groupedData = {};
      $.each(data, function(index, store) {
        var brand = store["Thương hiệu"];
        var city = store["Tỉnh/Thành phố"];
        var district = store["Quận/Huyện"];
        if (!groupedData[brand]) {
          groupedData[brand] = {};
        }
        if (!groupedData[brand][city]) {
          groupedData[brand][city] = [];
        }
        /*if (!groupedData[brand][city]) {
          groupedData[brand][city] = {};
        }
        if (!groupedData[brand][city][district]) {
          groupedData[brand][city][district] = [];
        }
        groupedData[brand][city][district].push({
          "Store": store["Tên cửa hàng"],
          "Address": store["Địa chỉ"],
          "Phone": store["Điện thoại"],
          "Time": store["Giờ mở cửa"],
          "Iframe": store["Iframe"],
          "Images": store["Hình ảnh"]
        });
        */
        groupedData[brand][city].push({
          "Store": store["Tên cửa hàng"],
          "Address": store["Địa chỉ"],
          "Phone": store["Điện thoại"],
          "Time": store["Giờ mở cửa"],
          "Iframe": store["Iframe"],
          "Images": store["Hình ảnh"]
        });
        
      });
      return groupedData;
    }  
    function groupStoresByLocation2(data) {
      var groupedData2 = {};
      $.each(data, function(index, store) {
        var brand = store["Thương hiệu"];
        var city = store["Tỉnh/Thành phố"];
        var district = store["Quận/Huyện"];
        if (!groupedData2[city]) {
          groupedData2[city] = {};
        }
        if (!groupedData2[city][brand]) {
          groupedData2[city][brand] = [];
        }
        groupedData2[city][brand].push({
          "Store": store["Tên cửa hàng"],
          "Address": store["Địa chỉ"],
          "Phone": store["Điện thoại"],
          "Time": store["Giờ mở cửa"],
          "Iframe": store["Iframe"],
          "Images": store["Hình ảnh"]
        });
      });
      return groupedData2;
    }    
    
    function renderBrand(data){
      var option = "<option value=''>Chọn Thương hiệu</option>";
      $.each(data, function(brand,data){
        option += '<option value="'+brand+'">'+brand+'</option>';
      });
      $('.brand-select').html(option);  
    }
    function renderProvince(brand){
      var option = "<option value=''>Chọn Thành phố</option>";
      $.each(getData, function(i,v){
        if(i == brand){
          $.each(v, function(j,k){
            option += '<option value="'+j+'">'+j+'</option>';
          })
        }
      });
      $('.province-select').html(option);
    }
    /*
    function renderDistrict(brand,province){
      var option = "<option value=''>Chọn Quận/Huyện</option>";
      $.each(getData, function(m,n){
        if(m == brand){   
          $.each(n, function(i,v){
            if(i == province){
              $.each(v, function(j,k){
                option += '<option value="'+j+'">'+j+'</option>';
              })
            }
          })
        }
      });
      $('.district-select').html(option);
    }
    */
    
    function itemAddress(address){
      var html = "";
      address.map(item => {
        var linkFrame = item.Iframe;
        if(linkFrame != ''){
          linkFrame = linkFrame.split('src=')[1].split('"')[1];;
        }
        html += '<div class="item-store" data-maps="'+linkFrame+'">';
        html +=  '<div class="info-store--top">';
        html +=    '<div class="name-store"><span>'+item.Store+'</span></div>';
        html +=    '<div class="address-store"><span>'+item.Address+'</span></div>';
        html +=    '<div class="time-store"><svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="8" height="8" rx="4" fill="#4DDB97"/></svg><span>Mở cửa từ '+item.Time+'</span></div>';
        html +=  '</div>';
        html +=  '<div class="info-store--bottom">';
        html +=    '<div class="phone-store"><span>'+item.Phone+'</span></div>';
        if (item.Images != '') {
          html +=    '<div class="imgs-store"><div><img src="'+item.Images+'"></div></div>';
        }
        html +=  '</div>';
        html += '</div>';
      });
      return html;
    }

    function renderItemAddress(data) {
      var html = '';
      $('.listStore .list-result').html('').removeClass('list-loading');
      $.each(getData2, function(m,n){
        if(m == 'Hồ Chí Minh' || m == 'Hà Nội'){
          $.each(n, function(i,v){
            html = itemAddress(v);
            $('.listStore .list-result').append(html);
          });
        }
      });
      $('.list-result').addClass('list-height render-default');
    }

    $(document).on('click', '.js-btn-find-stores', function(){
      var brand    = $('.brand-select').val();
      var province = $('.province-select').val();
      var district = $('.district-select').val();
      var html = '';
      if(brand != ''){
        $.each(getData, function(m,n){
          if(m == brand){
             $.each(n, function(i,v){
              if(province != ''){
                  if(i == province){
                    html = itemAddress(v);
                  }
                }
                else {
                  html = itemAddress(v);
                }
              /*
             if(i == province){
                $.each(v, function(j,k){
                  if(district != ''){
                    if(j == district){
                      html = itemAddress(k);
                    }
                  }
                  else {
                    html = itemAddress(k);
                  }
                });
              }
              */
               
            });
          }
        });
      }
      //$('.text-result').removeClass('d-none');
      if(html != ''){
        $('.list-result').html(html);
        $('.list-result').addClass('list-height');
        $('.text-result span').html($('.list-result .item-store').length);
      }
    });  
    $(document).on('click', '.item-store', function(){
      $('.map-embed').addClass('map-loading');
      var maps = $(this).attr('data-maps');
      var frame = '<iframe src="'+maps+'" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
      $('.item-store').removeClass('active');
      $(this).addClass('active');
      $('.rightColStore .map-embed').html(frame);
      setTimeout(function() {
        $('.map-embed').removeClass('map-loading');
      },500);
    });
    $(document).on('change', '.brand-select', function(){
      var brand = $(this).val();
      renderProvince(brand);
    }); 
    /*$('.province-select').change(function(){
      var province = $(this).val();
      var brand    = $('.brand-select').val();
      renderDistrict(brand,province);
    });*/
    
    $.get(urlData, function(response){
      var groupedStores = groupStoresByLocation(response);
      var groupedStores2 = groupStoresByLocation2(response);
      getData = groupedStores;
      getData2 = groupedStores2;
      renderBrand(groupedStores);
      renderItemAddress(groupedStores2);
      //console.log(groupedStores);
      console.log(groupedStores2);
    });
  } 
}
KG.Blog = {
  init: function(){
		this.loadmore();
	},
	loadmore: function(){
		var total_page = 0, cur_page = 1 ;
		$(document).ready(function(){
			var curl = window.blog.curl;
			jQuery.ajax({
				url: curl+'?view=pagesize',
				async: false,//tắt bất đồng bộ
				success:function(data){
					total_page = parseInt(data);
					if (cur_page >= total_page ) {
						jQuery('#js-btn-loadmore').parent().remove();
					}
				}
			});
			jQuery(document).on("click","#js-btn-loadmore", function(){
				jQuery('#js-btn-loadmore').parent().remove();  
				if(cur_page < total_page){
					cur_page++;
					jQuery.ajax({
						url: curl + '?view=data&page=' + cur_page,
						success:function(data){
							jQuery('.blog-ajax').append(data);				
							$('.blog-posts').append('<div id="js-btn-loadmore" class="btn btn-dark"><a href="javascript:void(0)">Xem thêm</a></div>');
							if (cur_page >= total_page - 1 ) {
								jQuery('#js-btn-loadmore').parent().remove();
							}
						}
					});
				}
			});
		});
	}
}
KG.Article = {
  init: function(){
    this.related();
    this.banners();
    this.hots();
    this.cates();
    this.author();
    this.recommend();
  },
  related: function(){
    var swiper = new Swiper("#related-articles", {
      loop: false,
      slidesPerView: 1.5,
      spaceBetween: 16,
      breakpoints: {
        735: {
          slidesPerView: 1.5,
          spaceBetween: 16,
        },
        1024: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        1460: {
          slidesPerView: 2,
          spaceBetween: 20,
        }
      },
      navigation: {
        nextEl: '#related-articles .swiper-button-next',
        prevEl: '#related-articles .swiper-button-prev',
      },
      scrollbar: {
        el: '#related-articles .swiper-scrollbar',
        draggable: true
      }
    });
  },
  banners: function(){
    var swiper = new Swiper(".article_banners", {
      loop: false,
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: ".article_banners .swiper-pagination",
      },
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      }
    });
  },
  hots: function(){
    $.get("/search?q=filter=(tag:article=hot)&type=article&view=articles-hot").done(function(res){
      if(res.trim() != ''){
        $('.list_noted').html(res);
      }
      else{
        $('.article_noted').addClass("d-none");
      }
    });
  },
  cates: function(){
    $('.icon_toggle').on('click',function(){
      $(this).parents('.blog_parent').find('.blog_child').slideToggle();
      $(this).toggleClass('open');
    });
  },
  author: function(){
    if($('.article-author').length > 0 && author_info != null){
      if(author_info.data.image != ''){
        $('.author-img img, .article-author-image img').attr('src',author_info.data.image);
        $('.author-img, .article-author-image').removeClass('mask');
      }
      else{
        $('.author-img, .article-author-image').addClass('d-none');
      }

      if(author_info.data.chuc_vu != ''){
        $('#article-author-name-chucvu span').html(' - ' + author_info.data.chuc_vu);
      }

      var check_social = 0;
      if(author_info.data.link_facebook != ''){
        check_social++;
        $('#link_facebook a').attr('href',author_info.data.link_facebook);
        $('#link_facebook').removeClass('d-none');
      }
      if(author_info.data.link_twitter != ''){
        check_social++;
        $('#link_twitter a').attr('href',author_info.data.link_twitter);
        $('#link_twitter').removeClass('d-none');
      }
      if(author_info.data.link_instargam != ''){
        check_social++;
        $('#link_instargam a').attr('href',author_info.data.link_instargam);
        $('#link_instargam').removeClass('d-none');
      }
      if(author_info.data.link_pinterest != ''){
        check_social++;
        $('#link_pinterest a').attr('href',author_info.data.link_pinterest);
        $('#link_pinterest').removeClass('d-none');
      }
      if(author_info.data.link_youtube != ''){
        check_social++;
        $('#link_youtube a').attr('href',author_info.data.link_youtube);
        $('#link_youtube').removeClass('d-none');
      }

      if(check_social > 0){
        $('#article-author-socials').removeClass('d-none');
      }

      if(author_info.short != ''){
        $('#article-author-short').append('<svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.78125 11.3438V19.5078H0.242188V13.0625C0.242188 9.57292 0.658854 7.04688 1.49219 5.48438C2.58594 3.40104 4.31771 1.82552 6.6875 0.757812L8.40625 3.49219C6.97396 4.09115 5.91927 4.98958 5.24219 6.1875C4.5651 7.35938 4.1875 9.07812 4.10938 11.3438H7.78125ZM19.8906 11.3438V19.5078H12.3516V13.0625C12.3516 9.57292 12.7682 7.04688 13.6016 5.48438C14.6953 3.40104 16.4271 1.82552 18.7969 0.757812L20.5156 3.49219C19.0833 4.09115 18.0286 4.98958 17.3516 6.1875C16.6745 7.35938 16.2969 9.07812 16.2188 11.3438H19.8906Z" fill="black" fill-opacity="0.2"></path></svg>');
        $('#article-author-short').append(author_info.short);
      }
    }
  },
  recommend: function(){
    if($(".list_recommend").length > 0){
      var handle_recommend = $(".list_recommend").attr('data-list');
      var url = "/collections/" + handle_recommend + "/products.json?limit=10&include=metafields[product]";
      $.get(url).done(function(data){
        if(data.products.length > 0){
          var html_loop = '';
          data.products.map(item => {
            html_loop += `<div class="swiper-slide"><div class="pro-loop">` + KG.Global.renderLoop(item) + `</div></div>`;
          });
          $(".zone_recommend .list-products").html(html_loop);
          KG.Wishlist.initFavorites();
          var swiper = new Swiper(".zone_recommend .swiper-container", {
            loop: false,
            slidesPerView: 1.2,
            spaceBetween: 16,
            breakpoints: {
              735: {
                slidesPerView: 2,
              },
              1024: {
                slidesPerView: 3,
              },
              1460: {
                slidesPerView: 3,
              }
            },
            navigation: {
              nextEl: '.zone_recommend .swiper-button-next',
              prevEl: '.zone_recommend .swiper-button-prev',
            },
            scrollbar: {
              el: '.zone_recommend .swiper-scrollbar',
              draggable: true
            }
          });
        }
        else{
          $(".zone_recommend").addClass("d-none");
        }
      });
    }
  }
}

KG.LDPApril = {
	init: function(){
		var that = this;
		that.sliderBannerHome();
    that.sliderCateHome();
		that.sliderCollection();
		that.sliderModule();
    that.tabBrands();
    that.galleryAction();
    
    if(flashsale != null){
      that.checkTimeFlashsale();
    }
    
	},
  checkTimeFlashsale: function(){
    var self = this;
    const flashSaleData = flashsale;
    const now = new Date();
    const todayKey = `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`;
    const currentTime = now.toTimeString().split(' ')[0];
    const timeFrames = flashSaleData[todayKey] || [];
    let currentFrame = null;
    let currentFrameIndex = 0;
    function findCurrentFrame() {
      for (let i = 0; i < timeFrames.length; i++) {
        const timeRange = timeFrames[i].time.split(' - ');
        const timeStart = timeRange[0];
        const timeEnd = timeRange[1];
        if (currentTime >= timeStart && currentTime <= timeEnd) {
          currentFrameIndex = i;
          return timeFrames[i];
        }
      }
      return null;
    }
    currentFrame = findCurrentFrame();
    
    function getCurrentFrameDetails() {
      if (currentFrame) {
        return {
          limit: currentFrame.limit,
          handle: currentFrame.handle
        };
      }
      return null;
    }
    
    function displayFrameDetails() {
      const details = getCurrentFrameDetails();
      if (details) {
        self.sliderFlashsale(details.handle,details.limit);
      } 
      else {
        $('.section-flashsale-home').hide();
      }
    }
    
    function parseDate(dateString, timeString) {
      const [day, month, year] = dateString.split('/').map(Number);
      const [hours, minutes, seconds] = timeString.split(':').map(Number);
      return new Date(year, month - 1, day, hours, minutes, seconds);
    }
    
    function formatToISO(dateString, timeString) {
      const [day, month, year] = dateString.split('/');
      const [hours, minutes, seconds] = timeString.split(':');
      return year + '-' + month + '-' + day + 'T' + hours + ':' + minutes + ':' + seconds;
    }

    if (!currentFrame) {
      $('.section-flashsale-home').hide();
    } 
    else {
      const timeRange = currentFrame.time.split(' - ');
      const timeStart = parseDate(todayKey, timeRange[0]);
      const timeEnd = parseDate(todayKey, timeRange[1]);
      const timeStartNew = formatToISO(todayKey, timeRange[0]);
      const timeEndNew = formatToISO(todayKey, timeRange[1]);
      function tick(milliseconds) {
        if (milliseconds === 0) {
          $('.section-flashsale-home').hide();
        } 
        else {
          $('#label-due').html("Sắp diễn ra:");
        }
      }
      function tick2(milliseconds) {
        if (milliseconds === 0) {
          $('.section-flashsale-home').hide();
        } 
        else {
          $('#label-due').html("Đang diễn ra:");
        }
      }
      function complete() {
        currentFrameIndex++;
        if (currentFrameIndex < timeFrames.length) {
          console.log('123');
          //startCountdown(timeFrames[currentFrameIndex]);
        } 
        else {
          $('#label-due').html("Chờ đến khung giờ tiếp theo...");
        }
      }
      const element = document.getElementById('flashsale-countdown');
      Soon.create(element, {
        due: now < timeStart ? timeStartNew : timeEndNew,
        now: null,
        layout: "group label-small",
        face: "flip color-light",
        format: "d,h,m,s",
        labelsYears: null,
        labelsDays: null,
        labelsHours: 'Giờ',
        labelsMinutes: 'Phút',
        labelsSeconds: 'Giây',
        separateChars: false,
        scaleMax: "s",
        separator: "",
        singular: true,
        paddingDays: "00",
        eventTick: now < timeStart ? tick : tick2,
        eventComplete: complete
      });
      $('#flashsale-countdown').addClass('soon');
      displayFrameDetails();
    }
  },
  
  sliderFlashsale: function(handle,limit){ 
    var url_get = '/collections/' + handle + '/products.json?include=metafields[product]&page=1&limit='+limit;
    var page = 1;
		$.get(url_get).done(function(data){
			if(data.products.length > 0){
				$('.section-flashsale-home .list-products').html('');
				data.products.map((item,ind) => {
					var html_loop = `<div class="swiper-slide"><div class="pro-loop pro-flashsale ">` + KG.Global.renderLoop(item,limit*(page - 1) + (ind + 1)) + `</div></div>`;
					$('.section-flashsale-home .list-products').append(html_loop);
          KG.Global.slideImgLoop();
				});
			}
			var swiper = new Swiper(".section-flashsale-home .s-content > .swiper-container", {
        loop: false,
        slidesPerView: 1.2,
        spaceBetween: 16,
        breakpoints: {
          735: {
            slidesPerView: 2.5,
          },
          1024: {
            slidesPerView: 4,
          },
          1460: {
            slidesPerView: 4,
          }
        },
        navigation: {
          nextEl: '.section-flashsale-home .s-content > .swiper-button-nav > .swiper-button-next',
          prevEl: '.section-flashsale-home .s-content > .swiper-button-nav > .swiper-button-prev',
        },
        scrollbar: {
          el: '.section-flashsale-home .s-content > .swiper-scrollbar',
          draggable: true
        }
      });
		});
  },

	sliderBannerHome: function(){
		var swiper = new Swiper("#bannerldpApril-slider", {
			loop: $('#bannerldpApril-slider').find('[data-vbg]').length > 0 ? false : true,
			slidesPerView: 1,
			spaceBetween: 1,
			autoplay: $('#bannerldpApril-slider').find('[data-vbg]').length > 0 ? false : {
				delay:  3000,
			},
			navigation: {
				nextEl: "#bannerldpApril-slider .swiper-button-next",
				prevEl: "#bannerldpApril-slider .swiper-button-prev",
			}
		});

    if($('#bannerldpApril-slider').find('[data-vbg]').length > 0){
      $('#bannerldpApril-slider').find('[data-vbg]').youtube_background();
    }
	},

  sliderCateHome: function(){
    if($('#cates-slider').length > 0){
      var swiper = new Swiper("#cates-slider", {
  			loop: $('#cates-slider').find('[data-vbg]').length > 0 ? false : true,
  			autoplay: false,
  			navigation: {
  				nextEl: "#cates-slider .swiper-button-next",
  				prevEl: "#cates-slider .swiper-button-prev",
  			},
        breakpoints: {
          640: {
            slidesPerView: 1,
            spaceBetween: 0
          },
          768: {
            slidesPerView: 3,
      			spaceBetween: 51,
          }
        },
        
  		});

      if($('#cates-slider').find('[data-vbg]').length > 0){
        $('#cates-slider').find('[data-vbg]').youtube_background();
      }
    }

    if($('#cates-slider-2').length > 0){
      var swiper = new Swiper("#cates-slider-2", {
  			loop: true,
  			autoplay: {
  				delay:  2000,
  			},
        slidesPerView: 2,
        spaceBetween: 10,
        
  			navigation: {
  				nextEl: "#cates-slider-2 .swiper-button-next",
  				prevEl: "#cates-slider-2 .swiper-button-prev",
  			},
        breakpoints: {
          640: {
            slidesPerView: 2,
            spaceBetween: 10
          },
          768: {
            slidesPerView: 3,
      			spaceBetween: 10
          },
          1024: {
            slidesPerView: 4,
      			spaceBetween: 10
          }
        },
  		});
    }

    if($('#middle-slider').length > 0 && window.screen.width >= 768){
      var swiper = new Swiper("#middle-slider", {
  			loop: true,
  			autoplay: {
  				delay: 3000,
  			},
        slidesPerView: 2,
  			navigation: false
  		});
    }
	},
  
	sliderModule: function(){
    //Logo Brand
    
      new Swiper('#brandldpApril-slider', {
        loop: true,
        slidesPerView: 2,
        spaceBetween: 0,
        /*autoplay: {
          delay: 3000,
        },*/
        breakpoints: {
          640: {
            slidesPerView: 2,
          },
          767: {
            slidesPerView: 7,
          },
          1024: {
            slidesPerView: 9,
          }
        },
        navigation: {
          nextEl: "#brandldpApril-slider .swiper-button-next",
          prevEl: "#brandldpApril-slider .swiper-button-prev",
        }
      });
    
	},
  
	sliderCollection: function(){ 
		var id1 = $('#collection-slider-1 .swiper-container').attr('data-id');
		var titleColl1 = $('#collection-slider-1 .swiper-container').attr('data-title');
		var urlColl1   = $('#collection-slider-1 .swiper-container').attr('data-handle');
		
		var id3 = $('#collection-slider-3 .swiper-container').attr('data-id');
		var titleColl3 = $('#collection-slider-3 .swiper-container').attr('data-title');
		var urlColl3   = $('#collection-slider-3 .swiper-container').attr('data-handle');
		
    KG.Global.getItemSlide('pro-t1',id1,titleColl1,urlColl1,1,8,'#collection-slider-1',function(){
      var swiper1 = new Swiper("#collection-slider-1 .slider-collection.swiper-container", {
        loop: false,
        slidesPerView: 1.22,
        spaceBetween: 32,
        breakpoints: {
          767: {
            slidesPerView: 2.5,
          },
          1023: {
            spaceBetween: 40,
            slidesPerView: 4,
          },
          1460: {
            spaceBetween: 40,
            slidesPerView: 4,
          }
        },
        navigation: {
          nextEl: $('#collection-slider-1').hasClass('section-collection-2') ? '#collection-slider-1 .swiper-button-next': '#collection-slider-1 .s-heading .swiper-button-next',
          prevEl: $('#collection-slider-1').hasClass('section-collection-2') ? '#collection-slider-1 .swiper-button-prev': '#collection-slider-1 .s-heading .swiper-button-prev',
        }
      });
    });
    
    KG.Global.getItemSlide('pro-t1',id3,titleColl3,urlColl3,1,8,'#collection-slider-3',function(){
      var swiper3 = new Swiper("#collection-slider-3 .slider-collection.swiper-container", {
        loop: false,
        slidesPerView: 1.22,
        spaceBetween: 32,
        breakpoints: {
          767: {
            slidesPerView: 2.5,
          },
          1023: {
            spaceBetween: 40,
            slidesPerView: 4,
          },
          1460: {
            spaceBetween: 40,
            slidesPerView: 4,
          }
        },
        navigation: {
          nextEl: $('#collection-slider-3').hasClass('section-collection-2') ? '#collection-slider-3 .swiper-button-next': '#collection-slider-3 .s-heading .swiper-button-next',
          prevEl: $('#collection-slider-3').hasClass('section-collection-2') ? '#collection-slider-3 .swiper-button-prev': '#collection-slider-3 .s-heading .swiper-button-prev',

        }
      });
    });

    if($('#collection-slider-2').length > 0){
      var id2 = $('#collection-slider-2 .swiper-container').attr('data-id');
  		var titleColl2 = $('#collection-slider-2 .swiper-container').attr('data-title');
  		var urlColl2   = $('#collection-slider-2 .swiper-container').attr('data-handle');
      
      KG.Global.getItemSlide('pro-t2',id2,titleColl2,urlColl2,1,8,'#collection-slider-2',function(){
        var swiper2 = new Swiper("#collection-slider-2 .swiper-container", {
          loop: false,
          slidesPerView: 1.4,
          spaceBetween: 64,
          breakpoints: {
            735: {
              slidesPerView: 3,
            },
            1024: {
              slidesPerView: 3,
            },
            1460: {
              slidesPerView: 3,
            }
          },
          navigation: {
            nextEl: '#collection-slider-2 .s-nav .swiper-button-next',
            prevEl: '#collection-slider-2 .s-nav .swiper-button-prev',
          }
        });
      });
    }

    if($('#collection-slider-2-new').length > 0){
      var id_spec = $('#collection-slider-2-new .swiper-container').attr('data-id');
  		var titleCollSpec = $('#collection-slider-2-new .swiper-container').attr('data-title');
  		var urlCollSpec   = $('#collection-slider-2-new .swiper-container').attr('data-handle');
      
      KG.Global.getItemSlide('pro-t2', id_spec, titleCollSpec, urlCollSpec, 1, 8, '#collection-slider-2-new',function(){
        var swiper2 = new Swiper("#collection-slider-2-new .swiper-container", {
          loop: false,
          slidesPerView: 1.4,
          spaceBetween: 10,
          breakpoints: {
            735: {
              slidesPerView: 3,
            },
            1024: {
              slidesPerView: 3,
            },
            1460: {
              slidesPerView: 3,
            }
          },
          navigation: {
            nextEl: '#collection-slider-2-new .slider-collection-new .swiper-button-next',
            prevEl: '#collection-slider-2-new .slider-collection-new .swiper-button-prev',
          }
        });
      });
    }
	},
  
  tabBrands: function() {
    function sliderTab (ind) {
      new Swiper(ind, {
        loop: false,
        slidesPerView: 1.6,
        spaceBetween: 12,
        breakpoints: {
          767: {
            slidesPerView: 2.2,
          },
          991: {
            slidesPerView: 3,
          }
        },
        navigation: {
          nextEl: ind+" .swiper-button-next",
          prevEl: ind+" .swiper-button-prev",
        }
      });
    }
    $( ".section-brandcategory-tab .tab-content" ).each(function(){
  		var that = jQuery(this);
  		var id	= '#'+that.find('div[id*="brandcate-slider-"]').attr('id');
      sliderTab(id);
  	});
    $(document).on('click','.section-brandcategory-tab .tablist li a',function(e){
      e.preventDefault();
			var target = $(this).attr('data-tab');
			$('.section-brandcategory-tab .tablist li').removeClass('active-tab');
      $('.section-brandcategory-tab .tab-content').removeClass('active-tab show');
			$(this).parent().addClass('active-tab');
			$('#'+target).addClass('active-tab show');
		});
  },

  galleryAction: function(){
    $('[data-fancybox="gallery"]').fancybox({
			thumbs : {
				autoStart : false
			},
			buttons: [
				"zoom",
				"close"
			]
		});

    var swiper = new Swiper("#gallery-top-slider", {
			loop: true,
			slidesPerView: 1.22,
      spaceBetween: 15,
      centeredSlides: true,
      breakpoints: {
        767: {
          slidesPerView: 2.5,
          spaceBetween: 15
        },
        1023: {
          spaceBetween: 15,
          slidesPerView: 4,
          centeredSlides: false
        },
        1460: {
          spaceBetween: 15,
          slidesPerView: 5,
          centeredSlides: false
        }
      },
      navigation: false,
      autoplay: {
				delay: 3000,
			}
		});

    var swiper = new Swiper("#gallery-bottom-slider", {
			loop: true,
			slidesPerView: 1.22,
      spaceBetween: 15,
      centeredSlides: true,
      breakpoints: {
        767: {
          slidesPerView: 2.5,
          spaceBetween: 15,
        },
        1023: {
          spaceBetween: 15,
          slidesPerView: 4,
          centeredSlides: false
        },
        1460: {
          spaceBetween: 15,
          slidesPerView: 5,
          centeredSlides: false
        }
      },
      navigation: false,
      autoplay: {
				delay: 3000,
			}
		});
  }
}

KG.InitMain = function(){
	if(template == 'index' || template == 'index.flashsale' || template == 'index.dev'){
    KG.Index.init();
    if(window.use_index_v2){
      KG.IndexV2.init();
      /*
      setTimeout(function(){
        if($('.section-slider .item-video #vbg_cate_0').hasClass('youtube-background') > 0){
          $('.section-slider .item-video .mute-toggle').click();
        }
      },5000);
      */
    }
	}
	if(template == 'product'){
		KG.Product.init();
	}
	if(template.indexOf('collection') > -1){
		KG.Collection.init();
	}
	
  if(template.indexOf('stores-system') > -1){
		KG.Store.init();
	}
  if(template.indexOf('page.') > -1){
    if(template.indexOf('ldp-thang4-2025') > -1){
      KG.LDPApril.init();
    }
    else{
  		KG.Pages.init();
    }
	}
	if(template.indexOf('customer') > -1){
		KG.Account.init();
	}
	if(template.indexOf('search') > -1){
		KG.Search.init();
	}
  if(template.indexOf('blog') > -1){
    KG.Blog.init();
  } 
  if(template.indexOf('article') > -1){
    KG.Article.init();
  } 
}

$(document).ready(function(){
	KG.InitMain();
})

