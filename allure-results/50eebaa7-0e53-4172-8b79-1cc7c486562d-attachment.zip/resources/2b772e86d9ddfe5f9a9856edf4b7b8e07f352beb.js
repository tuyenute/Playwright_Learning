KG = {};
window.proInCartJS = {};
window.cartJS = {};
window.accountJS = {
	"email": null,
	"first_name": null,
	"last_name": null,
	"name": null,
	"phone": null,
	"logged": false,
	"id": ""
};
window.productCollect = [];

var template = window.shop.template;
var isText = window.textMain;
var isAccount = false;

/*Var Country*/
var countries = null;
const addressData = window.Countries;
/*Var App PE*/
var list_item_gift = [];

KG.Wishlist = { 
	init: function(){
		var that = this;
		that.addFavorites();
		that.initFavorites(function(){
			KG.Wishlist.renderFavorites();
		});
	},
	setFavorites: function(id, handle, title, cb){
		$.ajax({
			type: 'POST',
			url: 'https://onapp.haravan.com/wishlist/frontend/api/likeproduct',
			async: false,
			data: {
				shop: shop.myharavan_domain,
				customer_id: window.account.id,
				product_id: id,
				product_title: title,
				product_handle: handle,
				//product_price: price,
				email: window.account.email,
				last_name: window.account.last_name,
				first_name: window.account.first_name
			},
			success: function(data){
				cb(data);
			}
		})
	},
	unSetFavorites: function(id, handle, cb){
		$.ajax({
			type: 'POST',
			url: 'https://onapp.haravan.com/wishlist/frontend/api/unlikeproduct',
			async: false,
			data: {
				shop: shop.myharavan_domain,
				customer_id: window.account.id,
				product_id: id,
				product_handle: handle,
				email: window.account.email
			},
			success: function(data){
				cb(data);
			}
		})
	},
	listFavorites: function(ids,cb){
		var data = {
			shop: shop.myharavan_domain,
			customer_id: window.account.id,
			products: ids
		};
		if(ids == '') delete data.products;
		
		$.ajax({
			type: 'POST',
			url: 'https://onapp.haravan.com/wishlist/frontend/api/listproduct',
			data: data,
			success: function(data){
				cb(data);
			}
		})
	},
	renderFavorites: function(){
		try{
			if(typeof window.shop.favorites === 'object' && window.shop.favorites.length > 0){
				$.each(window.shop.favorites, function(i, v){
					$('.btn-wishlist[data-handle="'+v+'"]').addClass('active');
				})
			}
		}
		catch(err){

		}
	},
	initFavorites: function(cb){
		if(window.account.logged){
			if($('.pro-loop--wishlist').length > 0){
				var ids = [];
				$('.pro-loop--wishlist .btn-wishlist:not(.wish_loaded)').each(function(){
					ids.push($(this).attr('data-id'));
				});
				
				KG.Wishlist.listFavorites(ids,function(data){
					if(data.total > 0){
            $('.header-actions-list .action-wishlist span,.mb_wishlist span').html(data.total);
						$.each(data.data, function(i, v){
							if(typeof v.product_handle === 'string' && v.product_handle.length > 0){
								window.shop.favorites[v.product_id] = v.product_handle;
								$('.pro-loop--wishlist .btn-wishlist[data-id="'+v.product_id+'"]').addClass('active wish_loaded');
							}
						})
					}
					else{
						window.shop.favorites = {};
					}
					if(cb != undefined && typeof cb == 'function') return cb(data);
				});
			}
      else if(shop.template.indexOf('product') > -1){
        var id = $('.pr-button-wishlist').attr('data-id');
        KG.Wishlist.listFavorites(id,function(data){
					if(data.total > 0){
						$.each(data.data, function(i, v){
							$('.pr-button-wishlist[data-id="'+v.product_id+'"]').addClass('active');
						})
					}
					else{
						window.shop.favorites = {};
					}
					if(cb != undefined && typeof cb == 'function') return cb(data);
				});
      }
			else if(shop.template.indexOf('wishlist') > -1){
				KG.Wishlist.listFavorites('',function(data){
					if(data.total > 0){
						var handles = data.data.filter(wish => wish.product_id != 'NaN' && wish.product_id != '' && wish.product_id != null);
						handles = handles.map(wish => { return wish.product_handle });

            var arrRequest = [];
      			handles.map(item => {
      				var promise = new Promise(function(resolve, reject) {
      					$.ajax({
      						url:'/products/' + item + '.js',
      						success: function(product){
      							resolve(product);
      						},
      						error: function(err){
      							resolve('');
      						}
      					});
      				});
      				arrRequest.push(promise);
      			});
						
      			Promise.all(arrRequest).then(function(values) {
              var html_loop = '';
              
              values.map(item => {
                if(item != ''){
                  html_loop += `<div class="swiper-slide"><div class="pro-loop">` + KG.Global.renderLoop(item) + `</div></div>`;
                }
              });
              if(html_loop != ''){
                $('#js-render-wishlist .list-products').html(html_loop);
                KG.Wishlist.initFavorites();
                /*var swiper = new Swiper("#js-render-wishlist .swiper-container", {
                  loop: false,
                  slidesPerView: 1.2,
                  spaceBetween: 16,
                  breakpoints: {
                    735: {
                      slidesPerView: 2,
                    },
                    1024: {
                      slidesPerView: 4,
                    },
                    1460: {
                      slidesPerView: 4,
                    }
                  },
                  navigation: false,
                  scrollbar: {
                    el: '#js-render-wishlist .swiper-scrollbar',
                    draggable: true
                  }
                });*/
              }
              else{
                $('#js-render-wishlist').hide();
              }
            });

            /*
  						$.get('/search.js?q=filter=((id:product='+ids.join(')||(id:product=')+'))').done(function(prds){
  							if(prds.total > 0){
                  data.products.map((item,ind) => {
          					var html_loop = `<div class="swiper-slide"><div class="pro-loop ${type} ">` + KG.Global.renderLoop(item,limit*(page - 1) + (ind + 1)) + `</div></div>`;
          					$(target+' .list-products').append(html_loop);
          				});
  								$('#js-render-wishlist .list-products').html(KG.Global.renderItem(prds.products));
  								setTimeout(function(){
  									$('.collection--list .label-wishlist').addClass('active');
  								},800);
  							}
  						});
            */
					}
				});
			}
      else{
        var ids = [];
        KG.Wishlist.listFavorites(ids,function(data){
					if(data.total > 0){
            $('.header-actions-list .action-wishlist span,.mb_wishlist span').html(data.total);
						$.each(data.data, function(i, v){
							if(typeof v.product_handle === 'string' && v.product_handle.length > 0){
								window.shop.favorites[v.product_id] = v.product_handle;
								$('.pro-loop--wishlist .btn-wishlist[data-id="'+v.product_id+'"]').addClass('active wish_loaded');
							}
						})
					}
					else{
						window.shop.favorites = {};
					}
					if(cb != undefined && typeof cb == 'function') return cb(data);
				});
      }
		}
	},
	addFavorites: function(){
		$(document).on('click', '.js-wishlist', function(e){
			e.preventDefault();
			var self = $(this);
			var id = Number($(this).attr('data-id'));
			var handle = $(this).attr('data-handle');
			var title = $(this).attr('data-title');
			//var price = Number($(this).attr('data-price'));
			
			if(window.account.logged){
				if(self.hasClass('active')){
					KG.Wishlist.unSetFavorites(id, handle, function(info_wl){
						self.removeClass('active');
						
            $('.header-actions-list .action-wishlist span,.mb_wishlist span').html(info_wl.total);
            
						
					});
				}
				else{
					KG.Wishlist.setFavorites(id, handle, title, function(info_wl){
						self.addClass('active');
						if(shop.template == 'product'){
							KG.Product.info_wishlist[id] = info_wl;
						}
            $('.header-actions-list .action-wishlist span,.mb_wishlist span').html(info_wl.total);
					});
				}
			}
			else{
				KG.Helper.SwalWarning("","Vui lòng đăng nhập để tiến hành thao tác",'warning',false,true,3000,function(){
          sessionStorage.setItem('prevLink',window.location.pathname);
					window.location = '/account/login';
				});
			}
		});
		
		$(document).on('click','.label-wishlist',function(){
			var $this = $(this);
			var id = Number($(this).attr('data-id'));
			var handle = $(this).attr('data-handle');
			var title = $(this).attr('data-title');
			
			if(window.account.logged){
				var self = $(this);
				if(self.hasClass('active')){
					KG.Wishlist.unSetFavorites(id, handle, function(){
						self.removeClass('active');
						delete shop.favorites[id];
						delete KG.Product.info_wishlist[id];
						if(shop.template.indexOf('wishlist') > -1){
							$this.parents('.product-loop').remove();
						}
					});
				}
				else{
					KG.Wishlist.setFavorites(id, handle, title, function(info_wl){
						self.addClass('active');
						if(shop.template == 'product'){
							KG.Product.info_wishlist[id] = info_wl;
						}
						else{
							shop.favorites[id] = handle;
						}
					});
				}
			}
			else{
				KG.Helper.SwalWarning("","Vui lòng đăng nhập để tiến hành thao tác",'warning',false,true,20000,function(){
					window.location = '/account/login';
				});
			}
		});
	},
	getWishlistProduct: function(prdId,cb){
		$.ajax({
			type: 'POST',
			url: 'https://onapp.haravan.com/wishlist/frontend/api/getproduct',
			data: {
				shop: shop.myharavan_domain,
				customer_id: window.account.id,
				product_id: prdId
			},
			success: function(data){
				if(typeof cb === 'function') return cb(data);
			}
		})
	}
}

KG.Helper = {
	moneyFormat: function(number,format) {
		if(number != undefined){
			return number
				.toFixed(0) // always two decimal digits
				.replace(".", ",") // replace decimal point character with ,
				.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,") + "" + format // use , as a separator
		}
	},
	formatDate: function(date) { // account pages
		var days = {
			'1': 'Thứ 2',
			'2': 'Thứ 3',
			'3': 'Thứ 4',
			'4': 'Thứ 5',
			'5': 'Thứ 6',
			'6': 'Thứ 7',
			'7': 'Chủ Nhật'
		}
		var day = days[date.getDay()];
		var time = (date.getHours() < 10 ? ('0' + date.getHours()): date.getHours()) + ':' + (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
		var _date = (date.getDate() < 10 ? ('0' + date.getDate()):date.getDate());
		var month = date.getMonth() + 1;
		month = month < 10 ? ('Thg 0' + month): month;
		var year = date.getFullYear();
		return /*day + ', ' +*/ time + ', ' + _date + '/' + month + '/' + year
	},
	delayTime:function (func, wait) {
		return function() {
			var that = this,
					args = [].slice(arguments);
			clearTimeout(func._throttleTimeout);
			func._throttleTimeout = setTimeout(function() {
				func.apply(that, args);
			}, wait);
		};
	},
	uniques: function(arr) {
		var a = [];
		for (var i=0, l=arr.length; i<l; i++)
			if (a.indexOf(arr[i]) === -1 && arr[i] !== '')
				a.push(arr[i]);
		return a;
	},
	change_alias: function(alias){
		var str = alias;
		str = str.toLowerCase();
		str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,"a"); 
		str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g,"e"); 
		str = str.replace(/ì|í|ị|ỉ|ĩ/g,"i"); 
		str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g,"o"); 
		str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g,"u"); 
		str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y"); 
		str = str.replace(/đ/g,"d");
		str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\•|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g," ");
		str = str.replace(/ /g,"_");
		str = str.trim(); 
		return str;
	},  
	smoothScroll: function(a,b){
		$('body,html').animate({
			scrollTop : a
		}, b);
	},
	SwalWarning: function(title,content,icon,cancel,confirm,timeclose,callback){
		Swal.fire({
			title: title,
			text: content,
			icon: icon,
			timer: timeclose != undefined ? timeclose : false,
			showCancelButton: cancel,
			showConfirmButton: confirm,
			confirmButtonText: 'Đồng ý',
			cancelButtonText: 'Không',
		}).then((result) => {
			if (result.isConfirmed) {
				if(callback != undefined && typeof callback == 'function') return callback(true);
			} else if (result.isDenied) {
				//Swal.fire('Changes are not saved', '', 'info')
			}
      else if(result.isDismissed){
        if(callback != undefined && typeof callback == 'function') return callback(false);
      }
		})
	},
	plusQuantity: function() {
		if ( jQuery('input[name="quantity"]').val() != undefined ) {
			var currentVal = parseInt(jQuery('input[name="quantity"]').val());
			if (!isNaN(currentVal)) {
				jQuery('input[name="quantity"]').val(currentVal + 1);
			} else {
				jQuery('input[name="quantity"]').val(1);
			}
		}
		else {
			console.log('error: Not see elemnt ' + jQuery('input[name="quantity"]').val());
		}
	},
	minusQuantity: function() {
		if (jQuery('input[name="quantity"]').val() != undefined ) {
			var currentVal = parseInt(jQuery('input[name="quantity"]').val());
			if (!isNaN(currentVal) && currentVal > 1) {
				jQuery('input[name="quantity"]').val(currentVal - 1);
			}
		}else {
			console.log('error: Not see elemnt ' + jQuery('input[name="quantity"]').val());
		}
	},

  validatePhone: function(phone){
    var regex = /^0(96|97|98|32|33|34|35|36|37|38|39|90|93|70|71|71|76|77|78|79|91|94|81|82|83|84|85|86|87|88|89|99|92|56|58|95)[0-9]{7}$/;
    if(regex.test(phone)){
      return true;
    }
    return false;
  },
  checkPasswordValidation: function (value) {
    const isWhitespace = /^(?=.*\s)/;
    if (isWhitespace.test(value)) {
      return isText.text158;
    }
  
    const isContainsUppercase = /^(?=.*[A-Z])/;
    if (!isContainsUppercase.test(value)) {
      return isText.text159;
    }
  
    const isContainsLowercase = /^(?=.*[a-z])/;
    if (!isContainsLowercase.test(value)) {
      return isText.text160;
    }
  
    const isContainsNumber = /^(?=.*[0-9])/;
    if (!isContainsNumber.test(value)) {
      return isText.text161;
    }
  
    const isContainsSymbol = /^(?=.*[~`!@#$%^&*()--+={}\[\]|\\:;"'<>,.?/_₹])/;
    if (!isContainsSymbol.test(value)) {
      return isText.text162;
    }
  
    return null;
  },
  validateEmail: function($email) {
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return emailReg.test( $email );
  },
  
  //NEW
	getMiniCart: function(){
		var cart = null;
		jQuery.getJSON('/cart.js', function(cart, textStatus) {
			if(cart) {
				cartJS = cart;
				$('.mainHeader .header-actions-list .action-cart > a > span').html(cart.item_count);
				
				if(cart.items.length > 0){
					/*
          var prdIds = cart.items.map(x => {return x.product_id});
					var queryCart = "/search.js?q=filter=(id:product in "+prdIds.join(',')+")";

					$.ajax({
						type:'GET',
						async: false,
						url: queryCart+'&view=item-cart',
						success: function(search){
							window.proInCartJS = JSON.parse(search);
						}
					});
          */
          if(window.screen.width > 767){
            var prdRequest = [];
      			cart.items.map(item => {
      				var promise = new Promise(function(resolve, reject) {
      					$.ajax({
      						url:'/products/' + item.handle + '.js',
      						success: function(product){
      							resolve(product);
      						},
      						error: function(err){
      							resolve('');
      						}
      					});
      				});
      				prdRequest.push(promise);
      			});
      						
      			Promise.all(prdRequest).then(function(values) {
              values.map(prd => {
                window.proInCartJS[prd.id] = prd;
              }); 
              cartJS.items.map(x => {
                x.inAdmin = window.proInCartJS[x.product_id];
              });
              $('.mainHeader .header-actions-list .action-cart > a').addClass('has-item');
    					$('.mainHeader .header-actions-list .action-cart').addClass('allow-hover');
    					
    					$('#minicart .ajaxMinicart').html('');
    					$('#minicart .ajaxMinicart').append(KG.Helper.checkItemMiniCart(cartJS));
    					$('#minicart #minicart-subtotal div.number').html(KG.Helper.moneyFormat(cart.total_price/100, '₫'));	
              $('#minicart #minicart-total div.number').html(KG.Helper.moneyFormat(cart.total_price/100, '₫'));	
            });
          }
          else{
            window.location.href = '/cart';
          }
				}
				else {
					$('#minicart .ajaxMinicart').html('<div class="alert alert-warning text-center">Chưa có sản phẩm nào trong giỏ hàng </div>');
				}	
				
				$('#minicart #minicart-subtotal div.number').html(KG.Helper.moneyFormat(cart.total_price/100, '₫'));
        $('#minicart #minicart-total div.number').html(KG.Helper.moneyFormat(cart.total_price/100, '₫'));

        $('#mainLoading').removeClass('active');		
        $('body, html').addClass('open-cart');
        
      				
			}
		});
	},
	renderItemMiniCart: function(resultItem,type,line) {
		var itemOjProperties = {}
		var htmlLine = '';
    
		htmlLine +=	'<div class="item line-item '+((type == 'giftApp') ? 'line-gift' : '' )+'" data-line="'+(line+1)+'" data-variant-id="'+resultItem.variant_id+'" data-pro-id="'+resultItem.product_id+'">';
		htmlLine +=		'<div class="left">';
		htmlLine +=			'<div class="item-img">';
		htmlLine +=				'<a href="'+resultItem.url+'">';
		if ( resultItem.image == null ) {
			htmlLine +=					'<img src="//theme.hstatic.net/200000636033/1001033735/14/no-image.jpg" alt="'+resultItem.title+'" />';
		}
		else {
			htmlLine +=					'<img src="'+resultItem.image+'" alt="'+resultItem.title+'" />';
		}
		htmlLine +=				'</a>';
		htmlLine +=			'</div>';
		htmlLine +=		'</div>';

		htmlLine +=		'<div class="right">';
		htmlLine +=			'<div class="item-info">';
		
		htmlLine +=				'<div class="item-desc">';
    htmlLine +=			   '<span>'+resultItem.vendor+'</span>';
    htmlLine +=				 '<h3><a href="'+resultItem.url+'">'+resultItem.title+'</a></h3>';
    htmlLine +=				'</div>';
    
    if (type == 'comboApp' ){
			if (resultItem.price > 0){
				if(resultItem.price_original > resultItem.price) {
					htmlLine +=			'<div class="item-price">';
					htmlLine +=			 '<del>'+ KG.Helper.moneyFormat(resultItem.price_original/100,'₫')+'</del>';
          htmlLine +=      '<span>'+ KG.Helper.moneyFormat(resultItem.price/100,'₫')+'</span>';
          htmlLine +=     '</div>';
				}
				else {
					htmlLine +=			'<div class="item-price"><span>'+ KG.Helper.moneyFormat(resultItem.price/100,'₫')+'</span></div>';
				}
				htmlLine +=			'<div class="item-total-price d-none">';
				htmlLine +=				'<span>'+KG.Helper.moneyFormat(resultItem.line_price/100,'₫')+'</span>';
				htmlLine +=			'</div>';
			}
			else {
				htmlLine +=			'<div class="item-price"></div>';
				htmlLine +=			'<div class="item-total-price d-none"><span>Quà tặng</span></div>';															
			}
		}
		else if (type == 'giftApp' || type == 'giftOmni') {
			htmlLine +=			'<div class="item-price"></div>';
			htmlLine +=			'<div class="item-total-price d-none"><span>Quà tặng</span></div>';															
		}
		else {
			if (resultItem.price > 0){
				if(resultItem.price_original > resultItem.price) {
					htmlLine +=			'<div class="item-price">';
          htmlLine +=				'<del>'+KG.Helper.moneyFormat(resultItem.price_original/100,'₫')+'</del>';
					htmlLine +=				'<span class="hasSale">'+KG.Helper.moneyFormat(resultItem.price/100,'₫')+'</span>';
					htmlLine +=			'</div>';
				}
				else {
					var checkVr = proInCartJS[resultItem.product_id].variants.filter(variant => variant.id == resultItem.variant_id);
					if (checkVr.length > 0){
            checkVr = checkVr[0];
						htmlLine +=			'<div class="item-price">';
						if (checkVr.compare_price > resultItem.price) {
              htmlLine +=			'<del>'+KG.Helper.moneyFormat(checkVr.compare_price/100,'₫')+'</del>';
							htmlLine +=			'<span class="hasSale">'+KG.Helper.moneyFormat(resultItem.price/100,'₫')+'</span>';
						}
						else {
							htmlLine +=			'<span>'+KG.Helper.moneyFormat(resultItem.price/100,'₫')+'</span>';
						}
						htmlLine +=			'</div>';
					}
				}

				htmlLine +=			'<div class="item-total-price d-none">';
				htmlLine +=				'<span>'+KG.Helper.moneyFormat(resultItem.line_price/100,'₫')+'</span>';
				htmlLine +=			'</div>';

			}
			else {
				htmlLine +=			'<div class="item-price"></div>';
				htmlLine +=			'<div class="item-total-price d-none"><span>Quà tặng</span></div>';															
			}
		}
		
		htmlLine +=			'</div>';

		htmlLine +=			'<div class="item-meta">';

    htmlLine +=				 '<div class="list-variant">';
    
    resultItem.inAdmin.options.map((option,ind_opt) => {
       htmlLine +=       '<div class="variant-option">';
       htmlLine +=          '<select name="option_'+(ind_opt+1)+'_'+resultItem.variant_id+'" data-prd="'+resultItem.product_id+'" data-line="'+(line+1)+'">'     
         option.values.map(opt => {
           var selected = '';
           if(resultItem.variant_options.includes(opt)) selected = 'selected';
           htmlLine +=          '<option value="'+opt+'" '+selected+'>'+opt+'</option>';
         });
       htmlLine +=          '</select>';
       htmlLine +=       '</div>';
    });
    
   
    /*
    if(resultItem.variant_options[0] != 'Default Title' && resultItem.variant_options[0] != 'Default tittle') {
			if (resultItem.variant_options.length > 1) {
				if (resultItem.variant_options[0] != undefined) {
					htmlLine +=						'<div class="variant-option"><span class="text"> '+resultItem.variant_options[0]+'</span></div>';
				}
				if (resultItem.variant_options[1] != undefined) {
					htmlLine +=						'<div class="variant-option"><span class="text"> '+resultItem.variant_options[1]+'</span></div>';
				}
			}
			else {
				if (resultItem.variant_options[0] != undefined) {
					htmlLine +=						'<div class="variant-option"><span class="text"> '+resultItem.variant_options[0]+'</span></div>';
				}
			}
		}
    */
    htmlLine +=				 '</div>';

    htmlLine +=			'<div class="item-actions">';
   
    if (resultItem.price > 0){
      htmlLine +=			'<div class="item-quan">';
      // mini click qly
      htmlLine +=				'<div class="qty quantity-partent qty-click-mini">';
      if(resultItem.quantity > 1){
        htmlLine +=					'<button type="button" class="qtyminus-mini qty-btn">';
        htmlLine += 					'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3332 8H7.99984H2.6665" stroke="#111111" stroke-width="2" stroke-linecap="round"/></svg>';
        htmlLine +=					'</button>';
      }
      else {
        htmlLine +=					'<button type="button" class="qtyminus-mini qty-btn disabled" disabled>';
        htmlLine += 					'<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3332 8H7.99984H2.6665" stroke="#cfcfcf" stroke-width="2" stroke-linecap="round"/></svg>';
        htmlLine +=					'</button>';
      }
      htmlLine +=					'<input readonly data-vid="'+resultItem.variant_id+'" data-quantity="'+resultItem.quantity+'" data-product="'+resultItem.product_id+'" type="text" size="4" name="updates[]" min="1" id="updates_'+resultItem.variant_id+'" data-price="'+resultItem.price+'" value="'+resultItem.quantity+'" class="tc line-item-qty item-quantity-mini">';
      htmlLine +=					'<button type="button" class="qtyplus-mini qty-btn"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.00033 13.3334V8.00008M8.00033 8.00008V2.66675M8.00033 8.00008H13.3337M8.00033 8.00008H2.66699" stroke="#111111" stroke-width="2" stroke-linecap="round"/></svg></button>';
      htmlLine +=				'</div>';
      
      htmlLine +=			'</div>';
    }
    else {
      htmlLine +=				'<div class="item-quan">';
      htmlLine +=					'<span>Số lượng: '+resultItem.quantity+'</span>';
      htmlLine +=				'</div>';
    }

    if (resultItem.price > 0){
      htmlLine +=	'<div class="item-remove">';
      htmlLine += 		'<a href="javascript:void(0);" onclick="KG.Helper.deleteItemMiniCartSingle(' + (line+1) + ')" >';
      htmlLine +=				'<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3333 5.00008V4.33341C13.3333 3.39999 13.3333 2.93328 13.1517 2.57676C12.9919 2.26316 12.7369 2.00819 12.4233 1.8484C12.0668 1.66675 11.6001 1.66675 10.6667 1.66675H9.33333C8.39991 1.66675 7.9332 1.66675 7.57668 1.8484C7.26308 2.00819 7.00811 2.26316 6.84832 2.57676C6.66667 2.93328 6.66667 3.39999 6.66667 4.33341V5.00008M8.33333 9.58342V13.7501M11.6667 9.58342V13.7501M2.5 5.00008H17.5M15.8333 5.00008V14.3334C15.8333 15.7335 15.8333 16.4336 15.5608 16.9684C15.3212 17.4388 14.9387 17.8212 14.4683 18.0609C13.9335 18.3334 13.2335 18.3334 11.8333 18.3334H8.16667C6.76654 18.3334 6.06647 18.3334 5.53169 18.0609C5.06129 17.8212 4.67883 17.4388 4.43915 16.9684C4.16667 16.4336 4.16667 15.7335 4.16667 14.3334V5.00008" stroke="#8C8C8C" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      htmlLine +=			'</a>';
      htmlLine +=	'</div>';	
    }
  
    htmlLine +=			'</div>';
    
		htmlLine +=			'</div>';
	
		htmlLine +=		'</div>';
		htmlLine +=	'</div>';

		return htmlLine;
	},
	checkItemMiniCart: function(cart) {
		var itemOjProperties = {}
		var countPromo = 0;
		var typePromo = '';

		var Gift = []; //mã gift
		var titleGift = []; //tên program gift
		var lineGift = [];

		var checkItemGiftOmni = false;
		var checkItemGift = false;
		var checkItemCombo = false;

		for(var i = 0; i < cart.items.length; i++) {
			var item = cart.items[i];
			itemOjProperties = item.properties;
			for (const property in itemOjProperties){
				if(property.indexOf('PE-gift-item ') > -1) {
					checkItemGift = true;
					var temp3 = itemOjProperties[property];
					var titleTemp3 = temp3;
					var codeTemp3 = property.split(' ')[1].trim();
					if(Gift.includes(codeTemp3)) {
						var indexExist = Gift.indexOf(codeTemp3);
						lineGift[indexExist].push(i);
						continue;
					}
					else {
						Gift.push(codeTemp3);
						titleGift.push(titleTemp3);
						var temp33 = [];
						temp33.push(i);
						lineGift.push(temp33);
					}
				}
				else if(property.indexOf('Khuyến mãi') > -1) {
					checkItemGiftOmni = true;
				}		
			}
		}
    
		var promoGift   = lineGift.join(',').split(',');
		var promoSingle = lineGift.join(',').split(',');

		if(cart.item_count > countPromo) {
			var htmlHead = '';
			var parent = null;
			if (countPromo >= 0) {
				htmlHead += '<div class="cart-group single"></div>';
				$('#minicart .ajaxMinicart').append(htmlHead);
			} 
			else {
				parent = $('#minicart .ajaxMinicart');
			}
			for(var i = 0; i < cart.items.length; i++) {
				if (!promoGift.includes(i+"") ) {
					var item = cart.items[i];
					var htmlNormal =	KG.Helper.renderItemMiniCart(item,'',i,);
					$('#minicart .ajaxMinicart .cart-group.single').append(htmlNormal);
				}
        else{
          var item = cart.items[i];
					var htmlNormal =	KG.Helper.renderItemMiniCart(item,'giftApp',i,);
					$('#minicart .ajaxMinicart .cart-group.single').append(htmlNormal);
        }
			}
		}
	},
	UpdateChangeQtyMiniCart: function(comboCode,newQty,beforeQty,line) {
		var arrayUpdate = [];
		var comboItem = false;
		var listCart = document.querySelectorAll('[id^="updates_"]');
		if(window.cartJS.items[line].properties.hasOwnProperty('PE-combo-item')){
			comboItem = true;
			$.each(window.cartJS.items,function(i,v){
				if(v.properties.hasOwnProperty('PE-combo-item') && v.properties['PE-combo-item'].indexOf(comboCode) > -1){
					if(line == i){
						arrayUpdate.push(newQty);
					}
					else{
						arrayUpdate.push(v.quantity / beforeQty * newQty);
					}
				}
				else{
					arrayUpdate.push(v.quantity);
				}
			});		
		}
		else{
			$.each(window.cartJS.items,function(i,v){
				if(i == line){
					arrayUpdate.push(newQty);
				}
				else{
					arrayUpdate.push(v.quantity);
				}
			});
		}
		arrayUpdate = 'updates[]='+arrayUpdate.join('&updates[]=');
		var params = {
			type: 'POST',
			url: '/cart/update.js',
			data: arrayUpdate,
			dataType: 'json',
			success: function(data) { 
				window.cartJS = data;
				KG.Helper.getMiniCart();
				$('.box-viewcart').removeClass('js-loading');
			},
			error: function(XMLHttpRequest, textStatus) {
				Haravan.onError(XMLHttpRequest, textStatus);
			}
		};
		jQuery.ajax(params);
	},
	changeQtyItemMiniCart: function() {
		//SP lẻ
		$(document).on('click','.qty-click-mini .qtyplus-mini',function(e){
			e.preventDefault();
			var input = $(this).parent('.quantity-partent').find('input');
			var currentVal = parseInt(input.val());
			if (!isNaN(currentVal)) {
				input.val(currentVal + 1);
			} else {
				input.val(1);
			}
		});
		$(document).on('click',".qty-click-mini .qtyminus-mini",function(e) {
			e.preventDefault();
			var input = $(this).parent('.quantity-partent').find('input');
			var currentVal = parseInt(input.val());
			if (!isNaN(currentVal) && currentVal > 1) {
				input.val(currentVal - 1);
			} else {
				input.val(1);
			}
		});
		$(document).on('click','.qty-click-mini button[class*="qty"]',KG.Helper.delayTime(function(e){
			var beforeQty = parseInt($(this).parents('.item-quan').find('.txt-qty').html()),
					qtyChange = parseInt($(this).siblings('input').val());
			var line = parseInt($(this).parents('.line-item').attr('data-line')) - 1;
			$('.box-viewcart').addClass('js-loading');
			KG.Helper.UpdateChangeQtyMiniCart(null,qtyChange,beforeQty,line);
		},500));
		
	},
	deleteItemMiniCartSingle: function(line){
		var params = {
			type: 'POST',
			url: '/cart/change.js',
			data: 'quantity=0&line=' + line,
			dataType: 'json',
			success: function(cart) {				
				$('.mainHeader .header-actions-list .action-cart > a > span').html(cart.item_count);
				$('.mainHeader .header-actions-list .action-cart a').removeClass('has-item');
				$('.mainHeader .header-actions-list .action-cart').removeClass('allow-hover');
				$('#minicart .ajaxMinicart').html('');
				$('#minicart #minicart-subtotal div.number').html('');
				$('#minicart #minicart-total div.number').html('');

        PE.getCart(() => {
          getListBXSY();
        });
        
				KG.Helper.getMiniCart();	
				
			},
			error: function(XMLHttpRequest, textStatus) {
				Haravan.onError(XMLHttpRequest, textStatus);
			}
		};

    jQuery.ajax(params);

	},
  changeOptionMiniCart: function(){
    $(document).on('change','.list-minicart .variant-option select',function(){
      var v_id = $(this).attr('name').split('_')[2];
      var p_id = $(this).attr('data-prd');
      var line = $(this).attr('data-line');
      var quantity = $(this).parents('.line-item').find('.line-item-qty').val();
      var value = $(this).val();
      var index = Number($(this).attr('name').split('_')[1]);
      var option_other = $(this).parents('.list-variant').find('select[name="option_'+(index == 1 ? 2 : 1)+'_'+v_id+'"]').val();

      var variant_new = window.proInCartJS[p_id].variants.filter(variant => variant.options.includes(value) && variant.options.includes(option_other));
      if(variant_new.length > 0 && variant_new[0].available){
        $.get("/cart/change.js",{line: line, quantity: 0}).done(function(){
          $.post("/cart/add.js",{id: variant_new[0].id,quantity: quantity}).done(function(){
            KG.Helper.getMiniCart();
          });
        });
      }
      else{
        
      }
    });
  },
  clickMiniCheckout: function(){
    $(document).on('click','.js-btn-minicheckout',function(e){
      e.preventDefault();
      window.location.href = '/cart';
      /*
      if(!$.isEmptyObject(cartJS) && !cartJS.attributes.hasOwnProperty('bill_order_tax_code')){
        KG.Helper.SwalWarning("","Bạn có muốn xuất hoá đơn không",'warning',true,true,undefined, function(status){
          if(status != undefined){
            if(status){
              window.location.href = '/cart';
            }
            else{
              window.location.href = '/checkout'; 
            }
          }
        });
      }
      else{
        window.location.href = '/checkout'; 
      }
      */
    });
  }
}
KG.Global = {
	init: function(){
		var that = this;
		that.cartAjax();
		that.headerJS.init();
		that.footerJS();
		that.socialContact();
		that.popupContact();
		that.actionAccount();
		that.fixedMainHeader();
    that.sliderBrand();
    that.actionLoop();
    that.modalBanner();
    KG.Helper.changeQtyItemMiniCart();
    KG.Helper.changeOptionMiniCart();
    KG.Helper.clickMiniCheckout();
    KG.Wishlist.init();
	},
	cartAjax: function(callback){
		var self = this;
		$.ajax({
			type:'GET',
			url: '/cart.js',
			dataType: 'json',
			async: false,
			success: function(data){
				window.cartJS = data;
				$('.mainHeader .header-actions-list .action-cart > a > span').html(data.item_count);
				
				if(data.customer_id != null){
					window.accountJS.id = data.customer_id;
				}
				else {
					window.accountJS.id = window.account.id;
				}
				
				if(window.cartJS.items.length > 0){
					$('.mainHeader .header-actions-list .action-cart > a').addClass('has-item');
					$('.mainHeader .header-actions-list .action-cart').addClass('allow-hover');
					/*
					var listItem = '';
					var query = '/search?q=filter=';
					$.each(window.cartJS.items, function(i,item){
						(listItem == '') ? listItem = '(id:product='+item.product_id+')' : listItem = listItem + '||' + '(id:product='+item.product_id+')';
					});
					if(listItem != ''){
						query += encodeURIComponent('('+listItem+')'); 
						$.ajax({
							type:'GET',
							async: false,
							url: query+'&view=item-cart',
							success: function(search){
								if(!$.isEmptyObject(search)){
									window.proInCartJS = JSON.parse(search);
									window.cartJS.items.filter(x => {
										x.inAdmin = window.proInCartJS[x.product_id];
									});
								}
								if(!isAccount){
									isAccount = true;
									self.accountJS();
								}
								if(typeof callback === 'function') return callback(data);
							},
							error: function(x,y){
								if(!isAccount){
									isAccount = true;
									self.accountJS();
								}
							}
						});
					}
          */
          var handles = KG.Helper.uniques(window.cartJS.items.map(item => {return item.handle}));
          
          var prdRequest = [];
    			handles.map(handle => {
    				var promise = new Promise(function(resolve, reject) {
    					$.ajax({
    						url:'/products/' + handle + '.js',
    						success: function(product){
    							resolve(product);
    						},
    						error: function(err){
    							resolve('');
    						}
    					});
    				});
    				prdRequest.push(promise);
    			});
    						
    			Promise.all(prdRequest).then(function(values) {
            values.map(prd => {
              window.proInCartJS[prd.id] = prd;
            }); 
            window.cartJS.items.map(x => {
              x.inAdmin = window.proInCartJS[x.product_id];
            });

            $('#minicart .ajaxMinicart').html(KG.Helper.checkItemMiniCart(data));
            $('#minicart #minicart-subtotal div.number').html(KG.Helper.moneyFormat(data.total_price/100, '₫'));
            $('#minicart #minicart-total div.number').html(KG.Helper.moneyFormat(data.total_price/100, '₫'));
            if(callback != undefined) return callback();
          });
				}
				else {
					$('.mainHeader .header-actions-list .action-cart > a').removeClass('has-item');
          $('#minicart .ajaxMinicart').append('<div class="alert alert-warning text-center">Chưa có sản phẩm nào trong giỏ hàng </div>');
					if(!isAccount){
						isAccount = true;
						self.accountJS();
					}
          if(callback != undefined) return callback();
				}
			}
		});
	},
	accountJS: function(){
		var self = this;
		$.ajax({
			type:'GET',
			async: false,
			url: '/account.js',
			dataType: 'json',
			success: function(account){
				var id = accountJS.id;
				var user_info = localStorage.getItem('user_info');
				if(account.email != '' && account.email != undefined){
					accountJS = account;
					accountJS['id'] = id;
					accountJS['logged'] = true;
				}
				if(account.first_name != null && account.first_name != '') {
					accountJS['id'] = id;
					accountJS['logged'] = true;
				}
        
			}
		});
	},
	headerJS: {
		init: function(){
			var that = this;
			that.topbar();
			that.checkMegasub();
      that.hoverMenu();
			that.menuIconAction();
			that.menuMobile();
			that.searchAuto();
			that.miniCart();
		},
		checkMegasub: function(){
			if ($(window).width() > 1024) {
				$('.header-menu--list-item').each(function() {
					if ($(this).find('.header-menu--mega-sub').length === 0) {
						$(this).addClass('not-mega-sub');
					}
				});
			}	
		},
    hoverMenu: function () {
      jQuery('.header-menu--list').hover(function() {
        $(this).addClass('active');
      }, function() {
        $(this).removeClass('active');
      });
      jQuery('.header-menu--list-item.has-child').hover(function() {
        $('.menuOverlay').stop().delay(20).css({
           'height' : '100%',
           'opacity' : '1',
           'visibility' : 'visible'
        });
      }, function() {
        $('.menuOverlay').stop().delay(20).css({
           'height' : '0%',
           'opacity' : '0',
           'visibility' : 'hidden'
        });
      });
    },
		menuIconAction: function(){
			if($(window).width() < 1024){
				$('body').on('click', '#js-click-menu', function(e){
					e.preventDefault();
					if($(this).hasClass('active')){
						$('.mainHeader-bottom').removeClass('open');
					}
          else{
						$('.mainHeader-bottom').addClass('open');
					}
					$(this).toggleClass('active');
					$('body').addClass('lock-scroll');
				});

        $('body').on('click', '#js-click-search', function(e){
					e.preventDefault();
					if($(this).hasClass('active')){
						$('.mainHeader-bottom').removeClass('open');
					}
          else{
						$('.mainHeader-bottom').addClass('open');
            setTimeout(function(){
              $('#inputSearchAuto').focus();
            },500);
					}
					$(this).toggleClass('active');
					$('body').addClass('lock-scroll');
				});

        
				$('body').on('click', '.close-button button', function(e){
					e.preventDefault();
					$('.mainHeader-bottom').removeClass('open');
					$('.header-menu').removeClass('open open-sub');
					$('.header-menu--mega').hide();
					$('.header-menu--mega-item > a').removeClass('active');
					$('.header-menu--mega-sub').removeClass('open');
					$('.header-menu--mega-sub .back-menu > a').removeClass('active');
					$('.back-button').addClass('d-none');
					$('.header-actions-list li > a ').removeClass('active');
					$('body').removeClass('lock-scroll');
				});	
			}
      
      $('body').on('click','#js-click-search', function(e){
        e.preventDefault();
        if($(this).hasClass('active')){
          $('.header-search').removeClass('open');
        }
        else{
          $('.header-search').addClass('open');
          setTimeout(function(){
            $('#inputSearchAuto').focus();
          },500);
        }
        $(this).addClass('active');
        if($(window).width() < 1024){
          $('body').addClass('lock-scroll');
        }
      })
      $('body').on('click','#js-click-search-close', function(e){
        e.preventDefault();
        $('.header-search').removeClass('open');
        $('#js-click-search').removeClass('active');
      })
		},
		menuMobile: function(){
      $('body').on('click', '.open_child',function(){
        $(this).toggleClass('active');
        $(this).siblings('a').toggleClass('active');
        $(this).siblings('div,ul').slideToggle(200);
      });
      
			if($(window).width() < 1024){
				/*
        $('body').on('click', '.header-menu--list-item.has-child > a', function(e){
					e.preventDefault();
					$(this).toggleClass('active');
					$(this).siblings('.header-menu--mega').slideToggle(200);
				});
        */

				/*$('body').on('click', '.header-menu--mega-item > a', function(e){
					e.preventDefault();
					if($(this).next().length > 0){
						//$('.back-button').removeClass('d-none');
						$('.header-menu').addClass('open-sub');
            $(this).toggleClass('active');
						$(this).siblings('.header-menu--mega-sub').toggleClass('open');
						//$(this).siblings('.header-menu--mega-sub').find('.back-menu > a').addClass('active');
					}else{
						location.href=$(this).attr("href");
					}
				});
        */
        
				$('body').on('click', '.header-menu-btn .back-button button', function(e){
					$( ".back-menu > a.active" ).trigger( "click" );
				});	
        
				$('body').on('click', '.back-menu > a.active', function(e){
					e.preventDefault();
					$('.back-button').addClass('d-none');
					$('.header-menu').removeClass('open-sub');
					$(this).parents('.header-menu--mega-sub').removeClass('open');
				});					
			}
		},
		searchAuto: function(){
			$('body').click(function(evt) {		
				var target = evt.target;
				if (target.id !== 'searchform-wrapper' && target.id !== 'inputSearchAuto') {
					$("#searchform-wrapper").hide();		
          $("body").removeClass('open-search');		
				}
			});
			$('#inputSearchAuto').on('input', function(e) {
				if(e.target.value != '') {
					$('#searchform .btn-reset').removeClass('d-none');
				}
				else {
					$('#searchform .btn-reset').addClass('d-none');
				}
			});	
			$('#searchform .btn-reset').on('click', function(){
				$(this).addClass('d-none');
				$('#inputSearchAuto').val('').blur().focus();
				$("#ajaxSearchPrResults").hide();	
				$('.resultsContent').html('');
				if($(window).width() < 1024){
					$('body').removeClass('lock-scroll');
					$('.header-search').removeClass('open');
				}
			});
			$('#searchform').submit(function(e) {
				e.preventDefault();
				var q = $(this).find('input[name=q]').val();
				if(q.indexOf('script') > -1 || q.indexOf('>') > -1){
					alert('Từ khóa của bạn có chứa mã độc hại ! Vui lòng nhập lại từ khóa khác');
					$(this).find('input[name=q]').val('');
				}
				else{
					if( !q ) {
						window.location = '/search?q=*';
						return;
					}	else {
						window.location = '/search?q=' + q.replace(/\ /g,'+');
						return;
					}
				}
			});
			
			var $input = $('#searchform input[type="text"]');
			$input.bind('keyup change paste propertychange', KG.Helper.delayTime(function(){
				var key = $(this).val(),
						$parent = $(this).parents('.header-search'),
						$results = $(this).parents('.header-search').find('#searchform-wrapper');
				if(key.indexOf('script') > -1 || key.indexOf('>') > -1){
					alert('Từ khóa của bạn có chứa mã độc hại! Vui lòng nhập lại từ khóa khác');
					$(this).val('');
					$('#searchform input[type="text"]').val('');
				}
				else{
					if(key.length > 0 ){
						$(this).attr('data-history', key);
						$('#searchform input[type="text"]').val($(this).val());
						
						var q_follow = 'product', q_str = '';
						q_str = '/search?q=filter=('+encodeURIComponent('(title:product**' + key + ')&&(price:product>100)&&(id:product<>1052931853)')+')&type=product&view=ultimate-product';
						$.ajax({
							url: q_str,
							type: 'GET',
							async: true,
							success: function(datapr){
								$results.find('#ajaxSearchPrResults').html(datapr).addClass('resultsdata');		
								$results.find('.results-pr-wrapper').removeClass('d-none');
								var linkmore = '';
								if ($results.find('.dataMore').length > 0) {
									$results.find('.dataMore a').attr('href','/search?q='+key.replace(/\ /g,'+'));
								}
							}
						});
												
						$("#searchform").addClass("expanded");
						$results.fadeIn();	
            $("body").addClass('open-search');		
					}
					else{
						$('#searchform input[type="text"]').val($(this).val());
						$("#searchform").removeClass("expanded");
						$('.results-pr-wrapper').addClass('d-none');
						
						if ($('.suggestions-wrapper .suggestions').length > 0){
							$results.fadeIn();
							$results.find('#ajaxSearchPrResults').html('').removeClass('resultsdata');		
              $("body").addClass('open-search');		
						}
						else{
							$results.find('#ajaxSearchPrResults').html('');
							$results.fadeOut();
              $("body").removeClass('open-search');		
						}
					}
				}
			},500));

			$('body').on('click', '.searchform-close', function(e){
				e.preventDefault();
				$('.header-search').removeClass('open');
				$('body').removeClass('lock-scroll');
			});
		},
		miniCart: function(){
      $('body').on('click', '#js-click-cartmini', function(e){
        e.preventDefault();
        $('html,body').addClass('open-cart');
			});
			$('body').on('click', '.sidebar-cart .close-sidebar', function(e){
        e.preventDefault();
        $('html,body').removeClass('open-cart');
      });
      $('body').on('click', '.sidebar-overlay', function(e){
        e.preventDefault();
        $('html,body').removeClass('open-cart');
      });
		},
		topbar: function(){
			$('body').on('click', '#topbar-notify .btn-close', function(e){
				e.preventDefault();
				$('#topbar-notify').addClass('d-none');
			});
		}
	},
	footerJS: function(){
    //Toogle footer
    if($(window).width() < 768){
  		$('.footer-block.block-toogle .footer-title').click(function(e){
    		e.preventDefault();
  			$(this).toggleClass('active').siblings('.footer-content').slideToggle(400);
  		});
    }
    //Scroll to top
    var footerOffsetTop = $('#mainFooter').offset().top;
    $(window).scroll(function () {
        var scrollPosition = $(window).scrollTop() + $(window).height();

        if ($(window).scrollTop() > 500) {
            $('#back-to-top').addClass('open'); // Show the button when scrolled down
        } else {
            $('#back-to-top').removeClass('open'); // Hide the button when at the top
        }
        // Check if scrolled to footer
        if (scrollPosition >= footerOffsetTop) {
            $('#back-to-top').addClass('change-color');
        } else {
            $('#back-to-top').removeClass('change-color');
        }
    });

    $('#back-to-top').click(function (e) {
      e.preventDefault();
      $('html, body').animate({ scrollTop: 0 }, 200);
    });
	},
	socialContact: function(){
		if ($('.sidebar-listSharing').length > 0){
			$('.sidebar-contact--icons .box-contact,.sidebar-contact--lists .sidebar-close').on('click', function(e){
				if($('.sidebar-listSharing').hasClass('active')){
					$('body').removeClass('locked-scroll');
					$('.sidebar-listSharing').removeClass('active');
					$('.sidebar-listSharing').fadeOut(150);				
				}
				else{		
					$('.sidebar-listSharing').fadeIn(100);
					$('.sidebar-listSharing').addClass('active');
				}
			});
			$("body").on('click', function(event) {
				if ($(event.target).is('.sidebar-contact--dialog') || $(event.target).is('.addThiclose')) {
					event.preventDefault();
					$('body').removeClass('locked-scroll');
					$('.sidebar-listSharing').removeClass('active');
					$('.sidebar-listSharing').fadeOut(150);			
				}
			});
			$('.body-popupform form.contact-form').submit(function(e){
				var self = $(this);
				if($(this)[0].checkValidity() == true){
					e.preventDefault();
					grecaptcha.ready(function() {
						grecaptcha.execute('6LdD18MUAAAAAHqKl3Avv8W-tREL6LangePxQLM-', {action: 'submit'}).then(function(token) {
							self.find('input[name="g-recaptcha-response"]').val(token);
							$.ajax({
								type: 'POST',
								url:'/contact',
								data: $('.body-popupform form.contact-form').serialize(),			 
								success:function(data){		
									$('.modal-contactform.fade.show').modal('hide');
									Swal.fire({
										icon: "success",
										className: "newsletter-form-success",
										title: "Gửi lời nhắn thành công",
										text: "Thông báo sẽ tự động tắt sau 5 giây...",
										button: false,
										timer: 5000,
									}).then((result) => {
										location.reload(); 
									});
								},	
							})
						}); 
					});
				}
			});
		}
		if ($('.layoutProduct_scroll').length > 0 ) {
			if	(jQuery(window).width() < 768 ){
				var curScrollTop = 0;
				$(window).scroll(function(){	
					var scrollTop = $(window).scrollTop();
					if(scrollTop > curScrollTop  && scrollTop > 200 ) {
						$('.layoutProduct_scroll').removeClass('scroll-down').addClass('scroll-up');
					}
					else {
						if (scrollTop > 200 && scrollTop + $(window).height() + 150 < $(document).height()) {
							$('.layoutProduct_scroll').removeClass('scroll-up').addClass('scroll-down');	
						}
					}
					if(scrollTop < curScrollTop  && scrollTop < 200 ) {
						$('.layoutProduct_scroll').removeClass('scroll-up').removeClass('scroll-down');
					}
					curScrollTop = scrollTop;
				});
			}
		}
	},
	popupContact: function(){
		setTimeout(function(){
			if(sessionStorage.mega_modal == null ){
				$('#contactModal').modal('show');
			}
		},1000);
		$(document).on('click','.linkbanner-modal-contact', function(){
			$('#contactModal').modal('hide');
			if(sessionStorage.mega_modal == null ){
				sessionStorage.mega_modal = 'show' ;
			}
		});
		$(document).on('click','.modal-contact .close', function(e){
			e.preventDefault();
			$('#contactModal').modal('hide');
			if(sessionStorage.mega_modal == null ){
				sessionStorage.mega_modal = 'show' ;
			}
		});
		$(".modal-contact").on('hidden.bs.modal', function(){
			if(sessionStorage.mega_modal == null ){
				sessionStorage.mega_modal = 'show' ;
			}
		});
	},
	
	renderLoop: function(data,ind){
		if(typeof data.tags == 'string'){
			data.tags = data.tags.split(',');			
		}
    if (!data.hasOwnProperty('url')) {
      data.variants[0].compare_at_price = Number(data.variants[0].compare_at_price)*100;
      data.variants[0].price = Number(data.variants[0].price)*100;
    }
		
		var img_desk = 'https://theme.hstatic.net/200000726949/1001078399/14/noimage.jpg';
		var img_mb = 'https://theme.hstatic.net/200000726949/1001078399/14/noimage.jpg';
		
		// Image
		if(data.featured_image != '' && data.featured_image != null){
			img_mb = Haravan.resizeImage(data.featured_image,'large');
			img_desk = Haravan.resizeImage(data.featured_image,'grande');
		}		
		if(data.image != '' && data.image != null){
			img_mb = Haravan.resizeImage(data.image.src,'large');
			img_desk = Haravan.resizeImage(data.image.src,'grande');
		}
		
		//Link product
		var url_prod = data.hasOwnProperty('url') ? data.url : '/products/'+data.handle;

		var logo_collab = '', title_collab = '';
		/*KG_tag.theme.tag.map((value,index) => {
			if(value != "null" && data.tags != null){
				if(data.tags.includes(value) && logo_collab == ''){
					logo_collab = KG_tag.theme.icon[index];
					title_collab = KG_tag.theme.tag[index1];
					//return false;
				}
			}
		});*/
		
		var tag_normal = '';
		/*KG_tag.normal.tag.map((value2,index2) => {
			if(value2 != "null" && data.tags != null){
				if(data.tags.join(',').indexOf(value2) > -1 && tag_normal == ''){
					tag_normal  = KG_tag.normal.icon[index2];
					//return false;
				}
			}
		});*/
		
		/*Check tag Badge*/
		var getTagBadge = data.tags == null ? [] : data.tags.filter((value) => value.indexOf('badge') > -1);
		var valTaBbadge	= 0;
		if(getTagBadge.length > 0){
			valTaBbadge = getTagBadge[0].split(':')[1];
		}

    /* Check tag NEW */
    var getTagNew = data.tags == null ? [] : data.tags.filter((value) => value == 'NEW');
    var html_label_new = '';
    if(getTagNew.length > 0){
      html_label_new = `<div class="pro-loop--labels"><span class="label-s1 tag-badge">NEW</span></div>`;
    }

    /* Check tag pre-order */
    var getTagPreOrder = data.tags == null ? [] : data.tags.filter((value) => value == 'pre-order');
    var html_label_pre_order = '';
    if(getTagPreOrder.length > 0){
      html_label_pre_order = `<div class="pro-loop--labels label-pre"><span class="label-s2 tag-badge">Pre-Order</span></div>`;
    }

    /* Check tag gift */
    var getTagGift = data.tags == null ? [] : data.tags.filter((value) => value == 'gift');
    var html_label_gift = '';
    if(getTagGift.length > 0 && icon_gift != ''){
      html_label_gift = `<div class="pro-loop--labels label-gift"><img src="${icon_gift}" /></div>`;
    }

    /* Check array tag setting */
    var html_label_setting = '';
    $.each(loop_label,function(tag_setting,data_setting){
      if(data.tags.filter((value) => value == tag_setting).length > 0){
        if(html_label_setting == '' ) html_label_setting += `<div class="pro-loop--labels">`; 
        if(data_setting.src != ''){
          html_label_setting += `<span class="label-s3 tag-badge"><img src="${data_setting.src}" alt="${tag_setting}" /></span>`;
        }
        else if(data_setting.text != ''){
          html_label_setting += `<span class="label-s3 tag-badge">${data_setting.text}</span>`;
        }
      }
    });
    if(html_label_setting != ''){
      html_label_setting += '</div>';
    }
    
		//Check Price
		var sale = 0, del = 0;
		var compare_at_price = Number(data.variants[0].compare_at_price);
		var price = Number(data.variants[0].price);
		if(compare_at_price > price){
			del = data.hasOwnProperty('url') ? compare_at_price : compare_at_price;
			del = Haravan.formatMoney(del,shop.moneyFormat);
			sale = Math.round((compare_at_price - price)/compare_at_price * 100);
		}

    var find_color = data.options.filter(check => check.name.indexOf('Màu sắc') > -1);
    var find_images = [];
    var temp_color = [];
    var html_colors = '';
    var src_images = [];
    if (find_color.length > 0) {
      if (data.hasOwnProperty('url')) {
        find_color[0].values.map(item => {
          if(!temp_color.includes(item)){
            var getVariant = data.variants.filter(variant => variant.option1 == item);
            if(getVariant.length > 0){
              src_images.push(getVariant[0].featured_image);
            }
            temp_color.push(item);
          }
        });
        if(src_images.length > 0 ){
         src_images.map((item,ind) => {
           if (item != null) {
             html_colors += `<li class="swatch-item"><span class="bg ${data.vendor == 'CHRISBELLA'?'type-2':'type-1'} default" style="background-image:url(${item.src})"></span></li>`;
           }
         });
        }
        else {
          find_color[0].values.map((color,ind) => {
            html_colors += `<li class="swatch-item"><span class="bg default color-${KG.Helper.change_alias(color)}" data-option="${color}" data-handle=""></span></li>`;
          });
        }
      }
      else {
        find_color[0].values.map(item => {
          if(!temp_color.includes(item)){
            var getVariant = data.variants.filter(variant => variant.option1 == item);
            if(getVariant.length > 0){
              find_images.push(getVariant[0].image_id);
            }
            temp_color.push(item);
          }
        });
        find_images.map(item => {
          var getSrc = data.images.filter(a => a.id == item);
           if (getSrc.length > 0){
            src_images.push(getSrc[0].src);
          }
        });
        if(src_images.length > 0 ){
          src_images.map((img,ind) => {
            html_colors += `<li class="swatch-item"><span class="bg ${data.vendor == 'CHRISBELLA'?'type-2':'type-1'} default" style="background-image:url(${img})"></span></li>`;
          });
        }
      }
    } 
    
		var html_button = '';
		var sku_available = data.variants.filter(v => v.available );
    var v_id = data.variants[0].id;
    var price_quickview = Haravan.formatMoney(data.hasOwnProperty('url') ? data.variants[0].price : data.variants[0].price ,shop.moneyFormat);
    if(sku_available.length > 0) v_id = sku_available[0].id;
    
		html_button += `
      <div class="pro-loop--buttons" data-view="${template}">  
        <button aria-label="Xem nhanh" class="pro-action quick-view full" data-variantid="${v_id}" data-price="${price_quickview}" data-handle="${url_prod}" data-id="${data.id}" data-variantid="${data.variants[0].id}"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.0001 4.16667V15.8333M4.16675 10H15.8334" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>
        <button aria-label="Thêm vào giỏ" class="pro-action add-to-cart" data-id="${data.id}" data-variantid="${v_id}">
          <svg class="ic-added" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
          <svg class="ic-add" width="20" height="20" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6.5 4V9M4 6.5H9M3.875 12.125H9.125C10.1751 12.125 10.7001 12.125 11.1012 11.9206C11.454 11.7409 11.7409 11.454 11.9206 11.1012C12.125 10.7001 12.125 10.1751 12.125 9.125V3.875C12.125 2.8249 12.125 2.29985 11.9206 1.89877C11.7409 1.54596 11.454 1.25913 11.1012 1.07936C10.7001 0.875 10.1751 0.875 9.125 0.875H3.875C2.8249 0.875 2.29985 0.875 1.89877 1.07936C1.54596 1.25913 1.25913 1.54596 1.07936 1.89877C0.875 2.29985 0.875 2.8249 0.875 3.875V9.125C0.875 10.1751 0.875 10.7001 1.07936 11.1012C1.25913 11.454 1.54596 11.7409 1.89877 11.9206C2.29985 12.125 2.8249 12.125 3.875 12.125Z" stroke="#110E11" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>  
      </div>`;		
		
		var html_loop = `
				<div class="pro-loop--wrap">
							<div class="pro-loop--head">
								${html_label_new}
                ${html_label_pre_order}
                ${html_label_gift}
                
                ${html_label_setting}
								<div class="pro-loop--img">
									<picture class="has-hover">
										<source data-srcset="${img_desk}" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" media="(min-width: 768px)">
										<source data-srcset="${img_mb}" srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" media="(max-width: 767px)">
										<img class="lazyload img-default" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" data-src="${img_desk}" alt="${data.title}">
									</picture>
								</div>
								<a href="${url_prod}" class="pro-loop--link"></a>
								<div class="pro-loop--wishlist">
									<button type="button" class="btn-wishlist js-wishlist" data-type="wishlist" data-title="${data.title}" data-handle="${data.handle}" data-id="${data.id}" data-price="${data.hasOwnProperty('url') ? data.variants[0].price : data.variants[0].price}">
										<svg class="ic-heart filled" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.99437 4.27985C8.32825 2.332 5.54987 1.80804 3.46233 3.59168C1.37478 5.37532 1.08089 8.35748 2.72025 10.467C4.08326 12.2209 8.20823 15.9201 9.56017 17.1174C9.71142 17.2513 9.78705 17.3183 9.87526 17.3446C9.95225 17.3676 10.0365 17.3676 10.1135 17.3446C10.2017 17.3183 10.2773 17.2513 10.4286 17.1174C11.7805 15.9201 15.9055 12.2209 17.2685 10.467C18.9079 8.35748 18.6498 5.35656 16.5264 3.59168C14.403 1.8268 11.6605 2.332 9.99437 4.27985Z" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                    <svg class="ic-heart" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.99437 4.27985C8.32825 2.332 5.54987 1.80804 3.46233 3.59168C1.37478 5.37532 1.08089 8.35748 2.72025 10.467C4.08326 12.2209 8.20823 15.9201 9.56017 17.1174C9.71142 17.2513 9.78705 17.3183 9.87526 17.3446C9.95225 17.3676 10.0365 17.3676 10.1135 17.3446C10.2017 17.3183 10.2773 17.2513 10.4286 17.1174C11.7805 15.9201 15.9055 12.2209 17.2685 10.467C18.9079 8.35748 18.6498 5.35656 16.5264 3.59168C14.403 1.8268 11.6605 2.332 9.99437 4.27985Z" stroke="#262626" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                  </button>
								</div>
								${html_button}
                <div class="pro-loop--swatch ${html_colors == ''?'d-none':''}">
									<ul class="swatch-list">${html_colors}</ul>
                  <a class="more" href="${url_prod}"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 2.5V9.5M2.5 6H9.5" stroke="#6D6D6D" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"></path></svg></a>
								</div>		
							</div>
							<div class="pro-loop--body">
                <div class="pro-loop--vendor">
                ${data.vendor}
                </div>
								<h3 class="pro-loop--title"><a href="${url_prod}" title="${data.title}">${data.title}</a></h3>
                <div class="pro-loop--prices">
                  <div class="price">
                    <span data-price="${data.variants[0].price}" class="${sale == 0?'normal':'hightlight'}">${Haravan.formatMoney(data.hasOwnProperty('url') ? data.variants[0].price : data.variants[0].price ,shop.moneyFormat)}</span>
                    <del class="${sale == 0?'d-none':''}">${del}</del>
                  </div>
                  <div class="percent ${sale == 0?'d-none':''}"><span>${sale}% off</span></div>
                </div>
							</div>
						</div>
            <a href="${url_prod}" class="pro-btn-link"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.875 6H10.125" stroke="white" stroke-width="0.838457" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 1.875V10.125" stroke="white" stroke-width="0.838457" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Shop now</span></a>
      `;
		return html_loop;
	},
  actionLoop: function(){
    var self = this;
    $(document).on('click','.pro-loop--buttons .quick-view',function(){
      var count_variant = $(this).parent().siblings('.pro-loop--swatch').find('.swatch-item').length;
      var vId = $(this).attr('data-variantid');
      if(count_variant > 1) window.location.href = $(this).attr('data-handle');
      else{
        $.ajax({
          url: '/cart/add.js',
          type: 'POST',
          data: {
            id: vId,
            quantity: 1
          },
          success: function(){
            self.cartAjax(function(){
              PE.getCart(() => {
          			getListBXSY();
          		});
            });
          }
        });
      }
    });
    
    $(document).on('click','.pro-loop--buttons .add-to-cart', function(e){
			e.preventDefault();
			$(this).addClass('loading');
			var id =  $(this).attr('data-variantid');
			var quantity = 1;
      var btn = $(this);
			var param = {
				type: 'POST',
				url: '/cart/add.js',
				data:  { id: id, quantity: quantity },
				dataType: 'json',
				success: function(datacart) {
          btn.addClass('added');
          setTimeout(function(){
            btn.removeClass('added');
          },2000);
          KG.Global.cartAjax(function(){
            PE.getCart(() => {
        			getListBXSY();
        		});
            
            KG.Helper.getMiniCart();
          },);
				},
				error: function(XMLHttpRequest, textStatus) {
					if ( XMLHttpRequest.status == 422 ){
						KG.Helper.SwalWarning("Thông báo","Đã có lỗi xảy ra",'error',false,false,2000);
					}
				}
			}
			$.ajax(param);
      
      btn.removeClass('loading');
		});
  },
	getItemSlide: function(type,id,title,url,page,limit,target,callback){
		var url_get = url+'/products.json?include=metafields[product]&page=1&limit='+limit;
		$.get(url_get).done(function(data){
			if(data.products.length > 0){
				$(target+' .list-products').html('');
				data.products.map((item,ind) => {
					var html_loop = `<div class="swiper-slide"><div class="pro-loop ${type} ">` + KG.Global.renderLoop(item,limit*(page - 1) + (ind + 1)) + `</div></div>`;
					$(target+' .list-products').append(html_loop);
				});
			}
      else{
        $('.section-collection-s2').hide();
      }
			if(typeof callback === 'function') return callback();
		});
	},
	getItemGrid: function(id,title,url,page,limit,target){ 
		var url_get = url+'/products.json?include=metafields[product]&page='+page+'&limit='+limit;
		$.get(url_get).done(function(data){
			if(data.products.length > 0){
				$(target+' .grid-products').html('');
				data.products.map((item,ind) => {
					var html_loop = `<div class="pro-loop">` + KG.Global.renderLoop(item,limit*(page - 1) + (ind + 1)) + `</div>`;
					$(target+' .grid-products').append(html_loop);
				});
			}
		});
	},
	
	actionAccount: function(){
		$('body').on('click', '#js-btn-logout', function(e){
			e.preventDefault();
			Swal.fire({
				title: '',
				text: 'Bạn muốn thoát tài khoản',
				icon: 'question',
				showCancelButton: true,
				showConfirmButton: true,
				confirmButtonText: 'Đồng ý',
				cancelButtonText: 'Không',
			}).then((result) => {
				if (result.isConfirmed) {
					window.location = '/account/logout';
				} 
			})
		});
	},
	fixedMainHeader: function(){
		
		var $parentHeader = $('#mainHeader');
		var parentHeight = $parentHeader.find('.header-top').outerHeight();
		$parentHeader.css('min-height', parentHeight);
		var resizeTimer = false,
				resizeWindow = $(window).prop("innerWidth");

		$(window).on("resize", function() {
			if (resizeTimer) {	clearTimeout(resizeTimer)	}
			resizeTimer = setTimeout(function() {
				var newWidth = $(window).prop("innerWidth");
				if (resizeWindow != newWidth) {
					if($('body').hasClass('overflow-hidden')) {
						$( "#showmenu-mobile" ).first().trigger( "click" );
					}
					$('.header-top').removeClass("nav-sticky");

					$parentHeader.css('min-height', '');
					parentHeight = $parentHeader.find('.header-top').outerHeight();
					$parentHeader.css('min-height', parentHeight);
					resizeWindow = newWidth
				}
			}, 200)
		});
		setTimeout(function() {
			$parentHeader.css('min-height', '');
			parentHeight = $parentHeader.find('.header-top').outerHeight();
			$parentHeader.css('min-height', parentHeight);
			var stickyNow = false,
					currentState = false;
			$(window).scroll(function() {
				var curWinTop = $(window).scrollTop();
				if (curWinTop > 400) {
					$('.header-top').addClass("nav-sticky");	
					$parentHeader.addClass("hSticky");				
					currentState = true
				}
				else {
					$('.header-top').removeClass('nav-sticky').removeClass('nofade');
					$parentHeader.removeClass("hSticky");	
					currentState = false
				}
				if (currentState != stickyNow) {	stickyNow = currentState }
			})
		}, 300)
	},

  sliderBrand: function () {
    new Swiper('#brandhome-s2-slider .swiper', {
      slidesPerView: 3,
      spaceBetween: 0,
      breakpoints: {
        767: {
          slidesPerView: 6,
        },
        1024: {
          slidesPerView: 6,
        }
      },
      navigation: {
        nextEl: "#brandhome-s2-slider .swiper-button-next",
        prevEl: "#brandhome-s2-slider .swiper-button-prev",
      }
    });
  }, 
  modalBanner: function(){
		if (window.settings.banner_modal.show){
			var time = parseInt(200);
			if (document.cookie.indexOf('modalBanner') !== -1 && Cookies.get('modalBanner') == 'on') {
			}else{
				setTimeout(function(){
					$('#bannerModal').modal('show');
					var date = new Date();
					var minutes = parseInt(window.settings.banner_modal.minutes);
					date.setTime(date.getTime() + (minutes * 60 * 1000));
					Cookies.set('modalBanner', 'on', { expires: date });	
				},time);
			}
			$('body').on('click', '#bannerModal .close', function(e){
				e.preventDefault();
				$('#bannerModal').removeClass('show');
			});			
		}
	}
}  

KG.CustomerVerify = {
	omniFormRegister: function($form, $lastName, $firstName, $email, $phone, $password, $tags){
    var site_key = $form.find('script:eq(0)').attr('src').split('render=')[1];
		grecaptcha.ready(function() {	
			grecaptcha.execute(site_key, {action: 'submit'}).then(function(token) {
        $form.find('input[name="g-recaptcha-response"]').val(token);
				$.ajax({  
					type: "POST",
					url: '/account',
					data: $form.serialize(),
					success:function(data){  
						var parsedResponse = $.parseHTML(data);
						var result = $(parsedResponse);
						if(result.find('#create_customer .errors').length > 0){
							var titleError = result.find('#create_customer .errors li').html();
							if(titleError.indexOf(isText.text165) != -1){
								$form.find('.error-status').html(isText.text166).removeClass('d-none');
							}
							if(titleError.indexOf(isText.text167) != -1){
								$form.find('.error-status').html(isText.text167).removeClass('d-none');
							}
							if(titleError.indexOf('Lỗi hệ thống') != -1){
								$form.find('.error-status').html('Lỗi hệ thống').removeClass('d-none');
							}
							if(titleError.indexOf('xin vui lòng vào liên kết') != -1){
								sessionStorage.setItem('isRegister',true);
								$form.find('.success-status').html('Chúng tôi đã gửi email đến '+$email+', xin vui lòng vào liên kết trong mail để xác minh.').removeClass('d-none');
							}
						}
						else {
							window.location.href = '/account';
						}
						$('.loading-ovl').removeClass('open');
					},  
					error: function(x,y){
						//var $toast =  $('.toast');
						//$toast.find('.toast-body').text(isText.text109);
						//new bootstrap.Toast($toast[0]).show();
						$('.loading-ovl').removeClass('open');
					}
				});
			});
		});
	},
}

KG.Init = function(){
	KG.Global.init();
}
$(document).ready(function(){
	KG.Init();
})
